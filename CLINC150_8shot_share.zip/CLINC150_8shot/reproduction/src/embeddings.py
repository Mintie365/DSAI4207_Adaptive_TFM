"""Normalized Sentence-BERT embeddings with content-addressed, verified caches."""
from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np

from .prepare_data import frame_fingerprint
from .utils import fingerprint, read_json, unit_vectors, versions, write_json


def array_digest(array):
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()


def encoder_settings(config):
    return {**config["embedding"], "preprocessing": "original_text_no_changes",
            "normalize_embeddings": True, "dtype": "float32", "software": versions()}


class SentenceEncoder:
    def __init__(self, config, resolved_revision):
        self.config = config
        self.revision = resolved_revision
        self._model = None
        self.device = None

    def encode(self, texts):
        if self._model is None:
            import torch
            from sentence_transformers import SentenceTransformer

            requested = self.config["embedding"]["device"]
            self.device = ("cuda" if torch.cuda.is_available() else "cpu") if requested == "auto" else requested
            torch.manual_seed(self.config["seed"])
            if self.device.startswith("cuda"):
                torch.cuda.manual_seed_all(self.config["seed"])
            torch.use_deterministic_algorithms(True)
            self._model = SentenceTransformer(
                self.config["embedding"]["model"], revision=self.revision,
                device=self.device, cache_folder=self.config["paths"]["hub_cache"],
                trust_remote_code=False)
            self._model.max_seq_length = self.config["embedding"]["max_seq_length"]
            self._model.eval()
        values = self._model.encode(list(texts), batch_size=self.config["embedding"]["batch_size"],
                                    normalize_embeddings=True, convert_to_numpy=True,
                                    show_progress_bar=True)
        return unit_vectors(values).astype(np.float32)


def cache_identity(config, manifest, frame, split, revision):
    return {"schema_version": 1, "encoder": encoder_settings(config),
            "resolved_model_revision": revision, "dataset_manifest": manifest["fingerprint"],
            "split": split, "data_fingerprint": frame_fingerprint(frame)}


def save_or_load_embeddings(config, manifest, frame, split, revision, encoder):
    identity = cache_identity(config, manifest, frame, split, revision)
    key = fingerprint(identity)
    root = Path(config["paths"]["embeddings"])
    root.mkdir(parents=True, exist_ok=True)
    metadata_path = root / f"{split}-{key}.json"
    array_path = root / f"{split}-{key}.npy"
    if metadata_path.exists() and array_path.exists():
        return load_cache(root, key, identity, frame), key
    values = encoder.encode(frame.text.tolist())
    if values.ndim != 2 or len(values) != len(frame):
        raise ValueError("Encoder output must have one vector per sample")
    values = unit_vectors(values).astype(np.float32)
    temporary = array_path.with_suffix(".tmp")
    with temporary.open("wb") as stream:
        np.save(stream, values, allow_pickle=False)
    temporary.replace(array_path)
    write_json(metadata_path, {"identity": identity, "key": key, "shape": list(values.shape),
                               "sample_ids": frame.example_id.tolist(), "sha256": array_digest(values),
                               "dtype": str(values.dtype), "actual_device": getattr(encoder, "device", "test")})
    return values, key


def load_cache(root, key, identity, frame):
    split = identity["split"]
    metadata = read_json(Path(root) / f"{split}-{key}.json")
    if metadata["identity"] != identity or fingerprint(identity) != key or metadata["key"] != key:
        raise ValueError("Embedding cache identity mismatch")
    if metadata["sample_ids"] != frame.example_id.tolist():
        raise ValueError("Embedding/sample ID alignment mismatch")
    values = np.load(Path(root) / f"{split}-{key}.npy", allow_pickle=False)
    if (list(values.shape) != metadata["shape"] or values.ndim != 2 or len(values) != len(frame) or
        str(values.dtype) != metadata["dtype"] or array_digest(values) != metadata["sha256"]):
        raise ValueError("Embedding cache integrity check failed")
    if not np.isfinite(values).all() or not np.allclose(np.linalg.norm(values, axis=1), 1, atol=1e-5):
        raise ValueError("Cached embeddings must be finite and normalized")
    return values


def generate_embeddings(config, splits, manifest):
    from huggingface_hub import HfApi

    revision = HfApi().model_info(config["embedding"]["model"],
                                  revision=config["embedding"]["revision"]).sha
    encoder = SentenceEncoder(config, revision)
    keys = {}
    for name, frame in splits.items():
        values, key = save_or_load_embeddings(config, manifest, frame, name, revision, encoder)
        keys[name] = key
        print(f"{name}: {values.shape}; cache {key[:12]}")
    write_json(Path(config["paths"]["embeddings"]) / "index.json", {
        "resolved_revision": revision, "encoder": encoder_settings(config),
        "dataset_manifest": manifest["fingerprint"], "keys": keys})


def load_embeddings(config, splits, manifest):
    root = Path(config["paths"]["embeddings"])
    index = read_json(root / "index.json")
    if index["encoder"] != encoder_settings(config) or index["dataset_manifest"] != manifest["fingerprint"]:
        raise ValueError("Embedding configuration or dataset changed; rerun embed")
    arrays = {}
    for name, frame in splits.items():
        identity = cache_identity(config, manifest, frame, name, index["resolved_revision"])
        arrays[name] = load_cache(root, index["keys"][name], identity, frame)
    if len({array.shape[1] for array in arrays.values()}) != 1:
        raise ValueError("Embedding dimension mismatch across splits")
    return arrays, index
