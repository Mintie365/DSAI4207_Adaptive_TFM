"""Gold labels are used here, after inference, only for metrics and comparisons."""
from __future__ import annotations

from collections import defaultdict

import numpy as np
from sklearn.metrics import accuracy_score, f1_score


def classification_metrics(records, valid_labels):
    if not records:
        raise ValueError("Cannot compute metrics without observations")
    valid = set(valid_labels)
    gold = [r["gold_label"] for r in records]
    if any(label not in valid for label in gold):
        raise ValueError("Unknown evaluation gold label")
    predicted = [r["predicted_label"] if r["valid"] and r["predicted_label"] in valid else "__INVALID__" for r in records]
    return {"n": len(records), "accuracy": float(accuracy_score(gold, predicted)),
            "macro_f1": float(f1_score(gold, predicted, labels=list(valid_labels), average="macro", zero_division=0)),
            "macro_f1_present_gold": float(f1_score(gold, predicted, labels=sorted(set(gold)), average="macro", zero_division=0)),
            "invalid_rate": float(np.mean([p == "__INVALID__" for p in predicted]))}


def baseline_metrics(records, valid_labels, expected_queries, random_seeds, *, full_validation=False,
                     tie_break_order=("similar", "balanced", "diverse", "random")):
    grouped = defaultdict(list)
    for record in records:
        grouped[(record["strategy"], record["random_seed"] if record["strategy"] == "random" else None)].append(record)
    seeds, rows = [], []
    expected = set(expected_queries)
    complete = True
    for strategy in ("random", "similar", "diverse", "balanced"):
        strategy_seeds = list(random_seeds) if strategy == "random" else [None]
        observed = []
        for seed in strategy_seeds:
            group = grouped[(strategy, seed)]
            ids = [r["query_id"] for r in group]
            group_complete = len(ids) == len(set(ids)) and set(ids) == expected
            complete &= group_complete
            if not group:
                continue
            metrics = classification_metrics(group, valid_labels)
            observed.append(metrics)
            if strategy == "random":
                seeds.append({"seed": seed, **metrics, "complete": group_complete})
        row = {"strategy": strategy, "query_count": len(expected), "completed_runs": len(observed),
               "required_runs": len(strategy_seeds)}
        for metric in ("accuracy", "macro_f1", "invalid_rate", "macro_f1_present_gold"):
            row[metric] = float(np.mean([m[metric] for m in observed])) if observed else None
            row[metric + "_std"] = float(np.std([m[metric] for m in observed], ddof=0)) if observed else None
        rows.append(row)
    winners = {"global_best_all_four": None, "global_best_adaptive_candidates": None}
    if full_validation and complete and len(expected) == 1003 and len(random_seeds) == 5:
        scores = {row["strategy"]: row["accuracy"] for row in rows}
        def best(order):
            maximum = max(scores[s] for s in order)
            return next(s for s in order if maximum - scores[s] <= 1e-12)
        winners["global_best_all_four"] = best(tie_break_order)
        winners["global_best_adaptive_candidates"] = best([s for s in tie_break_order if s != "random"])
    return {"baselines": rows, "random_seeds": seeds, "complete": bool(complete),
            "macro_f1_convention": "mean over all 77 official labels; zero_division=0; invalid predictions count as incorrect/FN",
            "random_std_ddof": 0, "tie_break_order": list(tie_break_order),
            "accuracy_tie_tolerance": 1e-12,
            "global_best_status": "selected_on_full_validation" if winners["global_best_all_four"] else "pending_full_validation",
            **winners}
