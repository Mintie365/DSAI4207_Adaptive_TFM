from __future__ import annotations

import hashlib
import importlib.metadata
import json
import platform
import re
import unicodedata
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
SPLITS = ("demonstration_pool", "meta_training", "validation", "test")


def fingerprint(value) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def load_config(path="configs/phase1.yaml"):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    for key, value in config["paths"].items():
        config["paths"][key] = str((ROOT / value).resolve())
    if config["selection"]["k"] not in config["selection"]["supported_k"]:
        raise ValueError("Default k must belong to supported_k")
    if config["retrieval"]["candidate_pool_size"] < max(config["selection"]["supported_k"]):
        raise ValueError("Candidate pool must cover all supported budgets")
    return config


def normalized_text(text: str) -> str:
    # Audit / exact-match exclusion only. Encoder always receives the original text.
    text = unicodedata.normalize("NFKC", text).casefold()
    return " ".join(re.sub(r"[^\w\s]", " ", text).split())


def unit_vectors(values):
    values = np.asarray(values, dtype=np.float32)
    if values.ndim not in (1, 2) or not np.isfinite(values).all():
        raise ValueError("Expected a finite vector or matrix")
    norms = np.linalg.norm(values, axis=-1, keepdims=True)
    if np.any(norms <= 0):
        raise ValueError("Zero-length embeddings are invalid")
    return values / norms


def versions():
    result = {"python": platform.python_version()}
    for package in ("numpy", "pandas", "scikit-learn", "datasets", "torch",
                    "sentence-transformers", "transformers"):
        try:
            result[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            result[package] = "not-installed"
    return result
