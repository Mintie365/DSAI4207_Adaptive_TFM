"""Validation-only inspection, with explicit provenance and shared candidate pools."""
from __future__ import annotations

from itertools import combinations
from pathlib import Path

import numpy as np

from .retrieval import SemanticRetriever
from .selection import STRATEGIES, select_demonstrations
from .utils import fingerprint, read_json, write_json


def run_demo(config, splits, arrays, manifest, embedding_index):
    count = config["demo"]["num_queries"]
    validation = splits["validation"]
    if not 5 <= count <= min(10, len(validation)):
        raise ValueError("Demo must use 5–10 validation queries")
    # Sample queries without looking at their gold labels.
    positions = sorted(np.random.default_rng(config["seed"]).choice(len(validation), count, replace=False))
    retriever = SemanticRetriever(splits["demonstration_pool"], arrays["demonstration_pool"],
                                  config["retrieval"]["exclude_identical_text"])
    examples = []
    budget = config["selection"]["k"]
    for position in positions:
        query = validation.iloc[position]
        vector = arrays["validation"][position]
        pool = retriever.retrieve(vector, config["retrieval"]["candidate_pool_size"],
                                   query_id=query.example_id, query_text=query.text)
        selections = []
        for strategy in STRATEGIES:
            seeds = config["selection"]["random_seeds"] if strategy == "random" else [config["seed"]]
            for seed in seeds:
                selections.append(select_demonstrations(
                    vector, pool, strategy, budget, seed, mmr_lambda=config["selection"]["mmr_lambda"],
                    query_id=query.example_id, query_text=query.text))
        overlaps = []
        primary = {s["strategy"]: s for s in selections
                   if s["strategy"] != "random" or s["seed"] == config["selection"]["random_seeds"][0]}
        for left, right in combinations(STRATEGIES, 2):
            a = {d["example_id"] for d in primary[left]["demonstrations"]}
            b = {d["example_id"] for d in primary[right]["demonstrations"]}
            overlaps.append({"left": left, "right": right, "common_count": len(a & b),
                             "jaccard": len(a & b) / len(a | b)})
        vectors_by_id = {d.example_id: d.embedding for d in pool}
        for selection in selections:
            vectors = np.stack([vectors_by_id[d["example_id"]] for d in selection["demonstrations"]])
            pairwise = vectors @ vectors.T
            selection["inspection_metrics"] = {
                "mean_query_similarity": float(np.mean([d["similarity"] for d in selection["demonstrations"]])),
                "mean_pairwise_cosine": float(np.mean(pairwise[np.triu_indices(budget, k=1)])) if budget > 1 else None}
        examples.append({"query_id": query.example_id, "query_text": query.text,
                         "candidate_pool": [d.as_dict() for d in pool],
                         "selections": selections, "overlap": overlaps})
    output = Path(config["paths"]["results"])
    output.mkdir(parents=True, exist_ok=True)
    result = {"schema_version": 1, "dataset_manifest": manifest["fingerprint"],
              "model_revision": embedding_index["resolved_revision"],
              "embedding_cache_keys": embedding_index["keys"],
              "config_fingerprint": fingerprint({k: v for k, v in config.items() if k != "paths"}),
              "query_partition": "validation",
              "uses_query_gold_labels": False, "examples": examples}
    write_json(output / "demo_examples.json", result)
    audit = read_json(Path(config["paths"]["splits"]) / "duplicate_report.json")
    lines = ["# Phase 1 实际运行摘要", "", "使用真实 Banking77 和 Sentence-BERT；未调用 LLM，未训练元选择器。", "",
             f"Dataset revision: `{manifest['resolved_revision']}`",
             f"Encoder revision: `{embedding_index['resolved_revision']}`", "",
             "| Split | 样本数 | 类别数 |", "|---|---:|---:|"]
    for name, info in manifest["splits"].items():
        lines.append(f"| {name} | {info['count']} | {info['num_classes']} |")
    lines.extend(["", f"检查 {count} 条固定种子抽取的 validation 查询。每条先检索同一 Top-{len(pool)} 候选池，再选择 k={budget}。",
                  "Random 保存五个 seed；其余策略各保存一次。查询 gold label 没有传入检索或选择接口。",
                  "", f"跨 split 重复审计：normalized exact={audit['exact_cross_split_count']}；lexical near={audit['near_cross_split_count']}。",
                  "完整配对见 data/splits/duplicate_report.json。未删除/修改官方 test；检索默认排除同 ID 和规范化后完全相同的查询文本。",
                  "词面近重复审计不能保证发现所有语义改写；发现的近重复仍保留，应在未来评估中披露。", "",
                  "## 各查询的选择情况", ""])
    for example in examples:
        lines.extend([f"### {example['query_id']}", "", f"> {example['query_text']}", "",
                      "| 策略 (seed) | 平均查询相似度 | 示例间平均 cosine | 所选候选 rank（选择顺序） |",
                      "|---|---:|---:|---|"])
        for selected in example["selections"]:
            demos = selected["demonstrations"]
            mean = np.mean([d["similarity"] for d in demos])
            ranks = ", ".join(str(d["rank"]) for d in demos)
            redundancy = selected["inspection_metrics"]["mean_pairwise_cosine"]
            lines.append(f"| {selected['strategy']} ({selected['seed']}) | {mean:.4f} | {redundancy:.4f} | {ranks} |")
        lines.extend(["", "策略间共同示例数（Random 使用第一个 seed）：" + "；".join(
            f"{o['left']}/{o['right']}={o['common_count']}" for o in example["overlap"]), ""])
        lines.extend(["", "Top-3 检索结果：", ""])
        for d in example["candidate_pool"][:3]:
            lines.append(f"- {d['similarity']:.4f} · `{d['label']}` · {d['text']}")
        lines.append("")
    lines.extend(["## 行为与限制", "", "Similar 的 rank 为 1…k；Diverse 从 rank 1 开始，再最大化与已选集合的最小余弦距离；",
                  "Balanced 从 rank 1 开始按配置的 MMR 权衡相关性与冗余。Random 在同一个候选池中无放回采样。",
                  "上述选择的预算、唯一性、候选池归属、排序均在运行时检查；具体算法由独立合成测试验证。",
                  "不同策略可能选到相同示例，这不是错误。当前结果只能验证检索与选择行为，不能证明分类性能提升。",
                  "test 仅用于原始数据检查、重复审计和独立编码，不参与本演示、候选检索、调参或策略判断。", ""])
    lines.extend(["聚合检查（8 条是默认值；表内实际数量由配置决定）：", "",
                  "| 策略（第一个 Random seed） | 平均查询相似度 | 示例间平均 cosine |", "|---|---:|---:|"])
    for strategy in STRATEGIES:
        selected = [next(s for s in e["selections"] if s["strategy"] == strategy) for e in examples]
        relevance = np.mean([s["inspection_metrics"]["mean_query_similarity"] for s in selected])
        redundancy = np.mean([s["inspection_metrics"]["mean_pairwise_cosine"] for s in selected])
        lines.append(f"| {strategy} | {relevance:.4f} | {redundancy:.4f} |")
    lines.extend(["", "示例间 cosine 越低表示这组示例平均更分散；Diverse 优化的是逐步 max-min，而非全局平均距离。",
                  "这里只做行为检查，不将这些统计当作下游分类性能或选模依据。", ""])
    # Runtime assertions use saved records, independently of selector internals.
    for example in examples:
        pool_ids = {d["example_id"] for d in example["candidate_pool"]}
        scores = [d["similarity"] for d in example["candidate_pool"]]
        if scores != sorted(scores, reverse=True):
            raise AssertionError("Retrieval order is incorrect")
        for selection in example["selections"]:
            ids = [d["example_id"] for d in selection["demonstrations"]]
            if len(ids) != budget or len(set(ids)) != budget or not set(ids) <= pool_ids:
                raise AssertionError("Invalid selection")
            if selection["strategy"] == "similar" and ids != [d["example_id"] for d in example["candidate_pool"][:budget]]:
                raise AssertionError("Similar disagrees with retrieval")
    (output / "summary.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Saved {count} validation examples and summary to {output}")
    return result
