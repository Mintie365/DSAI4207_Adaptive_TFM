"""Pure retrospective analysis; never called during retrieval or LLM prediction."""
from __future__ import annotations

from itertools import combinations

import numpy as np
import pandas as pd
from scipy.stats import binomtest, spearmanr

from .evaluation import classification_metrics
from .label_parsing import parse_intent

CANDIDATES = ("similar", "diverse", "balanced")


def validate_records(records, validation, labels, seeds, controls_hash):
    """Reject missing, duplicate logical keys, inconsistent labels or mixed runs."""
    ids = set(validation.example_id)
    gold = validation.set_index("example_id").label_name.to_dict()
    variants = [(s, None) for s in CANDIDATES] + [("random", s) for s in seeds] + [("zero_shot", None)]
    expected = {(q, strategy, seed) for q in ids for strategy, seed in variants}
    indexed = {}
    for record in records:
        key = (record["query_id"], record["strategy"], record["random_seed"])
        if key not in expected or key in indexed:
            raise ValueError(f"Unexpected or duplicate strategy-query prediction: {key}")
        if record["controls_hash"] != controls_hash or record["actual_device"] != "mps":
            raise ValueError("Mixed experimental controls/device")
        if record["gold_label"] != gold[key[0]]:
            raise ValueError("Saved gold label mismatch")
        parsed = parse_intent(record["raw_output"], labels)
        if (parsed["predicted_label"], parsed["valid"]) != (record["predicted_label"], record["valid"]):
            raise ValueError("Saved prediction/parser mismatch")
        budget = 0 if key[1] == "zero_shot" else 8
        if len(record["demonstration_ids"]) != budget or len(set(record["demonstration_ids"])) != budget:
            raise ValueError("Incorrect demonstration budget")
        if budget and (len(record["candidate_ids"]) != 32 or not set(record["demonstration_ids"]) <= set(record["candidate_ids"])):
            raise ValueError("Invalid Top-32 membership")
        if not np.isfinite(record["runtime_seconds"]) or record["runtime_seconds"] < 0:
            raise ValueError("Invalid inference time")
        indexed[key] = record
    missing = expected - set(indexed)
    if missing:
        raise ValueError(f"Missing {len(missing)} planned predictions; first={sorted(missing, key=str)[0]}")
    return indexed


def prediction_arrays(indexed, query_ids, labels, seeds):
    """Rows are queries; random columns retain the five predefined seed identities."""
    def agreement_label(record):
        # Preserve distinct invalid raw labels for agreement analysis; never repair them.
        return record["predicted_label"] if record["valid"] else "__INVALID__:"+record["raw_output"].strip()
    predictions = {s: np.array([agreement_label(indexed[(q,s,None)]) for q in query_ids], dtype=object)
                   for s in (*CANDIDATES, "zero_shot")}
    gold = np.array([indexed[(q, "similar", None)]["gold_label"] for q in query_ids], dtype=object)
    correct = {s: np.array([indexed[(q, s, None)]["valid"] and predictions[s][i] == gold[i]
                           for i, q in enumerate(query_ids)], dtype=bool) for s in predictions}
    random = np.array([[indexed[(q, "random", seed)]["valid"] and
                        indexed[(q, "random", seed)]["predicted_label"] == gold[i]
                        for seed in seeds] for i, q in enumerate(query_ids)], dtype=bool)
    return predictions, correct, random, gold


def complementarity(predictions, correct):
    matrix = np.column_stack([predictions[s] for s in CANDIDATES])
    successes = np.column_stack([correct[s] for s in CANDIDATES])
    n = len(matrix)
    distinct = np.array([len(set(row)) for row in matrix])
    counts = successes.sum(axis=1)
    all_valid = np.array([all(isinstance(value,str) and not value.startswith("__INVALID__:") for value in row) for row in matrix])
    pairs = []
    agreement_matrix = np.eye(3)
    for a, b in combinations(range(3), 2):
        prediction_disagreement = matrix[:, a] != matrix[:, b]
        correctness_disagreement = successes[:, a] != successes[:, b]
        agreement_matrix[a, b] = agreement_matrix[b, a] = 1-float(prediction_disagreement.mean())
        pairs.append({"left": CANDIDATES[a], "right": CANDIDATES[b],
                      "prediction_disagreement_count": int(prediction_disagreement.sum()),
                      "prediction_disagreement_rate": float(prediction_disagreement.mean()),
                      "correctness_disagreement_count": int(correctness_disagreement.sum()),
                      "correctness_disagreement_rate": float(correctness_disagreement.mean()),
                      "different_but_both_wrong_count": int((prediction_disagreement & ~successes[:, a] & ~successes[:, b]).sum())})
    s, d, b = (correct[name] for name in CANDIDATES)
    rescue = {"similar_wrong_diverse_correct": ~s & d, "similar_wrong_balanced_correct": ~s & b,
              "diverse_wrong_similar_correct": ~d & s, "balanced_wrong_similar_correct": ~b & s,
              "similar_wrong_at_least_one_alternative_correct": ~s & (d | b)}
    return {"n": n,
            "prediction_agreement": {"all_three_same": float((distinct == 1).mean()),
                                     "exactly_two_agree": float((distinct == 2).mean()),
                                     "all_three_different": float((distinct == 3).mean())},
            "invalid_agreement_policy":"Each invalid raw response (trimmed only) is a tagged category; distinct invalid outputs are not collapsed to None. All remain incorrect.",
            "all_three_valid_query_count":int(all_valid.sum()),
            "all_valid_prediction_agreement": {"all_three_same":float((distinct[all_valid]==1).mean()),
                                               "exactly_two_agree":float((distinct[all_valid]==2).mean()),
                                               "all_three_different":float((distinct[all_valid]==3).mean())} if all_valid.any() else None,
            "success_counts": {str(k): int((counts == k).sum()) for k in range(4)},
            "success_fractions": {str(k): float((counts == k).mean()) for k in range(4)},
            "rescue": {name: {"count": int(mask.sum()), "fraction": float(mask.mean())} for name, mask in rescue.items()},
            "correctness_patterns": {format(k, '03b'): int(np.all(successes == [bool(k&4), bool(k&2), bool(k&1)], axis=1).sum())
                                     for k in range(8)},
            "agreement_matrix": agreement_matrix.tolist(), "pairwise": pairs}


def ambiguity_groups(entropy, cutpoints):
    entropy = np.asarray(entropy, dtype=float)
    if not np.isfinite(entropy).all() or np.any(np.diff(cutpoints) < 0):
        raise ValueError("Invalid entropy or cutpoints")
    # An entropy equal to a cutpoint belongs to the lower bin. All ties stay together.
    return np.searchsorted(np.asarray(cutpoints), entropy, side="left")


def ambiguity_summary(features, predictions, correct, best_global, cutpoints):
    groups = ambiguity_groups(features["entropy_bits"], cutpoints)
    oracle = np.logical_or.reduce([correct[s] for s in CANDIDATES])
    pair_masks = {f"{a}/{b}": predictions[a] != predictions[b] for a,b in combinations(CANDIDATES,2)}
    rows = []
    for group in range(4):
        mask = groups == group
        row = {"group": f"Q{group+1}", "n": int(mask.sum()),
               "entropy_lower_bound": 0.0 if group == 0 else float(cutpoints[group-1]),
               "lower_bound_inclusive": group == 0,
               "entropy_upper_inclusive": float(cutpoints[group]) if group < 3 else float('inf')}
        if not mask.any():
            rows.append(row)
            continue
        scores = {s: float(correct[s][mask].mean()) for s in CANDIDATES}
        row.update({f"{s}_accuracy": value for s,value in scores.items()})
        row["oracle_accuracy"] = float(oracle[mask].mean())
        row["global_best_candidate_accuracy"] = scores[best_global]
        row["oracle_gain_over_global_best"] = row["oracle_accuracy"] - scores[best_global]
        row["best_fixed_in_group_accuracy"] = max(scores.values())
        row["oracle_gain_over_group_best"] = row["oracle_accuracy"] - max(scores.values())
        row["mean_pairwise_disagreement"] = float(np.mean([m[mask].mean() for m in pair_masks.values()]))
        for key, values in pair_masks.items():
            row[f"disagreement_{key}"] = float(values[mask].mean())
        row["mean_top_label_vote"] = float(features.loc[mask, "top_label_vote"].mean())
        rows.append(row)
    correlations = []
    outcomes = {f"{s}_error": ~correct[s] for s in CANDIDATES}
    outcomes["any_prediction_disagreement"] = np.logical_or.reduce(list(pair_masks.values()))
    outcomes["oracle_rescues_global_best"] = oracle & ~correct[best_global]
    for feature in ("entropy_bits", "top_label_vote"):
        for outcome, values in outcomes.items():
            if len(np.unique(values)) < 2 or features[feature].nunique() < 2:
                rho, p = None, None
            else:
                result = spearmanr(features[feature], values.astype(float))
                rho, p = float(result.statistic), float(result.pvalue)
            correlations.append({"feature": feature, "outcome": outcome, "spearman_rho": rho,
                                 "p_value_unadjusted_exploratory": p})
    return pd.DataFrame(rows), pd.DataFrame(correlations), groups


def bootstrap_means(values, replicates=5000, seed=42, batch_size=250):
    values = np.asarray(values, dtype=float)
    if values.ndim == 1:
        values = values[:, None]
    if not len(values) or not np.isfinite(values).all() or replicates < 1:
        raise ValueError("Invalid bootstrap data")
    rng = np.random.default_rng(seed)
    output = []
    for start in range(0, replicates, batch_size):
        indices = rng.integers(0, len(values), size=(min(batch_size, replicates-start), len(values)))
        output.append(values[indices].mean(axis=1))
    return np.vstack(output)


def exact_mcnemar(left, right):
    left, right = np.asarray(left, bool), np.asarray(right, bool)
    left_only, right_only = int((left & ~right).sum()), int((right & ~left).sum())
    total = left_only + right_only
    return {"left_only_correct": left_only, "right_only_correct": right_only,
            "mcnemar_exact_p": float(binomtest(left_only, total, .5, alternative="two-sided").pvalue) if total else 1.0}


def holm_adjust(p_values):
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values, kind="stable")
    result = np.empty_like(values)
    largest = 0.
    for rank, i in enumerate(order):
        largest = max(largest, (len(values)-rank)*values[i])
        result[i] = min(1., largest)
    return result


def statistical_comparisons(correct, random_correct, best_global, config):
    oracle = np.logical_or.reduce([correct[s] for s in CANDIDATES])
    values = {**{s: correct[s].astype(float) for s in (*CANDIDATES, "zero_shot")},
              "random_mean": random_correct.mean(axis=1), "oracle": oracle.astype(float)}
    names = list(values)
    samples = bootstrap_means(np.column_stack([values[s] for s in names]), config["replicates"],
                              config["seed"], config["batch_size"])
    bootstrap = {s: samples[:, i] for i,s in enumerate(names)}
    comparisons = [(a,b,"predefined_candidate_pair") for a,b in combinations(CANDIDATES,2)]
    comparisons += [(s,"zero_shot","predefined_icl_vs_zero") for s in CANDIDATES]
    comparisons += [("random_mean","zero_shot","random_mean_query_paired"),
                    ("random_mean",best_global,"post_selection_random_vs_best"),
                    ("oracle",best_global,"post_selection_oracle_gain")]
    alpha = (1-config["confidence"])/2
    rows = []
    for left,right,kind in comparisons:
        delta = values[left]-values[right]
        low, high = np.quantile(bootstrap[left]-bootstrap[right],[alpha,1-alpha])
        row = {"left":left,"right":right,"comparison":kind,"n":len(delta),
               "accuracy_difference":float(delta.mean()),"ci_95_low":float(low),"ci_95_high":float(high),
               "bootstrap_replicates":config["replicates"],"bootstrap_seed":config["seed"],
               "ci_excludes_zero":bool(low>0 or high<0),
               "post_selection":kind.startswith("post_selection"),
               "random_unit":"query, averaging the same five fixed seeds" if "random_mean" in (left,right) else "query"}
        if kind == "predefined_candidate_pair":
            row.update(exact_mcnemar(correct[left],correct[right]))
        rows.append(row)
    adjusted = holm_adjust([r["mcnemar_exact_p"] for r in rows[:3]])
    for row,p in zip(rows[:3],adjusted):
        row["mcnemar_holm_p"] = float(p)
    # Reselect best candidate in each bootstrap replicate as a sensitivity analysis.
    gain_reselected = bootstrap["oracle"] - np.max(np.column_stack([bootstrap[s] for s in CANDIDATES]),axis=1)
    sensitivity = {"bootstrap_reselect_best_ci":np.quantile(gain_reselected,[alpha,1-alpha]).tolist(),
                   "note":"Exploratory Validation resampling, not an unbiased post-selection Test estimate"}
    return pd.DataFrame(rows), sensitivity


def metrics_tables(records, labels, seeds):
    rows, random_rows = [], []
    for strategy in ("zero_shot", "random", *CANDIDATES):
        grouped = []
        for seed in (seeds if strategy == "random" else [None]):
            group = [r for r in records if r["strategy"] == strategy and r["random_seed"] == seed]
            metrics = classification_metrics(group,labels)
            metrics.update({"correct_count":sum(r["valid"] and r["predicted_label"]==r["gold_label"] for r in group),
                            "incorrect_count":sum(not r["valid"] or r["predicted_label"]!=r["gold_label"] for r in group),
                            "mean_inference_seconds":float(np.mean([r["runtime_seconds"] for r in group]))})
            grouped.append(metrics)
            if strategy == "random":
                random_rows.append({"seed":seed, **metrics})
        row = {"strategy":strategy,"n":grouped[0]["n"],"seed_runs":len(grouped)}
        for key in ("accuracy","macro_f1","invalid_rate","correct_count","incorrect_count","mean_inference_seconds"):
            row[key] = float(np.mean([m[key] for m in grouped]))
            row[key+"_std"] = float(np.std([m[key] for m in grouped],ddof=0))
        rows.append(row)
    return pd.DataFrame(rows), pd.DataFrame(random_rows)
