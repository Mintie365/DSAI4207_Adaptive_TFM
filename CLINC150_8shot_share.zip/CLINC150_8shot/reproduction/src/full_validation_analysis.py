"""Recompute the full Phase 2 report strictly from completed, audited saved predictions."""
from __future__ import annotations

from collections import Counter
from itertools import combinations
import hashlib
from pathlib import Path

import numpy as np
import pandas as pd

from .evaluation import baseline_metrics
from .experiment_cache import append_record, read_records
from .full_validation_run import load_analysis_config
from .phase2_data import load_phase2_config, load_phase2_inputs
from .retrieval import SemanticRetriever
from .prompting import build_prompt
from .selection import select_demonstrations
from .strategy_analysis import (CANDIDATES, ambiguity_summary, complementarity, metrics_tables,
                                prediction_arrays, statistical_comparisons, validate_records)
from .utils import ROOT, fingerprint, read_json, write_json


def neighborhood_features(phase1, frames, arrays, m=32):
    if not 1<=m<=32:
        raise ValueError("Mean-neighborhood budget must be within Top-32")
    retriever = SemanticRetriever(frames["demonstration_pool"],arrays["demonstration_pool"],phase1["retrieval"]["exclude_identical_text"])
    rows,pools = [],{}
    for position,row in frames["validation"][["example_id","text"]].iterrows():
        pool = retriever.retrieve(arrays["validation"][position],32,query_id=row.example_id,query_text=row.text)
        counts = Counter(c.label for c in pool)
        proportions = np.array(list(counts.values()),dtype=float)/32
        rows.append({"query_id":row.example_id,"max_similarity":pool[0].similarity,
                     "mean_similarity":float(np.mean([c.similarity for c in pool[:m]])),"mean_neighbors_m":m,
                     "entropy_bits":float(-np.sum(proportions*np.log2(proportions))),
                     "top_label_vote":float(proportions.max()),"unique_intents":len(counts)})
        pools[row.example_id] = pool
    return pd.DataFrame(rows),pools


def representative_cases(validation,predictions,correct,features,indexed,pools,phase1,settings):
    ids = validation.example_id.tolist()
    gold_lookup = validation.set_index("example_id")
    s,d,b = (correct[name] for name in CANDIDATES)
    categories = {"similar_only_correct":s & ~d & ~b,
                  "diverse_correct_similar_wrong":d & ~s,
                  "balanced_correct_similar_wrong":b & ~s,
                  "all_correct":s & d & b,"all_wrong":~s & ~d & ~b,
                  "prediction_disagreement":np.logical_or.reduce([predictions[a]!=predictions[z] for a,z in combinations(CANDIDATES,2)])}
    selected,used = [],set()
    coverage = {}
    for category,mask in categories.items():
        eligible = sorted(i for i in np.flatnonzero(mask) if ids[i] not in used)
        coverage[category] = int(mask.sum())
        for i in eligible[:settings["per_category"]]:
            selected.append((i,category)); used.add(ids[i])
    # Fill only if some categories are too rare, without inventing missing cases.
    for i in np.argsort(-features.entropy_bits.to_numpy(),kind="stable"):
        if len(selected)>=settings["target_total"]:
            break
        if ids[i] not in used:
            selected.append((int(i),"additional_high_entropy_case")); used.add(ids[i])
    demo = pd.read_csv(Path(phase1["paths"]["splits"])/"demonstration_pool.csv",keep_default_na=False).set_index("example_id")
    output = []
    for i,category in selected:
        query_id = ids[i]
        pool = pools[query_id]
        similarities = {c.example_id:c.similarity for c in pool}
        output.append({"category":category,"query_id":query_id,"query_text":gold_lookup.loc[query_id,"text"],
            "gold_label":gold_lookup.loc[query_id,"label_name"],
            "predictions":{name:indexed[(query_id,name,None)]["predicted_label"] for name in CANDIDATES},
            "raw_outputs":{name:indexed[(query_id,name,None)]["raw_output"] for name in CANDIDATES},
            "correct":{name:bool(correct[name][i]) for name in CANDIDATES},
            "top32_label_distribution":dict(Counter(c.label for c in pool)),
            "features":features.iloc[i].to_dict(),
            "demonstrations":{name:[{"example_id":eid,"label":demo.loc[eid,"label_name"],
                "text":demo.loc[eid,"text"],"similarity":similarities[eid]}
                for eid in indexed[(query_id,name,None)]["demonstration_ids"]] for name in CANDIDATES}})
    return {"selection_rule":settings,"available_queries_by_category":coverage,"cases":output,
            "caution":"Retrospective descriptive cases; not causal evidence or training targets"}


def run_analysis(config,analysis):
    destination = ROOT/analysis["output"]
    plan = read_json(destination/"analysis_plan.json")
    if plan["analysis"] != analysis:
        raise ValueError("Analysis settings differ from frozen plan")
    sources = read_json(destination/"source_runs.json")
    full,zero = ROOT/sources["full_directory"],ROOT/sources["zero_directory"]
    if not read_json(full/"status.json")["complete"] or not read_json(zero/"status.json")["complete"]:
        raise ValueError("Full validation or zero-shot incomplete")
    phase1,frames,arrays,labels,manifest,embedding_index = load_phase2_inputs(config)
    validation = frames["validation"].sort_values("example_id").reset_index(drop=True)
    if len(validation)!=analysis["expected_queries"] or manifest["fingerprint"]!=plan["dataset_manifest"]:
        raise ValueError("Unexpected Validation data")
    records = read_records(full/"validation_predictions.jsonl",False)+read_records(zero/"zero_shot_predictions.jsonl",False)
    seeds = analysis["expected_random_seeds"]
    indexed = validate_records(records,validation,labels,seeds,sources["controls_hash"])
    full_snapshot = read_json(full/"experiment_config.json")
    inference_identity = full_snapshot["experiment"]["controls"]["inference"]
    if (inference_identity["model_revision"]!=config["model"]["revision"] or
        inference_identity["tokenizer_revision"]!=config["model"]["tokenizer_revision"] or
        inference_identity["device"]!="mps" or inference_identity["precision"]!="torch.float16" or
        not inference_identity["all_parameters_frozen"] or not inference_identity["evaluation_mode"] or
        inference_identity["generation"]["do_sample"] or inference_identity["generation"]["num_beams"]!=1):
        raise ValueError("Checkpoint, precision or deterministic inference controls changed")
    for record in records:
        if record["inference_identity_hash"]!=fingerprint(inference_identity):
            raise ValueError("Prediction has different model/tokenizer/generation identity")
        cache_record = read_json(ROOT/config["results"]/"inference_cache"/f"{record['cache_key']}.json")
        identity = cache_record["identity"]
        if (fingerprint(identity)!=record["cache_key"] or cache_record["key"]!=record["cache_key"] or
            fingerprint(cache_record["prediction"])!=cache_record["prediction_sha256"] or
            identity["controls_hash"]!=sources["controls_hash"]):
            raise ValueError("Prediction cache identity/integrity failed")
        for key in ("query_id","strategy","random_seed","demonstration_ids","prompt_hash"):
            if identity[key]!=record[key]:
                raise ValueError(f"Cache/log disagree on {key}")
        for key in ("predicted_label","raw_output","valid","runtime_seconds"):
            if cache_record["prediction"][key]!=record[key]:
                raise ValueError(f"Cache/log prediction mismatch: {key}")
    predictions,correct,random_correct,gold = prediction_arrays(indexed,validation.example_id.tolist(),labels,seeds)
    baseline,seed_table = metrics_tables(records,labels,seeds)
    fixed = baseline_metrics([r for r in records if r["strategy"]!="zero_shot"],labels,
                            validation.example_id.tolist(),seeds,full_validation=True)
    best_global = fixed["global_best_adaptive_candidates"]
    if best_global is None:
        raise ValueError("Cannot select a best strategy from incomplete full predictions")
    complement = complementarity(predictions,correct)
    features,pools = neighborhood_features(phase1,frames,arrays,analysis["feature_mean_neighbors"])
    features = features.set_index("query_id").loc[validation.example_id].reset_index()
    for query_id,pool in pools.items():
        expected = [c.example_id for c in pool]
        source_position = int(frames["validation"].index[frames["validation"].example_id.eq(query_id)][0])
        query_text = str(frames["validation"].loc[source_position,"text"])
        for strategy,seed in [(s,None) for s in CANDIDATES]+[("random",s) for s in seeds]:
            record = indexed[(query_id,strategy,seed)]
            if record["candidate_ids"]!=expected:
                raise ValueError("Reconstructed Top-32 differs from saved experimental candidates")
            selected = select_demonstrations(arrays["validation"][source_position],pool,strategy,8,
                config["seed"] if seed is None else seed,mmr_lambda=phase1["selection"]["mmr_lambda"])
            prompt = build_prompt(query_text,selected["demonstrations"],labels,k=8,version=config["prompt"]["version"])
            if prompt.demonstration_ids!=record["demonstration_ids"] or prompt.prompt_hash!=record["prompt_hash"]:
                raise ValueError("Saved selection/order/prompt differs from original Phase 1/2 rules")
        zero_prompt = build_prompt(query_text,[],labels,k=0,version=config["prompt"]["version"])
        if zero_prompt.prompt_hash!=indexed[(query_id,"zero_shot",None)]["prompt_hash"]:
            raise ValueError("Zero-shot instructions/labels/template differ")
    ambiguity,correlations,groups = ambiguity_summary(features,predictions,correct,best_global,plan["entropy_cutpoints_bits"])
    statistics,sensitivity = statistical_comparisons(correct,random_correct,best_global,analysis["bootstrap"])
    oracle = np.logical_or.reduce([correct[s] for s in CANDIDATES])
    gain = next(r for r in statistics.to_dict("records") if r["comparison"]=="post_selection_oracle_gain")
    oracle_result = {"n":len(validation),"candidate_strategies":list(CANDIDATES),
        "oracle_correct_count":int(oracle.sum()),"oracle_accuracy":float(oracle.mean()),
        "global_best_all_four":fixed["global_best_all_four"],"global_best_adaptive_candidates":best_global,
        "global_best_candidate_accuracy":float(correct[best_global].mean()),
        "oracle_gain":float((oracle.astype(float)-correct[best_global]).mean()),
        "oracle_gain_ci_95":[gain["ci_95_low"],gain["ci_95_high"]],
        "oracle_rescued_query_count":int((oracle & ~correct[best_global]).sum()),
        "zero_shot_accuracy":float(correct["zero_shot"].mean()),
        "best_fixed_icl_minus_zero_shot":float(next(r for r in baseline.to_dict('records') if r['strategy']==fixed['global_best_all_four'])['accuracy']-correct['zero_shot'].mean()),
        **sensitivity,
        "interpretation":"Retrospective gold-label Oracle restricted to these fixed three predictions; not a deployed adaptive model and not an upper bound outside these strategies.",
        "selection_warning":"Best fixed is selected on this same Validation set. CIs/tests are exploratory, conditional on the observed configuration; independent Test confirmation remains necessary."}
    cases = representative_cases(validation,predictions,correct,features,indexed,pools,phase1,analysis["representative_cases"])
    prediction_table = pd.DataFrame({"query_id":validation.example_id,"gold_label":gold,
        **{name:[indexed[(q,name,None)]["predicted_label"] for q in validation.example_id] for name in CANDIDATES},
        **{name+"_raw_output":[indexed[(q,name,None)]["raw_output"] for q in validation.example_id] for name in CANDIDATES},
        **{name+"_valid":[indexed[(q,name,None)]["valid"] for q in validation.example_id] for name in CANDIDATES}})
    correctness_table = pd.DataFrame({"query_id":validation.example_id,**{f"{s}_correct":correct[s] for s in CANDIDATES},
                                     "successful_strategies":np.column_stack([correct[s] for s in CANDIDATES]).sum(axis=1)})
    features["ambiguity_group"] = [f"Q{g+1}" for g in groups]
    vote_rows = []
    for name,mask in (("vote<=0.5",features.top_label_vote<=.5),
                      ("0.5<vote<=0.8",(features.top_label_vote>.5)&(features.top_label_vote<=.8)),
                      ("vote>0.8",features.top_label_vote>.8)):
        vote_rows.append({"group":name,"n":int(mask.sum()),
                          **{f"{s}_accuracy":float(correct[s][mask].mean()) if mask.any() else None for s in CANDIDATES}})
    run_id = fingerprint({"full":sources["full_run_id"],"analysis_plan":plan})[:16]
    model_revision = config["model"]["revision"]

    def save_table(table,name):
        table = table.copy(); table["run_id"]=run_id; table["model_revision"]=model_revision
        table.to_csv(destination/name,index=False)

    for table,name in ((baseline[baseline.strategy!="zero_shot"],"baseline_metrics.csv"),(seed_table,"random_seed_metrics.csv"),
                       (baseline[baseline.strategy=="zero_shot"],"zero_shot_metrics.csv"),
                       (prediction_table,"query_prediction_matrix.csv"),(correctness_table,"query_correctness_matrix.csv"),
                       (pd.DataFrame(complement["pairwise"]),"strategy_disagreement.csv"),
                       (ambiguity,"ambiguity_analysis.csv"),(correlations,"feature_correlations.csv"),
                       (pd.DataFrame(vote_rows),"top_vote_analysis.csv"),(statistics,"statistical_comparisons.csv"),
                       (features,"query_neighborhood_features.csv")):
        save_table(table,name)
    invalid_rows=[{k:r[k] for k in ("query_id","strategy","random_seed","gold_label","raw_output","generated_tokens")}
                  for r in records if not r["valid"]]
    save_table(pd.DataFrame(invalid_rows,columns=["query_id","strategy","random_seed","gold_label","raw_output","generated_tokens"]),"invalid_outputs.csv")
    for value,name in ((oracle_result,"oracle_analysis.json"),(complement,"complementarity.json"),(cases,"representative_cases.json")):
        write_json(destination/name,{"run_id":run_id,"model_revision":model_revision,**value})
    aggregate_path = destination/"all_predictions.jsonl"
    temporary = aggregate_path.with_suffix(".jsonl.tmp")
    temporary.write_text("",encoding="utf-8")
    for record in sorted(records,key=lambda r:(r["query_id"],r["strategy"],r["random_seed"] or 0)):
        append_record(temporary,{**record,"experiment_run_id":run_id,"checkpoint_revision":model_revision,
                                  "tokenizer_revision":config["model"]["tokenizer_revision"]})
    temporary.replace(aggregate_path)
    from .analysis_figures import create_figures
    figure_names = create_figures(destination/"figures",complement,ambiguity,statistics,run_id=run_id,n=len(validation))
    write_json(destination/"analysis_status.json",{"complete":True,"run_id":run_id,"prediction_count":len(records),
        "figures":figure_names,"controls_hash":sources["controls_hash"],"model_revision":model_revision})
    # Detailed Chinese report is generated separately from these audited numeric artifacts.
    from .full_validation_report import write_report
    write_report(destination,baseline,seed_table,oracle_result,complement,ambiguity,statistics,cases,run_id,config,analysis)
    print(f"Full analysis complete: {len(records)} predictions; best={best_global}; oracle={oracle.mean():.4%}")
    return destination


if __name__ == "__main__":
    run_analysis(load_phase2_config(),load_analysis_config())
