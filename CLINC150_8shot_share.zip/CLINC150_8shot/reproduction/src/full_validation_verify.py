"""Final offline acceptance audit. Never runs inference or reads Official Test labels."""
from __future__ import annotations

import hashlib
import json
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd

from .full_validation_run import load_analysis_config
from .phase2_data import load_phase2_config, load_phase2_inputs
from .utils import ROOT, read_json, write_json


def verify(config,analysis):
    destination = ROOT/analysis["output"]
    status = read_json(destination/"analysis_status.json")
    records = [json.loads(line) for line in (destination/"all_predictions.jsonl").read_text().splitlines()]
    _,frames,_,labels,_,_ = load_phase2_inputs(config)
    ids = set(frames["validation"].example_id)
    assert len(ids)==1003 and len(records)==9027 and status["complete"]
    logical = {(r["query_id"],r["strategy"],r["random_seed"]) for r in records}
    assert len(logical)==len(records)
    variants = [(s,None) for s in ("similar","diverse","balanced","zero_shot")]+[("random",s) for s in (42,43,44,45,46)]
    assert logical=={(q,s,seed) for q in ids for s,seed in variants}
    # Recompute metrics independently from confusion counts, not sklearn helpers.
    seed_metrics = pd.read_csv(destination/"random_seed_metrics.csv")
    table = pd.concat([pd.read_csv(destination/"baseline_metrics.csv"),pd.read_csv(destination/"zero_shot_metrics.csv")])
    for strategy,seed in variants:
        group = [r for r in records if r["strategy"]==strategy and r["random_seed"]==seed]
        correct = sum(r["valid"] and r["predicted_label"]==r["gold_label"] for r in group)
        f1s=[]
        for label in labels:
            tp=sum(r["valid"] and r["gold_label"]==label and r["predicted_label"]==label for r in group)
            fp=sum(r["valid"] and r["gold_label"]!=label and r["predicted_label"]==label for r in group)
            fn=sum(r["gold_label"]==label and (not r["valid"] or r["predicted_label"]!=label) for r in group)
            f1s.append(2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.)
        row = seed_metrics[seed_metrics.seed==seed].iloc[0] if strategy=="random" else table[table.strategy==strategy].iloc[0]
        assert abs(correct/1003-row.accuracy)<1e-12
        assert abs(float(np.mean(f1s))-row.macro_f1)<1e-12
    random = table[table.strategy=="random"].iloc[0]
    assert abs(random.accuracy-seed_metrics.accuracy.mean())<1e-12
    assert abs(random.accuracy_std-seed_metrics.accuracy.std(ddof=0))<1e-12
    indexed={(r["query_id"],r["strategy"],r["random_seed"]):r for r in records}
    query_ids=sorted(ids)
    candidates=("similar","diverse","balanced")
    correct=np.array([[indexed[(q,s,None)]["valid"] and indexed[(q,s,None)]["predicted_label"]==indexed[(q,s,None)]["gold_label"]
                       for s in candidates] for q in query_ids],dtype=bool)
    correctness=pd.read_csv(destination/"query_correctness_matrix.csv").set_index("query_id").loc[query_ids]
    np.testing.assert_array_equal(correct,correctness[[f"{s}_correct" for s in candidates]].to_numpy())
    oracle=read_json(destination/"oracle_analysis.json")
    assert oracle["oracle_correct_count"]==int(correct.any(axis=1).sum())
    assert abs(oracle["oracle_accuracy"]-correct.any(axis=1).mean())<1e-12
    winner_order=("similar","balanced","diverse","random")
    scores=table.set_index("strategy").accuracy.to_dict()
    def best(order):
        maximum=max(scores[s] for s in order)
        return next(s for s in order if maximum-scores[s]<=1e-12)
    assert oracle["global_best_all_four"]==best(winner_order)
    assert oracle["global_best_adaptive_candidates"]==best(winner_order[:3])
    assert abs(oracle["oracle_gain"]-(correct.any(axis=1).mean()-scores[oracle["global_best_adaptive_candidates"]]))<1e-12
    overlap=read_json(destination/"complementarity.json")
    for k in range(4):
        assert overlap["success_counts"][str(k)]==int((correct.sum(axis=1)==k).sum())
    matrix=pd.read_csv(destination/"query_prediction_matrix.csv").set_index("query_id").loc[query_ids]
    for s in candidates:
        actual=matrix[s].astype(object).where(pd.notna(matrix[s]),None).tolist()
        assert actual==[indexed[(q,s,None)]["predicted_label"] for q in query_ids]
    ambiguity=pd.read_csv(destination/"ambiguity_analysis.csv")
    assert int(ambiguity.n.sum())==1003
    features=pd.read_csv(destination/"query_neighborhood_features.csv")
    assert set(features.query_id)==ids and not any("gold" in c for c in features.columns)
    before = read_json(ROOT/config["results"]/"phase1_integrity_before.json")
    changed = [name for name,checksum in before.items() if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=checksum]
    assert not changed, f"Protected Phase 1 artifacts changed: {changed}"
    suites=list(ET.parse(destination/"tests.xml").getroot().iter("testsuite"))
    tests={key:sum(int(s.attrib.get(key,0)) for s in suites) for key in ("tests","failures","errors","skipped")}
    assert tests["failures"]==tests["errors"]==0
    required = ["baseline_metrics.csv","random_seed_metrics.csv","zero_shot_metrics.csv","all_predictions.jsonl",
                "query_prediction_matrix.csv","query_correctness_matrix.csv","strategy_disagreement.csv","oracle_analysis.json",
                "ambiguity_analysis.csv","representative_cases.json","statistical_comparisons.csv","experiment_config.json","summary.md"]
    assert all((destination/name).is_file() for name in required)
    assert all((destination/"figures"/f"{name}.png").is_file() for name in status["figures"])
    assert 10<=len(read_json(destination/"representative_cases.json")["cases"])<=15
    result={"complete":True,"run_id":status["run_id"],"validation_queries":1003,"unique_predictions":len(records),
            "independent_metric_recomputation_passed":True,"missing_predictions":0,"duplicate_logical_predictions":0,
            "phase1_protected_files_unchanged":len(before),"actual_devices":sorted({r["actual_device"] for r in records}),
            "official_test_used_for_evaluation":False,"adaptive_models_trained":False,"tests":tests,
            "artifacts_sha256":{name:hashlib.sha256((destination/name).read_bytes()).hexdigest() for name in required},
            "source_sha256":{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"src").glob("*.py"))}}
    write_json(destination/"verification.json",result)
    print(f"Accepted: 1003 queries, 9027 predictions, {tests['tests']} passing tests; protected Phase 1 unchanged")
    return result


if __name__=="__main__":
    verify(load_phase2_config(),load_analysis_config())
