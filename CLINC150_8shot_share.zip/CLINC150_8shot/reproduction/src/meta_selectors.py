"""Replaceable sklearn/official TabPFN-v2 adapters. No Validation tuning."""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/dsai4207-matplotlib')
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.model_selection import GridSearchCV,StratifiedKFold,cross_val_predict
from sklearn.metrics import accuracy_score,f1_score

class ConstantSelector:
    def __init__(self,strategy=0):self.strategy=strategy
    def fit(self,X,y):return self
    def predict(self,X):return np.full(len(X),self.strategy,dtype=int)
    def predict_proba(self,X):return np.eye(3)[self.predict(X)]

class LogisticSelector:
    def __init__(self,cfg):self.cfg=cfg
    def fit(self,X,y):
        counts=np.bincount(y,minlength=3);positive=counts[counts>0]
        if len(positive)<2 or positive.min()<3:
            self.model=DummyClassifier(strategy='most_frequent').fit(X,y);self.diagnostics={'constant_fallback':True};return self
        folds=min(self.cfg['cv_folds'],int(positive.min()))
        if folds<2:raise ValueError('Too few examples for leakage-free stratified CV')
        cv=StratifiedKFold(folds,shuffle=True,random_state=self.cfg['seed'])
        inner=StratifiedKFold(max(2,folds-1),shuffle=True,random_state=self.cfg['seed'])
        pipeline=Pipeline([('scale',StandardScaler()),('classifier',LogisticRegression(max_iter=2000,random_state=self.cfg['seed']))])
        grid={'classifier__C':self.cfg['logistic_c'],'classifier__class_weight':self.cfg['logistic_class_weight']}
        # Nested OOF: inner selection is performed only inside each outer training fold.
        oof=cross_val_predict(GridSearchCV(pipeline,grid,cv=inner,scoring='f1_macro',n_jobs=1),X,y,cv=cv,n_jobs=1)
        search=GridSearchCV(pipeline,grid,cv=cv,scoring='f1_macro',n_jobs=1).fit(X,y)
        self.model=search.best_estimator_
        self.diagnostics={'nested_oof_accuracy':accuracy_score(y,oof),'nested_oof_macro_f1':f1_score(y,oof,labels=[0,1,2],average='macro',zero_division=0),
                          'best_parameters':search.best_params_,'folds':folds,'validation_used_for_tuning':False}
        return self
    def predict(self,X):return self.model.predict(X).astype(int)
    def predict_proba(self,X):return self.model.predict_proba(X)

class TabPFNV2Selector:
    def __init__(self,cfg,checkpoint,device=None,factory=None):
        self.cfg,self.checkpoint=cfg,checkpoint
        if factory is None:
            from tabpfn import TabPFNClassifier
            from tabpfn.constants import ModelVersion
            factory=TabPFNClassifier.create_default_for_version;version=ModelVersion.V2
        else:version='v2'
        self.model=factory(version,device=device or cfg['tabpfn']['device'],random_state=cfg['seed'],
            model_path=checkpoint['path'],n_estimators=cfg['tabpfn']['n_estimators'])
    def fit(self,X,y):self.model.fit(X,y);return self
    def predict(self,X):return self.model.predict(X).astype(int)
    def predict_proba(self,X):return self.model.predict_proba(X)
