"""Training-only gold continuation scoring; stable cache keys, no Validation targets."""
import argparse, time
from filelock import FileLock
import numpy as np
import pandas as pd
from .meta_features import inputs, config, prepare, STRATEGIES
from .llm_inference import QwenInference
from .retrieval import SemanticRetriever
from .selection import select_demonstrations
from .prompting import build_prompt
from .experiment_cache import append_record, read_records
from .utils import ROOT, fingerprint, read_json, write_json

def choose_target(scores,tolerance=1e-6):
    a=np.asarray(scores,float)
    if a.shape!=(3,) or not np.isfinite(a).all(): raise ValueError('Three finite scores required')
    order=np.sort(a)
    best=next(i for i in (0,2,1) if a.max()-a[i]<=tolerance)
    return best,float(order[-1]-order[-2]),int(np.sum(a.max()-a<=tolerance))

def score(limit=None):
    root=prepare();cfg=config()
    p2,p1,frames,arrays,labels,manifest,index=inputs();p2['model']['device']='mps'
    engine=QwenInference(p2,p1['paths']['hub_cache'])
    if engine.device!='mps':raise RuntimeError('MPS required; no CPU fallback')
    reference=read_json(ROOT/'results/phase2/full_validation/experiment_config.json')['inference']
    assert engine.identity==reference,'Qwen controls differ from Phase 2'
    retriever=SemanticRetriever(frames['demonstration_pool'],arrays['demonstration_pool'],p1['retrieval']['exclude_identical_text'])
    cache=root/'score_cache';cache.mkdir(exist_ok=True)
    log=root/'meta_label_scores.jsonl'
    with FileLock(str(root/'.scoring.lock'),timeout=0):
        records=read_records(log);done={r['cache_key'] for r in records}
        for i,row in frames['meta_training'].iterrows():
            if limit is not None and i>=limit:break
            pool=retriever.retrieve(arrays['meta_training'][i],32,query_id=row.example_id,query_text=row.text)
            for strategy in STRATEGIES:
                demos=select_demonstrations(arrays['meta_training'][i],pool,strategy,8,42,mmr_lambda=.5)['demonstrations']
                prompt=build_prompt(row.text,demos,labels,k=8)
                identity={'query_id':row.example_id,'strategy':strategy,'target_label':row.label_name,'prompt_hash':prompt.prompt_hash,
                          'model':engine.identity,'manifest':manifest['fingerprint'],'scoring':'exact-continuation-no-eos-mean-token-v1'}
                key=fingerprint(identity);path=cache/f'{key}.json'
                if key in done:
                    stored=read_json(path);assert stored['identity']==identity and stored['record']['cache_key']==key
                    continue
                if path.exists():
                    stored=read_json(path);assert stored['identity']==identity
                    result=stored['record']
                else:
                    engine._synchronize();start=time.perf_counter()
                    result=engine.score_label(row.text,demos,row.label_name,labels)
                    engine._synchronize()
                    result.update(query_id=row.example_id,strategy=strategy,cache_key=key,runtime_seconds=time.perf_counter()-start,
                                  model_revision=p2['model']['revision'],device=engine.device)
                    assert np.isfinite(result['mean_log_likelihood']) and result['label_token_count']>0
                    if not records:
                        repeat=engine.score_label(row.text,demos,row.label_name,labels)
                        assert abs(repeat['mean_log_likelihood']-result['mean_log_likelihood'])<1e-5
                        write_json(root/'scoring_smoke.json',{'first':result,'repeat':repeat,'passed':True})
                    write_json(path,{'identity':identity,'record':result})
                append_record(log,result);records.append(result);done.add(key)
            if (i+1)%10==0:print(f'Scored {i+1}/2000 queries ({len(records)} operations)',flush=True)
    build_dataset(root)

def build_dataset(root):
    records=read_records(root/'meta_label_scores.jsonl')
    grouped={}
    for r in records:
        payload=read_json(root/'score_cache'/f"{r['cache_key']}.json")
        if fingerprint(payload['identity'])!=r['cache_key'] or payload['record']!=r:
            raise ValueError('Scoring cache/log mismatch')
        group=grouped.setdefault(r['query_id'],{})
        if r['strategy'] in group:raise ValueError('Duplicate query-strategy score; do not mix experiments')
        group[r['strategy']]=r
    features=pd.read_csv(root/'meta_features_train.csv').set_index('query_id');rows=[]
    for q,group in sorted(grouped.items()):
        if set(group)!=set(STRATEGIES):continue
        scores=[group[s]['mean_log_likelihood'] for s in STRATEGIES]
        target,margin,ties=choose_target(scores,config()['tie_tolerance'])
        rows.append({'query_id':q,**features.loc[q].to_dict(),'gold_intent':group['similar']['target_label'],
                     **{f'{s}_log_likelihood':v for s,v in zip(STRATEGIES,scores)},'target_class':target,'target_strategy':STRATEGIES[target],
                     'score_margin':margin,'tied_strategies':ties,'runtime_seconds':sum(r['runtime_seconds'] for r in group.values()),
                     'model_revision':group['similar']['model_revision'],**{f'{s}_prompt_hash':group[s]['prompt_hash'] for s in STRATEGIES}})
    data=pd.DataFrame(rows);data.to_csv(root/'meta_training_dataset.csv',index=False)
    if len(data):
        write_json(root/'meta_label_diagnostics.json',{'n':len(data),'complete':len(data)==2000,
            'distribution':data.target_strategy.value_counts().to_dict(),'mean_margin':float(data.score_margin.mean()),
            'class_proportions':{s:float(data.target_strategy.eq(s).mean()) for s in STRATEGIES},
            'majority_meta_label_accuracy':float(data.target_strategy.value_counts().max()/len(data)),
            'median_margin':float(data.score_margin.median()),'effectively_tied_queries':int((data.tied_strategies>1).sum()),
            'small_margin_counts':{str(t):int((data.score_margin<=t).sum()) for t in config()['small_margin_thresholds']},
            'tie_tolerance':config()['tie_tolerance'],'tie_order':['similar','balanced','diverse'],
            'target_caution':'Gold-label likelihood argmax need not match greedy 0-1 correctness; Validation targets are not constructed.'})
    print('Complete meta-label rows:',len(data),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int);args=p.parse_args();score(args.limit)
