"""Read-only Phase 1 artifacts. Never open the official test CSV or test embeddings."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import yaml

from .embeddings import load_cache
from .prepare_data import frame_fingerprint
from .utils import ROOT, fingerprint, load_config, read_json


def load_phase2_config(path="configs/phase2.yaml"):
    path = ROOT / path
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    if config["k"] != 8 or config["prompt"]["ordering"] != "descending_query_similarity_then_id":
        raise ValueError("Phase 2 controls require k=8 and common similarity ordering")
    generation = config["generation"]
    if generation["do_sample"] is not False or generation["num_beams"] != 1 or generation["max_new_tokens"] < 1:
        raise ValueError("Phase 2 requires deterministic greedy generation")
    if config["evaluation"]["tie_break_order"] != ["similar", "balanced", "diverse", "random"]:
        raise ValueError("Tie-breaking is preregistered: similar, balanced, diverse, random")
    return config


def load_phase2_inputs(config):
    phase1 = load_config(config["phase1_config"])
    root = Path(phase1["paths"]["splits"])
    manifest = read_json(root / "split_manifest.json")
    if fingerprint({k: v for k, v in manifest.items() if k != "fingerprint"}) != manifest["fingerprint"]:
        raise ValueError("Phase 1 manifest integrity failed")
    if (manifest["requested_revision"] != phase1["dataset"]["revision"] or
        manifest["dataset"] != phase1["dataset"]["name"] or manifest["seed"] != phase1["seed"]):
        raise ValueError("Phase 1 source settings changed")
    mapping = read_json(root / "label_mapping.json")
    if fingerprint(mapping) != manifest["label_mapping_fingerprint"]:
        raise ValueError("Authoritative label mapping integrity failed")
    labels = [mapping["id_to_label"][str(i)] for i in range(len(mapping["id_to_label"]))]
    if len(labels) != 77 or len(set(labels)) != 77:
        raise ValueError("Banking77 requires 77 distinct official labels")
    if phase1["retrieval"]["candidate_pool_size"] != 32:
        raise ValueError("Phase 1 Top-32 control changed")
    if config["evaluation"]["random_seeds"] != phase1["selection"]["random_seeds"]:
        raise ValueError("Random seeds must match Phase 1")
    for key in ("pilot_a_random_seeds", "pilot_b_random_seeds"):
        if not config["evaluation"][key] or not set(config["evaluation"][key]) <= set(config["evaluation"]["random_seeds"]):
            raise ValueError("Pilot Random seeds must be predefined Phase 1 seeds")
    frames, arrays = {}, {}
    cache_root = Path(phase1["paths"]["embeddings"])
    index = read_json(cache_root / "index.json")
    if index["dataset_manifest"] != manifest["fingerprint"]:
        raise ValueError("Frozen embeddings reference different data")
    for key, value in phase1["embedding"].items():
        if index["encoder"][key] != value:
            raise ValueError("Phase 1 encoder settings changed")
    for name in ("demonstration_pool", "validation"):
        frame = pd.read_csv(root / f"{name}.csv", keep_default_na=False)
        if (len(frame) != phase1["dataset"]["sizes"][name] or not frame.source_split.eq("train").all() or
            not frame.partition.eq(name).all() or not frame.example_id.is_unique or
            frame_fingerprint(frame) != manifest["splits"][name]["fingerprint"]):
            raise ValueError(f"Frozen {name} data integrity failed")
        if not frame.label_name.eq(frame.label.map(dict(enumerate(labels)))).all():
            raise ValueError("Source labels disagree with official mapping")
        key = index["keys"][name]
        identity = read_json(cache_root / f"{name}-{key}.json")["identity"]
        if (identity["dataset_manifest"] != manifest["fingerprint"] or identity["split"] != name or
            identity["data_fingerprint"] != frame_fingerprint(frame) or
            identity["encoder"] != index["encoder"] or identity["resolved_model_revision"] != index["resolved_revision"]):
            raise ValueError("Frozen cache provenance mismatch")
        # Verify original software provenance without regenerating vectors on new GPU hosts.
        arrays[name] = load_cache(cache_root, key, identity, frame)
        frames[name] = frame
    if set(frames["validation"].example_id) & set(frames["demonstration_pool"].example_id):
        raise ValueError("Query/candidate ID overlap")
    return phase1, frames, arrays, labels, manifest, index


def stratified_query_order(validation, seed=42):
    """Nested, class-balanced stratified prefixes; <77 cannot cover all classes.

    Shuffle each class with one local RNG, then take one row per class per round.
    Class order is reshuffled each round, independent of strategy and predictions.
    """
    rng = np.random.default_rng(seed)
    buckets = {int(label): list(rng.permutation(group.index.to_numpy()))
               for label, group in validation.groupby("label", sort=True)}
    order = []
    while any(buckets.values()):
        for label in rng.permutation(sorted(buckets)):
            if buckets[label]:
                order.append(int(buckets[label].pop()))
    return order
