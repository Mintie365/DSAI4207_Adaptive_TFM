"""Pure selectors: label metadata is carried to output, never used to score candidates."""
from __future__ import annotations

import hashlib

import numpy as np

from .utils import unit_vectors

STRATEGIES = ("random", "similar", "diverse", "balanced")


def _validate(query_embedding, candidate_pool, k):
    pool = sorted(candidate_pool, key=lambda d: d.example_id)
    if type(k) is not int or k <= 0 or len(pool) < k:
        raise ValueError("k must be positive and no larger than the candidate pool")
    if len({d.example_id for d in pool}) != len(pool):
        raise ValueError("Candidate IDs must be distinct")
    query = unit_vectors(query_embedding)
    vectors = unit_vectors(np.stack([d.embedding for d in pool]))
    if query.ndim != 1 or vectors.shape[1] != query.shape[0]:
        raise ValueError("Query/candidate embedding dimension mismatch")
    scores = vectors @ query
    if not np.allclose(scores, [d.similarity for d in pool], atol=1e-5):
        raise ValueError("Candidate scores do not match this query")
    # Stored retrieval scores keep Similar exactly aligned with retrieval ranking.
    return pool, vectors, np.array([d.similarity for d in pool])


def random_selection(query_embedding, candidate_pool, k=8, seed=42):
    pool, _, _ = _validate(query_embedding, candidate_pool, k)
    # SHA-256 avoids Python's randomized hash and global RNG/order dependencies.
    query = np.asarray(unit_vectors(query_embedding), dtype="<f4")
    payload = str(seed).encode() + b"\0" + query.tobytes()
    local_seed = int.from_bytes(hashlib.sha256(payload).digest()[:16], "little")
    indices = np.random.default_rng(local_seed).choice(len(pool), size=k, replace=False)
    return [pool[i] for i in indices]


def similar_selection(query_embedding, candidate_pool, k=8, seed=42):
    pool, _, scores = _validate(query_embedding, candidate_pool, k)
    return [pool[i] for i in sorted(range(len(pool)), key=lambda i: (-scores[i], pool[i].example_id))[:k]]


def _greedy(query_embedding, candidate_pool, k, balance):
    pool, vectors, relevance = _validate(query_embedding, candidate_pool, k)
    pairwise = vectors @ vectors.T
    remaining = list(range(len(pool)))  # Lexicographic ID order resolves exact score ties.
    first = max(remaining, key=lambda i: relevance[i])
    selected = [first]
    remaining.remove(first)
    while len(selected) < k:
        def score(i):
            redundancy = float(np.max(pairwise[i, selected]))
            if balance is None:
                return 1.0 - redundancy  # max min cosine distance to the selected set
            return balance * relevance[i] - (1.0 - balance) * redundancy
        best = max(remaining, key=score)
        selected.append(best)
        remaining.remove(best)
    return [pool[i] for i in selected]


def diverse_selection(query_embedding, candidate_pool, k=8, seed=42):
    return _greedy(query_embedding, candidate_pool, k, None)


def balanced_selection(query_embedding, candidate_pool, k=8, seed=42, mmr_lambda=0.5):
    if not 0 <= mmr_lambda <= 1:
        raise ValueError("MMR lambda must lie in [0, 1]")
    return _greedy(query_embedding, candidate_pool, k, mmr_lambda)


def select_demonstrations(query_embedding, candidate_pool, strategy="similar", k=8, seed=42,
                          *, mmr_lambda=0.5, query_id=None, query_text=None):
    selectors = {"random": random_selection, "similar": similar_selection,
                 "diverse": diverse_selection, "balanced": balanced_selection}
    if strategy not in selectors:
        raise ValueError(f"Unknown strategy: {strategy}")
    kwargs = {"mmr_lambda": mmr_lambda} if strategy == "balanced" else {}
    selected = selectors[strategy](query_embedding, candidate_pool, k=k, seed=seed, **kwargs)
    return {"schema_version": 1, "query_id": query_id, "query_text": query_text,
            "strategy": strategy, "k": k, "candidate_pool_size": len(candidate_pool),
            "seed": seed, "mmr_lambda": mmr_lambda if strategy == "balanced" else None,
            "demonstrations": [candidate.as_dict() for candidate in selected]}
