"""Staged, resumable fixed-strategy validation. No test-set evaluation or TFM training."""
from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
import platform
import time

from filelock import FileLock
import numpy as np
import pandas as pd

from .evaluation import baseline_metrics
from .experiment_cache import PredictionCache, append_record, inference_key, read_records
from .phase2_data import load_phase2_config, load_phase2_inputs, stratified_query_order
from .prompting import build_prompt
from .retrieval import SemanticRetriever
from .selection import select_demonstrations
from .utils import ROOT, fingerprint, load_config, read_json, versions, write_json

STAGES = ("pilot-a", "pilot-b", "full")


def stage_plan(config, stage, validation, query_count=None):
    spec = config["evaluation"]
    if stage == "pilot-a":
        count = spec["pilot_a_queries"] if query_count is None else query_count
        if not 20 <= count <= 50:
            raise ValueError("Pilot A requires 20–50 validation queries")
        seeds = spec["pilot_a_random_seeds"]
    elif stage == "pilot-b":
        count = spec["pilot_b_queries"] if query_count is None else query_count
        if not 100 <= count <= 200:
            raise ValueError("Pilot B requires 100–200 validation queries")
        seeds = spec["pilot_b_random_seeds"]
    elif stage == "full":
        if query_count is not None:
            raise ValueError("Full validation cannot be a subset")
        count, seeds = len(validation), spec["random_seeds"]
    else:
        raise ValueError("Unknown stage")
    if count > len(validation):
        raise ValueError("Not enough validation queries")
    order = stratified_query_order(validation, config["seed"])[:count]
    return order, list(seeds)


def _stage_gate(config, stage, output, controls_hash):
    if stage == "pilot-a":
        return
    previous = "pilot-a" if stage == "pilot-b" else "pilot-b"
    pointer = output / f"latest_{previous.replace('-', '_')}.json"
    if not pointer.exists():
        raise ValueError(f"Complete {previous} and inspect its outputs before expanding")
    prior = read_json(output / read_json(pointer)["run_directory"] / "status.json")
    if not prior["complete"] or prior["controls_hash"] != controls_hash or not prior["consistency_passed"]:
        raise ValueError("Previous pilot is incomplete or used different experimental controls")
    if prior["max_invalid_rate"] > .10:
        raise ValueError("Previous pilot has >10% invalid outputs; inspect correctness before expansion")


def _save_summary(directory, stage, records, labels, query_ids, seeds, controls_hash,
                  inference_identity, consistency, new_calls, cache_hits, elapsed, stop_reason):
    metrics = baseline_metrics(records, labels, query_ids, seeds, full_validation=stage == "full")
    write_json(directory / "metrics.json", metrics)
    pd.DataFrame(metrics["baselines"]).to_csv(directory / "baseline_metrics.csv", index=False)
    pd.DataFrame(metrics["random_seeds"]).to_csv(directory / "random_seed_metrics.csv", index=False)
    times = [r["runtime_seconds"] for r in records]
    runtime = {"session_wall_seconds": elapsed, "new_inference_calls": new_calls,
               "cache_hits_this_session": cache_hits,
               "mean_observed_inference_seconds": float(np.mean(times)) if times else None,
               "sum_recorded_inference_seconds": float(sum(times)),
               "projected_full_8024_calls_seconds": float(np.mean(times) * 1003 * 8) if times else None,
               "max_process_peak_rss_bytes": max((r["memory"].get("process_peak_rss_bytes", 0) for r in records), default=0),
               "max_mps_observed_allocated_bytes": max((r["memory"].get("mps_current_allocated_bytes", 0) for r in records), default=0)}
    write_json(directory / "runtime.json", runtime)
    rates = [r["invalid_rate"] for r in metrics["baselines"] if r["invalid_rate"] is not None]
    status = {"stage": stage, "complete": metrics["complete"], "stop_reason": stop_reason,
              "controls_hash": controls_hash, "consistency_passed": consistency,
              "observed_records": len(records), "expected_records": len(query_ids) * (3 + len(seeds)),
              "max_invalid_rate": max(rates, default=0), "device": inference_identity["device"]}
    write_json(directory / "status.json", status)
    lines = [f"# Phase 2 {stage} 实际结果", "", f"状态：{'完成' if metrics['complete'] else '未完成'}；{len(query_ids)} 条 validation 查询；实际记录 {len(records)} 条。",
             f"设备：`{inference_identity['device']}`；精度：`{inference_identity.get('precision', 'mock')}`。", "",
             "| Strategy | Accuracy | Macro-F1（全部77类） | Invalid Rate |", "|---|---:|---:|---:|"]
    for row in metrics["baselines"]:
        formatted = [f"{row[k]:.4f}" if row[k] is not None else "未执行" for k in ("accuracy", "macro_f1", "invalid_rate")]
        lines.append(f"| {row['strategy']} | {' | '.join(formatted)} |")
    lines.extend(["", f"Random 实际 seeds：{seeds}；CSV 同时保存各指标的均值和总体标准差（ddof=0）。",
                  "Pilot A 不足77条时不可能覆盖全部77类。上表 Macro-F1 固定对77类求平均，未覆盖类记0；",
                  "metrics.json 另报 macro_f1_present_gold，仅用于解释 pilot。未完成运行的指标只是已记录部分，不可跨策略比较。", "",
                  f"本次进程耗时 {elapsed:.2f}s；新推理 {new_calls} 次；缓存命中 {cache_hits} 次。",
                  f"单次实际平均推理：{runtime['mean_observed_inference_seconds']}s。",
                  f"基于这些调用的 full validation 时间投影：{runtime['projected_full_8024_calls_seconds']}s（仅耗时估算，不是实测完整实验）。",
                  f"最大进程 RSS：{runtime['max_process_peak_rss_bytes']} bytes；MPS 观测到的最大当前分配：{runtime['max_mps_observed_allocated_bytes']} bytes。",
                  "RSS 是进程历史峰值；MPS 分配是在每次推理后采样，不等于 GPU 瞬时峰值。", "",
                  f"独立重复生成一致性检查：{consistency}。停止原因：{stop_reason}。", "",
                  f"Global-Best 状态：{metrics['global_best_status']}。",
                  f"四种固定策略最佳：{metrics['global_best_all_four']}；三种 adaptive candidate 最佳：{metrics['global_best_adaptive_candidates']}。",
                  "只有完整1003条验证及Random五个seed全部完成后才选最佳；Accuracy差值≤1e-12视为数值并列，按 Similar > Balanced > Diverse > Random。",
                  "未使用官方 test；未训练元选择器；未在评估中调用 gold-label scoring。", ""])
    (directory / "summary.md").write_text("\n".join(lines), encoding="utf-8")
    return status


def run_experiment(config, stage="pilot-a", *, query_count=None, inference=None,
                   allow_cpu_pilot=False, max_new_predictions=None):
    from .llm_inference import QwenInference, automatic_device
    start = time.perf_counter()
    phase1, frames, arrays, labels, manifest, embedding_index = load_phase2_inputs(config)
    order, random_seeds = stage_plan(config, stage, frames["validation"], query_count)
    device = inference.device if inference is not None else automatic_device(config["model"]["device"])
    if device == "cpu" and (not allow_cpu_pilot or stage != "pilot-a"):
        raise RuntimeError("No accelerator is accessible. Run in ordinary macOS Terminal with --device mps. CPU is allowed only for an explicitly requested Pilot A; full CPU experiments are blocked.")
    output = ROOT / config["results"]
    output.mkdir(parents=True, exist_ok=True)
    if not (output / "retrieval_diagnostics.json").exists():
        raise ValueError("Run retrieval diagnostics before LLM inference")
    diagnostics = read_json(output / "retrieval_diagnostics.json")
    if diagnostics["dataset_manifest"] != manifest["fingerprint"] or diagnostics["query_count"] != len(frames["validation"]):
        raise ValueError("Retrieval diagnostics reference different validation data")
    engine = inference if inference is not None else QwenInference(config, phase1["paths"]["hub_cache"])
    controls = {"dataset_manifest": manifest["fingerprint"], "embedding_keys": embedding_index["keys"],
                "retrieval": phase1["retrieval"], "selection": phase1["selection"], "k": config["k"],
                "prompt": config["prompt"], "inference": engine.identity}
    controls_hash = fingerprint(controls)
    _stage_gate(config, stage, output, controls_hash)
    query_ids = [str(frames["validation"].iloc[i].example_id) for i in order]
    experiment = {"controls": controls, "stage": stage, "query_ids": query_ids, "random_seeds": random_seeds}
    run_id = fingerprint(experiment)[:16]
    directory = output / f"{stage}_{run_id}"
    directory.mkdir(parents=True, exist_ok=True)
    with FileLock(str(directory / ".writer.lock"), timeout=0):
        if not (directory / "experiment_config.json").exists():
            write_json(directory / "experiment_config.json", {"phase2": config, "phase1": phase1,
                                                               "experiment": experiment, "run_id": run_id})
            write_json(directory / "environment.json", {"platform": platform.platform(), "machine": platform.machine(),
                                                         "software": versions(), "inference": engine.identity})
        write_json(directory / "query_plan.json", {"query_ids": query_ids,
                   "gold_label_use": "Stratified sampling only; never passed to prediction/selection. Evaluated after inference.",
                   "represented_classes": int(frames["validation"].iloc[order].label.nunique())})
        write_json(output / f"latest_{stage.replace('-', '_')}.json", {"run_directory": directory.name})
        prediction_path = directory / ("validation_predictions.jsonl" if stage == "full" else "pilot_predictions.jsonl")
        records = read_records(prediction_path)
        completed = {r["cache_key"]: r for r in records}
        cache = PredictionCache(output / "inference_cache")
        retriever = SemanticRetriever(frames["demonstration_pool"], arrays["demonstration_pool"],
                                      phase1["retrieval"]["exclude_identical_text"])
        new_calls, hits, stop = 0, 0, "all_planned_predictions_completed"
        consistency_path = directory / "consistency.json"
        consistency = read_json(consistency_path)["passed"] if consistency_path.exists() else False
        try:
            for position in order:
                query_row = frames["validation"].iloc[position]
                query_id, query_text = str(query_row.example_id), str(query_row.text)
                vector = arrays["validation"][position]
                pool = retriever.retrieve(vector, 32, query_id=query_id, query_text=query_text)
                variants = [("similar", None), ("diverse", None), ("balanced", None)] + [("random", seed) for seed in random_seeds]
                for strategy, random_seed in variants:
                    selection = select_demonstrations(vector, pool, strategy, config["k"],
                        config["seed"] if random_seed is None else random_seed,
                        mmr_lambda=phase1["selection"]["mmr_lambda"], query_id=query_id, query_text=query_text)
                    prompt = build_prompt(query_text, selection["demonstrations"], labels,
                                          k=config["k"], version=config["prompt"]["version"])
                    batch, rendered = engine.prepare(prompt)
                    token_ids = batch["input_ids"].detach().cpu().tolist()
                    identity = {"query_id": query_id, "query_text": query_text, "strategy": strategy,
                                "random_seed": random_seed, "demonstration_ids": prompt.demonstration_ids,
                                "prompt_hash": prompt.prompt_hash, "template_hash": prompt.template_hash,
                                "token_ids_hash": fingerprint(token_ids), "controls_hash": controls_hash}
                    key = inference_key(identity)
                    if key in completed:
                        cached = cache.get(identity)
                        if cached is None or any(cached[k] != completed[key][k] for k in ("raw_output", "predicted_label", "valid")):
                            raise ValueError("Evaluation records disagree with inference cache")
                        hits += 1
                        continue
                    if max_new_predictions is not None and new_calls >= max_new_predictions:
                        stop = "requested_incremental_call_limit"
                        raise StopIteration
                    if time.perf_counter() - start >= config["evaluation"]["max_stage_seconds"]:
                        stop = "session_wall_time_limit"
                        raise StopIteration
                    prediction = cache.get(identity)
                    cache_hit = prediction is not None
                    if prediction is None:
                        prediction = engine.predict_prepared(prompt, labels, batch)
                        new_calls += 1
                    else:
                        hits += 1
                    if not consistency:
                        repeated = engine.predict_prepared(prompt, labels, batch)
                        consistency = (prediction["raw_output"] == repeated["raw_output"] and
                                       prediction["predicted_label"] == repeated["predicted_label"])
                        write_json(consistency_path, {"passed": consistency, "query_id": query_id,
                            "first_raw_output": prediction["raw_output"], "repeat_raw_output": repeated["raw_output"],
                            "first_seconds": prediction["runtime_seconds"], "repeat_seconds": repeated["runtime_seconds"]})
                        if not consistency:
                            raise RuntimeError("Greedy repeat consistency check failed")
                    if not cache_hit:
                        cache.put(identity, prediction)
                    # Gold is first accessed for this prediction AFTER the engine returns.
                    record = {**prediction, "cache_key": key, "query_id": query_id,
                              "gold_label": str(query_row.label_name), "strategy": strategy,
                              "random_seed": random_seed, "demonstration_ids": prompt.demonstration_ids,
                              "candidate_ids": [c.example_id for c in pool], "cache_hit": cache_hit,
                              "actual_device": engine.device, "controls_hash": controls_hash}
                    append_record(prediction_path, record)
                    records.append(record)
                    completed[key] = record
                    if len(records) <= 4:
                        write_json(directory / f"example_prompt_{strategy}.json", {"query_id": query_id,
                            "messages": prompt.messages, "rendered_chat_prompt": rendered,
                            "demonstration_ids": prompt.demonstration_ids, "prompt_tokens": prediction["prompt_tokens"]})
                    print(f"[{stage}] {len(records)}/{len(order)*(3+len(random_seeds))} {query_id} {strategy}"
                          f" seed={random_seed} valid={prediction['valid']} {prediction['runtime_seconds']:.3f}s device={engine.device}", flush=True)
        except (StopIteration, KeyboardInterrupt):
            if stop == "all_planned_predictions_completed":
                stop = "user_interrupt"
        except Exception as error:
            stop = f"error: {type(error).__name__}: {error}"
            append_record(directory / "errors.jsonl", {"error": stop, "completed_predictions": len(records)})
            _save_summary(directory, stage, records, labels, query_ids, random_seeds, controls_hash,
                          engine.identity, consistency, new_calls, hits, time.perf_counter()-start, stop)
            raise
        status = _save_summary(directory, stage, records, labels, query_ids, random_seeds, controls_hash,
                               engine.identity, consistency, new_calls, hits, time.perf_counter()-start, stop)
    print(f"Results: {directory}; complete={status['complete']}", flush=True)
    return directory, status


def main():
    parser = argparse.ArgumentParser(description="Phase 2 fixed LLM baselines; staged validation only")
    parser.add_argument("--config", default="configs/phase2.yaml")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("diagnostics")
    commands.add_parser("download-model")
    run = commands.add_parser("run")
    run.add_argument("--stage", choices=STAGES, default="pilot-a")
    run.add_argument("--queries", type=int)
    run.add_argument("--device", choices=("auto", "mps", "cuda", "cpu"))
    run.add_argument("--allow-cpu-pilot", action="store_true")
    run.add_argument("--max-new-predictions", type=int)
    args = parser.parse_args()
    config = load_phase2_config(args.config)
    if args.command == "diagnostics":
        from .retrieval_diagnostics import run_diagnostics
        run_diagnostics(config)
    elif args.command == "download-model":
        from huggingface_hub import snapshot_download
        phase1 = load_config(config["phase1_config"])
        for revision in set((config["model"]["revision"], config["model"]["tokenizer_revision"])):
            snapshot_download(config["model"]["checkpoint"], revision=revision,
                              cache_dir=phase1["paths"]["hub_cache"],
                              allow_patterns=["*.json", "*.safetensors", "merges.txt", "vocab.json", "tokenizer*"])
    else:
        config = deepcopy(config)
        if args.device:
            config["model"]["device"] = args.device
        run_experiment(config, args.stage, query_count=args.queries, allow_cpu_pilot=args.allow_cpu_pilot,
                       max_new_predictions=args.max_new_predictions)


if __name__ == "__main__":
    main()
