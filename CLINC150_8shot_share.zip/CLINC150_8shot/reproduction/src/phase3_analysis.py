"""Downstream accuracy is evaluated only by joining immutable Phase 2 predictions."""
import hashlib,json,os
os.environ.setdefault('MPLCONFIGDIR','/tmp/dsai4207-matplotlib')
import numpy as np,pandas as pd
from .meta_features import config,inputs,STRATEGIES
from .adaptive_evaluation import evaluate_strategy_choices
from .strategy_analysis import bootstrap_means,exact_mcnemar,ambiguity_groups
from .utils import ROOT,read_json,write_json

def analyze():
    cfg=config();root=ROOT/cfg['output'];p2,p1,frames,arrays,labels,manifest,index=inputs()
    phase2=ROOT/'results/phase2/full_validation'
    records=[json.loads(s) for s in (phase2/'all_predictions.jsonl').read_text().splitlines()]
    features=pd.read_csv(root/'meta_features_validation.csv').sort_values('query_id');ids=features.query_id.tolist()
    baseline=read_json(phase2/'oracle_analysis.json')
    metrics=[];predictions={};correctness={};group_rows=[];switch_rows=[]
    choices_by_method={'always_similar':np.zeros(len(ids),int),'always_diverse':np.ones(len(ids),int),
                       'always_balanced':np.full(len(ids),2,int)}
    for method in ('logistic_regression','tabpfn_v2'):
        path=root/'predictions'/f'{method}_validation.csv'
        if path.exists():
            df=pd.read_csv(path).set_index('query_id')
            assert set(df.index)==set(ids) and df.index.is_unique
            choices_by_method[method]=df.loc[ids].strategy_class.to_numpy(int)
    cutpoints=read_json(phase2/'analysis_plan.json')['entropy_cutpoints_bits']
    groups=ambiguity_groups(features.entropy_bits,cutpoints)
    for method,choices in choices_by_method.items():
        measured,correct,similar,oracle=evaluate_strategy_choices(ids,choices,records,labels)
        assert abs(oracle.mean()-baseline['oracle_accuracy'])<1e-12
        assert measured['recoverable_similar_errors']==20
        metadata_path=root/'models'/f'{method}_metadata.json'
        measured.update(method=method,inference_seconds=read_json(metadata_path)['validation_prediction_seconds'] if metadata_path.exists() else 0.)
        metrics.append({k:v for k,v in measured.items() if k!='selection_distribution'})
        predictions[method]=choices;correctness[method]=correct
        switch_rows.append({'method':method,**{k:measured[k] for k in ('beneficial','harmful','neutral_switches','switch_rate','rescue_rate')},
                            **measured['selection_distribution'],'helped_fraction':measured['beneficial']/len(ids),'harmed_fraction':measured['harmful']/len(ids)})
        for g in range(4):
            mask=groups==g
            group_rows.append({'method':method,'group':f'Q{g+1}','n':int(mask.sum()),'accuracy':float(correct[mask].mean()),
                               'similar_accuracy':float(similar[mask].mean()),'oracle_accuracy':float(oracle[mask].mean()),
                               'adaptive_gain':float(correct[mask].mean()-similar[mask].mean()),'switch_rate':float((choices[mask]!=0).mean())})
    correctness['oracle']=oracle
    names=list(correctness);samples=bootstrap_means(np.column_stack([correctness[s] for s in names]),cfg['bootstrap_replicates'],cfg['seed'])
    stats=[]
    for a,b in [('logistic_regression','always_similar'),('tabpfn_v2','always_similar'),('tabpfn_v2','logistic_regression'),('oracle','logistic_regression'),('oracle','tabpfn_v2')]:
        if a not in names or b not in names:continue
        diff=samples[:,names.index(a)]-samples[:,names.index(b)];lo,hi=np.quantile(diff,[.025,.975])
        stats.append({'left':a,'right':b,'accuracy_difference':float(correctness[a].mean()-correctness[b].mean()),'ci_low':lo,'ci_high':hi,
                      **exact_mcnemar(correctness[a],correctness[b]),'replicates':cfg['bootstrap_replicates'],'seed':cfg['seed']})
    out=root/'analysis';out.mkdir(exist_ok=True)
    table=pd.DataFrame(metrics);table.to_csv(out/'comparison_metrics.csv',index=False)
    switches=pd.DataFrame(switch_rows);switches.to_csv(out/'switching_analysis.csv',index=False)
    groups_table=pd.DataFrame(group_rows);groups_table.to_csv(out/'ambiguity_analysis.csv',index=False)
    pd.DataFrame(stats).to_csv(out/'statistical_comparisons.csv',index=False)
    target_diagnostics=read_json(root/'meta_label_diagnostics.json')
    score_records=[json.loads(s) for s in (root/'meta_label_scores.jsonl').read_text().splitlines()]
    score_seconds=sum(r['runtime_seconds'] for r in score_records)
    lines=['# Phase 3：似然元标签与自适应选择实验','',
           '## A. 实验设置','',f"Meta-training=2000，Validation=1003，特征维数=4；映射0=Similar、1=Diverse、2=Balanced。",
           f"实际6000条评分记录，缓存保留的评分计时合计{score_seconds:.2f}秒（{score_seconds/60:.2f}分钟），不含模型载入；smoke首次评分另做一次一致性重复。设备为Apple M5 MPS，Qwen FP16，与TabPFN分进程执行。",
           '固定阶段二Qwen checkpoint、tokenizer、ICL模板、greedy设置；仅meta_training gold作为teacher-forced target，不进入检索或特征。',
           '评分不含prompt/padding/EOS，按目标label token数归一化。三个策略使用相同Top-32及k=8。',
           f"TabPFN library=9.2.0，显式ModelVersion.V2，官方checkpoint见tabpfn_checkpoint.json，ensemble=4，MPS。fit是对预训练分类器的任务适配，未预训练TFM或微调Qwen。",'',
           '## B. 元标签分布与不确定性','',f"生成标签数：{target_diagnostics['n']}；分布：{target_diagnostics['distribution']}。",
           f"类别比例：{target_diagnostics.get('class_proportions')}；多数元标签基线Accuracy={target_diagnostics.get('majority_meta_label_accuracy')}（不等于Always-Similar）。",
           f"margin均值={target_diagnostics['mean_margin']:.6g}，中位数={target_diagnostics['median_margin']:.6g}；有效并列query={target_diagnostics['effectively_tied_queries']}。",
           f"小margin计数：{target_diagnostics['small_margin_counts']}。近似并列容差1e-6，优先Similar→Balanced→Diverse。",
           '最高gold-label似然不等价于最优greedy 0–1 Accuracy；大量低margin标签可能噪声较大。本阶段不生成Validation似然标签，也没有根据Validation表现改变主目标。','',
           '## C. 元选择器内部评估','']
    for method in ('logistic_regression','tabpfn_v2'):
        path=root/'models'/f'{method}_metadata.json'
        if path.exists():lines.append(f"- {method}：`{read_json(path)}`")
        else:lines.append(f'- {method}：未执行成功，不报告虚构结果。')
    lines+=['','Logistic Regression使用仅在Meta-training内拟合的Scaler，嵌套分层CV选择C与class_weight；报告nested OOF。TabPFN固定4个ensemble，内部20%分层holdout为描述性评价，不按Validation调参。','',
            '## D. 下游Validation结果','','| Method | Accuracy | Macro-F1 (77) | Correct / Incorrect | Gain vs Similar (pp) | Oracle gap (pp) |','|---|---:|---:|---:|---:|---:|']
    for r in metrics:lines.append(f"| {r['method']} | {r['accuracy']:.3%} | {r['macro_f1']:.5f} | {r['correct_count']} / {r['incorrect_count']} | {r['gain_vs_similar']*100:.3f} | {r['oracle_gap']*100:.3f} |")
    lines+=[f"| Oracle（非部署模型） | {oracle.mean():.3%} | — | {oracle.sum()} / {(~oracle).sum()} | {(oracle.mean()-similar.mean())*100:.3f} | 0 |",'',
            '只按Query ID从阶段二冻结预测矩阵取所选答案，没有重跑Validation Qwen。Oracle越界、缺失或重复ID会触发校验。','',
            '## E. 切换收益与代价','','| Method | Beneficial | Harmful | Neutral switches | Switch rate | Rescue rate of 20 |','|---|---:|---:|---:|---:|---:|']
    for r in switch_rows:lines.append(f"| {r['method']} | {r['beneficial']} | {r['harmful']} | {r['neutral_switches']} | {r['switch_rate']:.3%} | {r['rescue_rate']:.3%} |")
    lines+=['','已验证gain=(beneficial−harmful)/1003。策略选择数见switching_analysis.csv，不将仅仅切换策略算作改善。','',
            '## F. 高歧义分析','',f'沿用Phase 2切点：{cutpoints}；不重新估计或按结果调组。','',
            '| Method | Group | n | Accuracy | Similar | Oracle | Gain (pp) | Switch rate |','|---|---|---:|---:|---:|---:|---:|---:|']
    for r in group_rows:lines.append(f"| {r['method']} | {r['group']} | {r['n']} | {r['accuracy']:.3%} | {r['similar_accuracy']:.3%} | {r['oracle_accuracy']:.3%} | {r['adaptive_gain']*100:.3f} | {r['switch_rate']:.3%} |")
    lines+=['','## G. 配对统计与研究结论','','| Comparison | Difference (pp) | Paired bootstrap 95% CI (pp) | Exact McNemar p |','|---|---:|---:|---:|']
    for r in stats:lines.append(f"| {r['left']} − {r['right']} | {r['accuracy_difference']*100:.3f} | [{r['ci_low']*100:.3f}, {r['ci_high']*100:.3f}] | {r['mcnemar_exact_p']:.5g} |")
    for r in metrics:
        if r['method'] in ('logistic_regression','tabpfn_v2'):
            fraction=r['gain_vs_similar']/(oracle.mean()-similar.mean())
            lines.append(f"- {r['method']}：净变化{r['gain_vs_similar']*100:.3f}pp，实现Oracle余量的{fraction:.1%}（负值表示倒退）；选择分布`{next(x for x in switch_rows if x['method']==r['method'])}`。")
    if 'tabpfn_v2' in predictions:
        tab=next(r for r in metrics if r['method']=='tabpfn_v2')
        lr=next(r for r in metrics if r['method']=='logistic_regression')
        lines += ['', '### 对研究问题的直接回答', '',
            f"1. TabPFN相对Similar的实测增益为{tab['gain_vs_similar']*100:.3f}pp；没有观察到下游改善。" if tab['gain_vs_similar']<=0 else f"1. TabPFN数值增益{tab['gain_vs_similar']*100:.3f}pp，是否可靠须以上述配对区间为准。",
            f"2. TabPFN与LR的Accuracy差为{(tab['accuracy']-lr['accuracy'])*100:.3f}pp；不能仅凭数值领先声称统计优势。",
            f"3–4. TabPFN选择分布：{next(r for r in switch_rows if r['method']=='tabpfn_v2')['similar']} Similar / {next(r for r in switch_rows if r['method']=='tabpfn_v2')['diverse']} Diverse / {next(r for r in switch_rows if r['method']=='tabpfn_v2')['balanced']} Balanced。" + ('已塌缩为Always-Similar，虽然确实运行了官方v2的fit/predict，并非人为替换为常量模型。' if tab['switch_rate']==0 else '未完全塌缩。'),
            '5. 内部元标签Accuracy与下游正确性不是同一指标；本实验未构造Validation似然元标签，因此不报告未测量的相关系数。内部holdout结果不能直接证明似然目标与greedy正确性一致。',
            f"6. TabPFN实现Oracle余量比例为{tab['gain_vs_similar']/(oracle.mean()-similar.mean()):.1%}。",
            f"7. 有{target_diagnostics['small_margin_counts']['0.001']}/{target_diagnostics['n']}条（{target_diagnostics['small_margin_counts']['0.001']/target_diagnostics['n']:.2%}）margin≤0.001。当前四特征加似然目标的组合没有展示有效净切换收益；不能仅凭此实验区分特征不足、目标噪声与模型归纳偏差。",
            '8. 不建议立即把规模扩大到更多TFM。优先在Meta-training内审计低margin目标稳定性和目标/greedy正确性错位，再预注册特征或目标消融；若仍缺乏可预测的策略互补，可研究更有Oracle余量的数据集或选择策略。主实验目标保持不变。']
    lines+=['','Validation已参与选择Similar作为固定基线，以上仅是探索性证据，CI含0不得声称改善；最终需独立Test确认。',
            'McNemar p值未作多重比较校正；所有统计均为探索性。内部holdout共400条，LR与TabPFN使用相同分层划分；LR另报nested OOF。',
            '似然目标上的内部准确率不能保证下游收益；没有Validation meta-label，因此不能把Validation downstream correctness当作元标签准确率。',
            '四个邻域特征是否充分只能通过实际净切换收益检验，当前结果不能证明更大的TFM必然有效。建议先审计低margin噪声、似然目标与greedy正确性的错位、以及有限20条可挽救样本；再决定是否扩展TabICL/Mitra或研究更互补的选择策略/数据集。本阶段未实现这些额外TFM。','',
            '## 完整性与复现','', '特征及训练CSV、6000次评分日志/缓存、模型、预测、配对统计和图表均位于本目录。Official Test未用于任何训练、调参或评估。脚本：scripts/run_phase3.sh。']
    (root/'summary.md').write_text('\n'.join(lines),encoding='utf-8')
    figures(root,table,switches,groups_table)

def figures(root,table,switches,groups):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    path=root/'figures';path.mkdir(exist_ok=True)
    for name,values,ylabel in [('adaptive_accuracy',table.accuracy*100,'Downstream accuracy (%)')]:
        fig,ax=plt.subplots(figsize=(8,4));ax.bar(table.method,values);ax.tick_params(axis='x',rotation=20);ax.set_ylabel(ylabel);fig.tight_layout();fig.savefig(path/f'{name}.png',dpi=200);plt.close(fig)
    for name,columns in [('strategy_distribution',list(STRATEGIES)),('switching_outcomes',['beneficial','harmful','neutral_switches'])]:
        ax=switches.set_index('method')[columns].plot.bar(figsize=(9,4));ax.figure.tight_layout();ax.figure.savefig(path/f'{name}.png',dpi=200);plt.close(ax.figure)
    fig,ax=plt.subplots(figsize=(8,4))
    for method,group in groups.groupby('method'):ax.plot(group.group,group.accuracy*100,marker='o',label=method)
    ax.set_ylabel('Accuracy (%)');ax.legend();fig.tight_layout();fig.savefig(path/'accuracy_by_entropy.png',dpi=200);plt.close(fig)

def verify():
    cfg=config();root=ROOT/cfg['output'];before=read_json(root/'protected_before.json')
    assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==sha for p,sha in before.items())
    data=pd.read_csv(root/'meta_training_dataset.csv');assert len(data)==2000 and data.query_id.is_unique
    records=[json.loads(line) for line in (root/'meta_label_scores.jsonl').read_text().splitlines()]
    assert len(records)==6000 and len({(r['query_id'],r['strategy']) for r in records})==6000
    p2,p1,frames,arrays,labels,manifest,index=inputs()
    assert set(r['query_id'] for r in records)==set(frames['meta_training'].example_id)
    assert not set(data.query_id)&set(frames['validation'].example_id)
    assert np.isfinite(data[['max_similarity','mean_similarity','entropy_bits','top_label_vote']].to_numpy()).all()
    gold=frames['meta_training'].set_index('example_id').label_name.to_dict()
    assert all(r['target_label']==gold[r['query_id']] and not r['includes_eos'] and r['device']=='mps' for r in records)
    import xml.etree.ElementTree as ET
    suites=list(ET.parse(root/'tests.xml').getroot().iter('testsuite'))
    tests={key:sum(int(s.attrib.get(key,0)) for s in suites) for key in ('tests','failures','errors','skipped')}
    assert tests['failures']==tests['errors']==0
    write_json(root/'verification.json',{'meta_labels':len(data),'scores':6000,'protected_files_unchanged':len(before),
        'tabpfn_completed':(root/'predictions/tabpfn_v2_validation.csv').exists(),'logistic_completed':(root/'predictions/logistic_regression_validation.csv').exists(),
        'official_test_used':False,'only_meta_training_used_to_fit':True,'tests':tests})

if __name__=='__main__':analyze();verify()
