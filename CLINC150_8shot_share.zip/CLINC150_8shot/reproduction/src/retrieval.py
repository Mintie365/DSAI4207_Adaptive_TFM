"""One query-label-free retrieval system shared by every selector."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .utils import normalized_text, unit_vectors


@dataclass(frozen=True)
class Candidate:
    example_id: str
    text: str
    label_id: int
    label: str
    similarity: float
    rank: int
    embedding: np.ndarray = field(repr=False, compare=False)

    def as_dict(self):
        return {"example_id": self.example_id, "text": self.text, "label_id": self.label_id,
                "label": self.label, "similarity": self.similarity, "rank": self.rank}


class SemanticRetriever:
    def __init__(self, demonstration_pool, embeddings, exclude_identical_text=True):
        if len(demonstration_pool) != len(embeddings) or not len(demonstration_pool):
            raise ValueError("Pool and embedding rows must align and be nonempty")
        if not demonstration_pool.source_split.eq("train").all():
            raise ValueError("Demonstrations must originate from official training data")
        if "partition" not in demonstration_pool or not demonstration_pool.partition.eq("demonstration_pool").all():
            raise ValueError("Retrieval candidates must belong exclusively to the demonstration pool")
        if not demonstration_pool.example_id.is_unique:
            raise ValueError("Duplicate pool IDs")
        self.frame = demonstration_pool.reset_index(drop=True).copy()
        self.embeddings = unit_vectors(embeddings)
        self.ids = self.frame.example_id.to_numpy(dtype=str)
        self.normalized_texts = self.frame.text.map(normalized_text).to_numpy()
        self.exclude_identical_text = exclude_identical_text

    def retrieve(self, query_embedding, candidate_pool_size=32, *, query_id=None, query_text=None):
        if type(candidate_pool_size) is not int or candidate_pool_size <= 0:
            raise ValueError("candidate_pool_size must be a positive integer")
        query = unit_vectors(query_embedding)
        if query.ndim != 1 or query.shape[0] != self.embeddings.shape[1]:
            raise ValueError("Query must be a vector matching pool dimensions")
        scores = self.embeddings @ query
        eligible = np.ones(len(self.frame), dtype=bool)
        if query_id is not None:
            eligible &= self.ids != query_id
        if self.exclude_identical_text and query_text is not None:
            eligible &= self.normalized_texts != normalized_text(query_text)
        indices = np.flatnonzero(eligible)
        if len(indices) < candidate_pool_size:
            raise ValueError("Not enough eligible demonstrations for the requested candidate pool")
        order = np.lexsort((self.ids[indices], -scores[indices]))
        candidates = []
        for rank, i in enumerate(indices[order[:candidate_pool_size]], start=1):
            row = self.frame.iloc[i]
            candidates.append(Candidate(str(row.example_id), str(row.text), int(row.label),
                                         str(row.label_name), float(scores[i]), rank,
                                         self.embeddings[i].copy()))
        return candidates
