"""Frozen artifact loading and query-label-free four-feature extraction."""
from pathlib import Path
import numpy as np
import pandas as pd
import yaml
from .phase2_data import load_phase2_config, load_phase2_inputs
from .prepare_data import frame_fingerprint
from .embeddings import load_cache
from .retrieval import SemanticRetriever
from .retrieval_diagnostics import neighborhood_stats
from .utils import ROOT, read_json, write_json

STRATEGIES = ('similar','diverse','balanced')
FEATURES = ['max_similarity','mean_similarity','entropy_bits','top_label_vote']

def config():
    return yaml.safe_load((ROOT/'configs/phase3.yaml').read_text())

def inputs():
    phase2=load_phase2_config()
    phase1,frames,arrays,labels,manifest,index=load_phase2_inputs(phase2)
    frame=pd.read_csv(Path(phase1['paths']['splits'])/'meta_training.csv',keep_default_na=False)
    assert len(frame)==2000 and frame.partition.eq('meta_training').all() and frame.source_split.eq('train').all()
    assert frame.example_id.is_unique and not set(frame.example_id)&set(frames['validation'].example_id)
    assert frame_fingerprint(frame)==manifest['splits']['meta_training']['fingerprint']
    assert frame.label_name.eq(frame.label.map(dict(enumerate(labels)))).all()
    root=Path(phase1['paths']['embeddings']);key=index['keys']['meta_training']
    identity=read_json(root/f'meta_training-{key}.json')['identity']
    assert identity['data_fingerprint']==frame_fingerprint(frame) and identity['dataset_manifest']==manifest['fingerprint']
    assert identity['encoder']==index['encoder'] and identity['resolved_model_revision']==index['resolved_revision']
    arrays['meta_training']=load_cache(root,key,identity,frame)
    frames['meta_training']=frame
    return phase2,phase1,frames,arrays,labels,manifest,index

def feature_vector(pool):
    stats=neighborhood_stats([d.label for d in pool])
    assert len(pool)==32
    values=[max(d.similarity for d in pool),np.mean([d.similarity for d in pool]),stats['entropy_bits'],stats['top_label_vote']]
    assert np.isfinite(values).all()
    return dict(zip(FEATURES,map(float,values)))

def prepare():
    p2,p1,frames,arrays,labels,manifest,index=inputs()
    retriever=SemanticRetriever(frames['demonstration_pool'],arrays['demonstration_pool'],p1['retrieval']['exclude_identical_text'])
    root=ROOT/config()['output'];root.mkdir(parents=True,exist_ok=True)
    for split,name in [('meta_training','train'),('validation','validation')]:
        rows=[]
        for i,row in frames[split][['example_id','text']].iterrows():
            pool=retriever.retrieve(arrays[split][i],32,query_id=row.example_id,query_text=row.text)
            rows.append({'query_id':row.example_id,**feature_vector(pool)})
        pd.DataFrame(rows).sort_values('query_id').to_csv(root/f'meta_features_{name}.csv',index=False)
    write_json(root/'experiment_config.json',{'phase3':config(),'phase2':p2,'manifest':manifest['fingerprint'],
        'embedding_keys':index['keys'],'mapping':dict(enumerate(STRATEGIES)), 'feature_gold_labels_used':False})
    return root
