"""Typing contract for future model-specific adapters; no Phase 2 implementation."""
from __future__ import annotations

from typing import Literal, Protocol

import numpy as np

AdaptiveStrategy = Literal["similar", "diverse", "balanced"]


class MetaSelector(Protocol):
    """Adapters must handle each model's own initialization/API/label encoding.

    X contains query-neighborhood features computed without query gold labels.
    fit is for meta-training only; predict returns strategy names, never intent IDs.
    Random remains a fixed baseline, not an adaptive target class.
    """

    def fit(self, X_meta: np.ndarray, y_meta: np.ndarray) -> MetaSelector: ...

    def predict(self, X_query: np.ndarray) -> np.ndarray: ...
