"""Detailed Chinese research report composed solely from audited observed results."""
from __future__ import annotations

from collections import Counter
from datetime import datetime
import json

import numpy as np

from .utils import ROOT, read_json, write_json


def _read_jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()] if path.exists() else []


def write_report(destination,baseline,seeds,oracle,complement,ambiguity,statistics,cases,run_id,config,analysis):
    sources = read_json(destination/"source_runs.json")
    snapshot = read_json(destination/"experiment_config.json")
    calls = _read_jsonl(destination/"inference_calls.jsonl")
    sessions = _read_jsonl(destination/"execution_sessions.jsonl")
    zero_status = read_json(ROOT/sources["zero_directory"]/"status.json")
    zero_history = _read_jsonl(ROOT/sources["zero_directory"]/"execution_sessions.jsonl")
    zero_wall = sum(s["session_wall_seconds"] for s in zero_history) if zero_history else zero_status["session_wall_seconds"]
    current_wall = sum(s["wall_seconds"] for s in sessions)+zero_wall
    call_times = [c["runtime_seconds"] for c in calls]
    peak_rss = max(c["memory"].get("process_peak_rss_bytes",0) for c in calls)
    peak_mps = max(c["memory"].get("mps_current_allocated_bytes",0) for c in calls)
    # Pilot B may have been completed by the existing standalone runner before this orchestrator.
    pilot_b = ROOT/config["results"]/read_json(ROOT/config["results"]/"latest_pilot_b.json")["run_directory"]
    pilot_b_records = _read_jsonl(pilot_b/"pilot_predictions.jsonl")
    pilot_b_new = sum(not r["cache_hit"] for r in pilot_b_records)
    pilot_b_repeat = int((pilot_b/"consistency.json").exists())
    metrics = baseline.set_index("strategy")
    n = int(oracle["n"])
    lines = ["# Phase 2 全量 Validation 与策略互补性分析", "",
             f"Run ID：`{run_id}`；ICL source run：`{sources['full_run_id']}`。结果均由已保存预测重新计算。", "",
             "## A. 执行概况", "",
             f"- 数据：`PolyAI/banking77`，commit `{snapshot['phase1']['dataset']['revision']}`；split manifest fingerprint `{snapshot['pilot_a_snapshot']['experiment']['controls']['dataset_manifest']}`。",
             f"- 模型和tokenizer：`{config['model']['checkpoint']}`，revision均为 `{config['model']['revision']}`。",
             "- 设备：Apple M5，16 GiB unified memory，PyTorch `mps`，FP16；冻结参数/eval，greedy且do_sample=False。没有CPU回退。",
             f"- 完成全部{n}条Validation：Similar/Diverse/Balanced各{n}次，Random五seed共{n*5}次，Zero-shot另{n}次；总计{n*9}条唯一预测。",
             f"- 本次full/zero orchestrator实际generate调用{len(calls)}次（含一致性重复）；此前本轮Pilot B新增{pilot_b_new}次预测及{pilot_b_repeat}次重复。已有Pilot A和Pilot B预测按相同cache keys复用。",
             f"- 合计本轮新增generate调用{len(calls)+pilot_b_new+pilot_b_repeat}次；不含此前Pilot A。9027是唯一评估预测数，不能与新增调用数混为一谈。",
             f"- Pilot B共{len(pilot_b_records)}条记录，其中invalid={sum(not r['valid'] for r in pilot_b_records)}条；不是全部有效。所有invalid按预定parser计错。",
             f"- orchestrator计时区间合计{current_wall:.2f}s（{current_wall/60:.2f}分钟；包含缓存Pilot B检查，不含模型初始载入及此前独立Pilot B）。GPU调用内部累计{sum(call_times):.2f}s，平均{np.mean(call_times):.4f}s。",
             f"- 当前orchestrator进程RSS峰值{peak_rss/1024**3:.3f} GiB；推理后MPS当前分配采样最大{peak_mps/1024**3:.3f} GiB（不等于GPU瞬时峰值）。",
             f"- 当前调用日志中invalid输出{sum(not c['valid'] for c in calls)}次。每个预测保留device、token数、runtime、内存、raw response、控制hash；cache与真实generate计数分开。",
             "- 原Phase 1数据、缓存、标签映射、Top-32、k=8、MMR λ=0.5和ICL prompt均未改变；Official Test未用于实验。", "",
             "## B. 固定基线与Zero-shot", "",
             "| Method | Accuracy | Macro-F1（77类） | Invalid Rate | Correct / Incorrect | 平均推理秒 |",
             "|---|---:|---:|---:|---:|---:|"]
    for strategy in ("zero_shot","random","similar","diverse","balanced"):
        row = metrics.loc[strategy]
        if strategy=="random":
            name = "Random（五seed mean ± std）"
            acc = f"{row.accuracy:.3%} ± {row.accuracy_std:.3%}"
            f1 = f"{row.macro_f1:.5f} ± {row.macro_f1_std:.5f}"
            counts = f"{row.correct_count:.2f} / {row.incorrect_count:.2f}（均值）"
        else:
            name,acc,f1,counts = strategy,f"{row.accuracy:.3%}",f"{row.macro_f1:.5f}",f"{int(row.correct_count)} / {int(row.incorrect_count)}"
        lines.append(f"| {name} | {acc} | {f1} | {row.invalid_rate:.3%} | {counts} | {row.mean_inference_seconds:.4f} |")
    lines.extend(["", "Random seeds固定为42/43/44/45/46；std使用ddof=0，不挑最佳seed，逐seed结果见random_seed_metrics.csv。",
                  f"Global-Best Fixed (All)：**{oracle['global_best_all_four']}**。",
                  f"Global-Best Fixed (Adaptive Candidates)：**{oracle['global_best_adaptive_candidates']}**，这是未来三选一TFM的主要比较参照。",
                  "两者均按本Validation Accuracy选择，数值并列容差1e-12，顺序Similar > Balanced > Diverse > Random；不含Zero-shot或Oracle。",
                  f"Zero-shot Accuracy={oracle['zero_shot_accuracy']:.3%}；最佳固定ICL相比Zero-shot提升{oracle['best_fixed_icl_minus_zero_shot']*100:.3f}个百分点。",
                  "Zero-shot只移除示例，保留原system/user instruction、全部77标签、空Demonstrations节和相同chat/generation设置；不参与adaptive target。",
                  "以上属于Validation选择结果，不是无偏泛化估计；后续须在独立Official Test确认。", "",
                  "Zero-shot衡量当前冻结模型在给定标签列表下的既有任务能力；ICL−Zero-shot差异反映这套示例设置的增量，不能据此单独判定预训练记忆或数据污染。", "",
                  "无效输出保持原文并计为incorrect，没有修正canonical punctuation。例如漏掉`reverted_card_payment?`的问号会被拒绝；完整明细见invalid_outputs.csv。这使本结果同时反映分类与输出格式遵循能力。", "",
                  "## C. 策略预测分歧与正确性互补", "",
                  f"三者预测全相同：{complement['prediction_agreement']['all_three_same']:.3%}；恰好两者相同：{complement['prediction_agreement']['exactly_two_agree']:.3%}；三者全不同：{complement['prediction_agreement']['all_three_different']:.3%}。", "",
                  f"分歧统计对invalid使用带标记的原始输出类别（只trim空白），避免把不同错误输出均折叠为None而产生虚假一致；invalid仍全部判错。三者都输出有效标签的query共{complement['all_three_valid_query_count']}条，valid-only一致性另保存在complementarity.json。", "",
                  "| 策略对 | 标签预测分歧率 | 正确性分歧率 | 标签不同但都错（条） |", "|---|---:|---:|---:|"])
    for row in complement["pairwise"]:
        lines.append(f"| {row['left']} / {row['right']} | {row['prediction_disagreement_rate']:.3%} | {row['correctness_disagreement_rate']:.3%} | {row['different_but_both_wrong_count']} |")
    lines.extend(["", "| 正确的候选策略数 | Query数 | 比例 |", "|---:|---:|---:|"])
    for k in (3,2,1,0):
        lines.append(f"| {k} | {complement['success_counts'][str(k)]} | {complement['success_fractions'][str(k)]:.3%} |")
    lines.append("")
    for name,value in complement["rescue"].items():
        lines.append(f"- {name}：{value['count']}条（{value['fraction']:.3%}）。")
    lines.extend(["", "预测不同不等于能够改进：不同的错误标签不会被三选一selector转为正确答案。三策略都错的查询超出本Oracle的挽救范围。", "",
                  "![Prediction agreement](figures/prediction_agreement.png)",
                  "![Correctness intersections](figures/correctness_overlap.png)",
                  "![Successful strategy count](figures/successful_strategy_count.png)", "",
                  "## D. Oracle与可用改善空间", "",
                  f"受限Oracle正确{oracle['oracle_correct_count']}/{n}，Accuracy=**{oracle['oracle_accuracy']:.3%}**；最佳固定候选策略Accuracy={oracle['global_best_candidate_accuracy']:.3%}。",
                  f"Oracle增益=**{oracle['oracle_gain']*100:.3f}个百分点**，即额外挽救{oracle['oracle_rescued_query_count']}条；query-paired bootstrap 95% CI=[{oracle['oracle_gain_ci_95'][0]*100:.3f}, {oracle['oracle_gain_ci_95'][1]*100:.3f}]个百分点。",
                  f"bootstrap每轮重选最佳固定候选的敏感性CI=[{oracle['bootstrap_reselect_best_ci'][0]*100:.3f}, {oracle['bootstrap_reselect_best_ci'][1]*100:.3f}]个百分点。",
                  "Oracle在回顾分析中使用gold，只代表当前三组固定预测中完美按query选择的上限；不是部署方法、不是TFM实际效果，也不是其他策略/模型的普遍上界。未用Oracle标签修改检索、prompt或超参数。", "",
                  "## E. Query歧义分析", "",
                  "在查看全量预测结果之前固定entropy四分位切点。相同H_N不拆分，区间上界包含，因此各组大小可能不完全相等。特征均来自同一Top-32候选标签/相似度，mean similarity使用m=32。",
                  "主列Oracle gain参照全量选择的同一best fixed；另报组内回顾选择best fixed的增益，避免混淆两个参照。", "",
                  "| Entropy组 | n | Similar | Diverse | Balanced | Oracle | 平均pairwise分歧 | Oracle−全局best（pp） | Oracle−组内best（pp） |",
                  "|---|---:|---:|---:|---:|---:|---:|---:|---:|"])
    for row in ambiguity.itertuples():
        lines.append(f"| {row.group} | {row.n} | {row.similar_accuracy:.3%} | {row.diverse_accuracy:.3%} | {row.balanced_accuracy:.3%} | {row.oracle_accuracy:.3%} | {row.mean_pairwise_disagreement:.3%} | {row.oracle_gain_over_global_best*100:.3f} | {row.oracle_gain_over_group_best*100:.3f} |")
    low,high = ambiguity.iloc[0],ambiguity.iloc[3]
    support = high.oracle_gain_over_global_best>low.oracle_gain_over_global_best and high.mean_pairwise_disagreement>low.mean_pairwise_disagreement
    lines.extend(["", f"最高熵组与最低熵组的Oracle增益分别为{high.oracle_gain_over_global_best*100:.3f}与{low.oracle_gain_over_global_best*100:.3f}个百分点；",
                  f"平均预测分歧分别为{high.mean_pairwise_disagreement:.3%}与{low.mean_pairwise_disagreement:.3%}。",
                  "这些描述性结果与“混合标签邻域更可能需要策略选择”的假设方向一致，但不构成确认性证据。" if support else
                  "这些描述性结果没有在Oracle增益和分歧两项上同时支持“高歧义更受益”；原假设仍需进一步检验。",
                  "entropy/error、entropy/disagreement、top-vote/error的Spearman相关和未校正探索性p值见feature_correlations.csv；top-vote固定区间的Accuracy见top_vote_analysis.csv。不据此重新划分组或选择超参数。", "",
                  "![Accuracy by ambiguity](figures/accuracy_by_ambiguity.png)",
                  "![Disagreement by ambiguity](figures/disagreement_by_ambiguity.png)",
                  "![Oracle gain by ambiguity](figures/oracle_gain_by_ambiguity.png)", "",
                  "## F. 代表性成功与失败样本", "",
                  "每种预定义类别按example_id选择最多2条，去除重复query；不足时以高熵案例补足。不是随机代表性样本，也不是因果解释。",
                  f"各类别可用query数：`{cases['available_queries_by_category']}`。完整Top-32标签分布及三个策略的全部demo文本见representative_cases.json。", ""])
    for i,case in enumerate(cases["cases"],1):
        lines.extend([f"### 案例{i}：{case['category']} / {case['query_id']}", "", f"> {case['query_text']}", "",
                      f"Gold：`{case['gold_label']}`；H_N={case['features']['entropy_bits']:.4f} bits。",
                      "预测："+"；".join(f"{s}=`{case['predictions'][s]}` ({'正确' if case['correct'][s] else '错误'})" for s in ("similar","diverse","balanced")),
                      f"原始输出：`{case['raw_outputs']}`。",
                      f"Top-32标签分布：`{case['top32_label_distribution']}`。"])
        for s in ("similar","diverse","balanced"):
            counts = dict(Counter(d["label"] for d in case["demonstrations"][s]))
            example = case["demonstrations"][s][0]
            lines.append(f"- {s}所选标签：`{counts}`。首个demo：{example['text']} → `{example['label']}`。")
        lines.append("")
    lines.extend(["## G. 配对统计与可靠性", "",
                  f"采用query级配对percentile bootstrap，{analysis['bootstrap']['replicates']}次，seed={analysis['bootstrap']['seed']}；同一resample用于各方法，保留query内依赖。Random先在每个query上取固定五seed正确性的均值，再对query重采样，五次预测不作为独立样本。五seed变异另在CSV报告；此CI条件于这五个seed，不声称穷尽seed不确定性。", "",
                  "| 比较（左−右） | Accuracy差（pp） | 配对95% CI（pp） | Exact McNemar p | Holm p（三候选对） |", "|---|---:|---:|---:|---:|"])
    for row in statistics.to_dict("records"):
        p = row.get("mcnemar_exact_p",np.nan); adjusted=row.get("mcnemar_holm_p",np.nan)
        lines.append(f"| {row['left']}−{row['right']} | {row['accuracy_difference']*100:.3f} | [{row['ci_95_low']*100:.3f}, {row['ci_95_high']*100:.3f}] | {p:.5g} | {adjusted:.5g} |")
    inconclusive = [f"{r.left}−{r.right}" for r in statistics.itertuples() if not r.ci_excludes_zero]
    significant = [f"{r.left}−{r.right}" for r in statistics.iloc[:3].itertuples() if r.mcnemar_holm_p<.05]
    lines.extend(["", "bootstrap CI包含0、因而当前仍不确定的差异："+("、".join(inconclusive) or "本表无此项")+"。",
                  "三候选对Exact McNemar经Holm校正p<0.05的比较："+("、".join(significant) or "无")+"。",
                  "bootstrap CI未做多重性校正；仅三组预定义candidate McNemar检验使用Holm。所有最佳策略/Oracle分析均涉及同集选择或gold回顾，属于探索性Validation证据，不能解释为无偏Test性能。", "",
                  "![Paired differences](figures/paired_accuracy_differences.png)", "",
                  "## H. 对Phase 3的建议", "",
                  f"1. 全局候选最佳为{oracle['global_best_adaptive_candidates']}，应以其作为主要固定参照。数值排序与可靠差异须结合上述配对CI、Holm检验判断，不凭Accuracy小幅领先断言压倒性优势。",
                  f"2. 三策略存在{oracle['oracle_rescued_query_count']}条超出最佳固定策略的可挽救query，另有{complement['success_counts']['0']}条全部失败。标签分歧和错误互补已经分开量化。",
                  f"3. 当前受限Oracle headroom为{oracle['oracle_gain']*100:.3f}个百分点；任何三选一模型只能尝试实现其中一部分，不能把Oracle当作TFM预期性能。",
                  "4. 高歧义是否更有收益的探索性结论见E；需要在meta_training学习、冻结方案后在独立Test检验，不能使用本Validation的Oracle结果调组界。",
                  "5. 可继续一个受控Phase 3：先做Logistic Regression和TabPFN的小规模meta-training对照，再根据可实现增益决定是否扩大到TabICL、Mitra、TabDPT等；当前结果没有证明任何TFM能接近Oracle。" if oracle['oracle_gain_ci_95'][0]>0 else
                  "5. 当前Oracle改善的可靠性不足，优先检查可用headroom与meta-training信号，再决定是否投入大规模TFM对比；不要假定模型复杂度能创造不存在的互补性。",
                  "6. 保留泄漏与评估限制：Banking77既有跨split规范化/词面近重复仍需披露；已有8对demo/validation规范化匹配按原规则排除，190对近重复未删除。Validation参与选模，最终确认必须使用此前未参与训练/调参的Official Test。单一数据集、单一LLM、固定k/候选池、MPS FP16及有限seed的结论不自动推广。", "",
                  "本阶段未训练TabPFN/TabICL/Mitra或其他自适应模型，未构造训练meta-label。所保存的query级预测/特征/正确性可用于审计与未来分析；未来训练数据应来自既定meta_training split，而不是把本Validation Oracle标签拿去训练。", "",
                  "## 复现与文件", "", "参见根目录README与scripts/run_phase2_full.sh。所有CSV含run_id和model_revision；源实验snapshot、逐条原始预测、cache来源、计时和七组PNG/SVG图均保留。", ""])
    (destination/"summary.md").write_text("\n".join(lines),encoding="utf-8")
    write_json(destination/"execution_summary.json",{"run_id":run_id,"unique_prediction_records":n*9,
        "orchestrator_generate_calls":len(calls),"preceding_pilot_b_new_predictions":pilot_b_new,
        "generate_calls_this_full_phase":len(calls)+pilot_b_new+pilot_b_repeat,
        "preceding_pilot_b_repeat_calls":pilot_b_repeat,"timed_full_zero_wall_seconds":current_wall,
        "orchestrator_inference_seconds":sum(call_times),"process_peak_rss_bytes":peak_rss,
        "max_observed_mps_allocated_bytes":peak_mps,"actual_devices":sorted({c['actual_device'] for c in calls})})
