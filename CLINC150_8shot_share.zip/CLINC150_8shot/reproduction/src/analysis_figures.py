"""Static scientific figures; all data come from saved Validation predictions."""
from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/dsai4207-matplotlib")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import numpy as np

COLORS = {"similar":"#0072B2", "diverse":"#D55E00", "balanced":"#009E73", "oracle":"#333333"}


def create_figures(destination, complement, ambiguity, statistics, *, run_id, n):
    destination = Path(destination)
    destination.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":10, "axes.spines.top":False,
                         "axes.spines.right":False, "figure.dpi":120, "savefig.dpi":300})
    saved = []

    def save(fig,name):
        fig.text(.01,.008,f"Validation n={n} | Qwen2.5-1.5B-Instruct | MPS FP16 | run {run_id}",fontsize=7,color="#555555")
        fig.tight_layout(rect=(0,.035,1,1))
        for suffix in ("png","svg"):
            fig.savefig(destination/f"{name}.{suffix}",bbox_inches="tight")
        saved.append(name)
        plt.close(fig)

    fig,ax = plt.subplots(figsize=(5.5,4.7))
    matrix = np.array(complement["agreement_matrix"])
    im = ax.imshow(matrix,vmin=0,vmax=1,cmap="Blues")
    names = ["Similar","Diverse","Balanced"]
    ax.set_xticks(range(3),names); ax.set_yticks(range(3),names)
    for i in range(3):
        for j in range(3):
            ax.text(j,i,f"{matrix[i,j]:.1%}",ha="center",va="center",color="white" if matrix[i,j]>.65 else "black")
    ax.set_title("Pairwise prediction agreement")
    fig.colorbar(im,ax=ax,format=PercentFormatter(1))
    save(fig,"prediction_agreement")

    fig,(top,bottom) = plt.subplots(2,1,figsize=(8.2,5.5),gridspec_kw={"height_ratios":[3,1.3]},sharex=True)
    patterns = [format(i,"03b") for i in range(8)]
    counts = [complement["correctness_patterns"][p] for p in patterns]
    bars = top.bar(range(8),counts,color="#4477AA")
    top.bar_label(bars,padding=3); top.set_ylim(0,max(counts)*1.15+1)
    top.set_ylabel("Number of queries"); top.set_title("Correctness intersections (filled dots = correct)")
    for x,pattern in enumerate(patterns):
        active = [i for i,b in enumerate(pattern) if b=="1"]
        bottom.scatter([x]*3,range(3),s=45,color="#DDDDDD")
        if active:
            bottom.plot([x]*len(active),active,color="#333333",marker="o",markersize=6)
    bottom.set_yticks(range(3),names); bottom.invert_yaxis()
    bottom.set_xticks(range(8),["None","B","D","D+B","S","S+B","S+D","S+D+B"],rotation=20)
    bottom.set_ylim(2.5,-.5)
    save(fig,"correctness_overlap")

    fig,ax = plt.subplots(figsize=(6.2,4.3))
    counts = [complement["success_counts"][str(k)] for k in range(4)]
    bars = ax.bar(range(4),counts,color=["#CC6677","#DDCC77","#88CCEE","#44AA99"])
    ax.bar_label(bars,labels=[f"{count}\n({count/n:.1%})" for count in counts],padding=4)
    ax.set_ylim(0,max(counts)*1.22+1); ax.set_xticks(range(4))
    ax.set_xlabel("Number of correct candidate strategies"); ax.set_ylabel("Number of queries")
    ax.set_title("Per-query strategy success count")
    save(fig,"successful_strategy_count")

    x = np.arange(4)
    ticklabels = [f"{row.group}\n(n={row.n})" for row in ambiguity.itertuples()]
    fig,ax = plt.subplots(figsize=(7,4.8))
    for strategy in ("similar","diverse","balanced","oracle"):
        ax.plot(x,ambiguity[f"{strategy}_accuracy"],marker="o",label=strategy.title(),color=COLORS[strategy],
                linestyle="--" if strategy=="oracle" else "-")
    ax.set_xticks(x,ticklabels); ax.set_ylim(0,1.03); ax.yaxis.set_major_formatter(PercentFormatter(1))
    ax.set_xlabel("Neighborhood entropy quartile (low to high)"); ax.set_ylabel("Accuracy")
    ax.set_title("Accuracy by query ambiguity"); ax.legend(loc="lower left",ncol=2)
    save(fig,"accuracy_by_ambiguity")

    fig,ax = plt.subplots(figsize=(7,4.7))
    for pair,color in zip(("similar/diverse","similar/balanced","diverse/balanced"),COLORS.values()):
        ax.plot(x,ambiguity[f"disagreement_{pair}"],marker="o",label=pair,color=color)
    ax.set_xticks(x,ticklabels); ax.set_ylim(0,1.0); ax.yaxis.set_major_formatter(PercentFormatter(1))
    ax.set_ylabel("Prediction disagreement rate"); ax.set_xlabel("Neighborhood entropy quartile")
    ax.set_title("Strategy disagreement by ambiguity"); ax.legend()
    save(fig,"disagreement_by_ambiguity")

    fig,ax = plt.subplots(figsize=(7,4.7))
    ax.bar(x-.18,ambiguity.oracle_gain_over_global_best*100,width=.36,color="#4477AA",label="Oracle - global-best fixed")
    ax.bar(x+.18,ambiguity.oracle_gain_over_group_best*100,width=.36,color="#BBBBBB",label="Oracle - group-best fixed (retrospective)")
    ax.set_xticks(x,ticklabels); ax.set_ylabel("Accuracy gain (percentage points)")
    ax.set_xlabel("Neighborhood entropy quartile"); ax.set_title("Available oracle gain by ambiguity")
    ax.legend(fontsize=8)
    save(fig,"oracle_gain_by_ambiguity")

    fig,axes = plt.subplots(2,1,figsize=(9,7.4),gridspec_kw={"height_ratios":[5,4]})
    for ax,subset,title in ((axes[0],statistics[statistics.right!="zero_shot"],"Candidate comparisons and Oracle"),
                            (axes[1],statistics[statistics.right=="zero_shot"],"ICL versus zero-shot")):
        rows = subset.iloc[::-1].reset_index(drop=True)
        for i,row in rows.iterrows():
            ax.plot([row.ci_95_low*100,row.ci_95_high*100],[i,i],color="#4477AA",linewidth=2)
            ax.scatter([row.accuracy_difference*100],[i],color="#4477AA",s=28)
        if (rows.ci_95_low<=0).any():
            ax.axvline(0,color="#666666",linestyle="--",linewidth=1)
        ax.set_yticks(range(len(rows)),[f"{r.left} - {r.right}".replace('_',' ') for r in rows.itertuples()])
        ax.set_xlabel("Accuracy difference (percentage points), paired bootstrap 95% CI")
        ax.set_title(title+" (exploratory)",fontsize=11)
    save(fig,"paired_accuracy_differences")
    return saved
