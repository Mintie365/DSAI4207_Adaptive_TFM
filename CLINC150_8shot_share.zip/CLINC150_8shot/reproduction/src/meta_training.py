"""Fit on 2000 Meta-training rows only; separate process from Qwen scoring."""
import argparse,hashlib,importlib.metadata,time
import joblib,numpy as np,pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,f1_score
from .meta_features import config,FEATURES
from .meta_selectors import LogisticSelector,TabPFNV2Selector,ConstantSelector
from .utils import ROOT,read_json,write_json

def train(method,device='mps'):
    cfg=config();root=ROOT/cfg['output'];train=pd.read_csv(root/'meta_training_dataset.csv');val=pd.read_csv(root/'meta_features_validation.csv')
    assert len(train)==2000 and train.query_id.is_unique and len(val)==1003 and not set(train.query_id)&set(val.query_id)
    X=train[FEATURES].to_numpy();y=train.target_class.to_numpy(int);V=val[FEATURES].to_numpy()
    assert np.isfinite(X).all() and np.isfinite(V).all()
    start=time.perf_counter();metadata={}
    if method=='logistic_regression':
        model=LogisticSelector(cfg).fit(X,y);metadata=model.diagnostics
        if len(np.unique(y))>1:
            a,b=train_test_split(np.arange(len(X)),test_size=cfg['tabpfn']['holdout_fraction'],stratify=y,random_state=cfg['seed'])
            check=LogisticSelector(cfg).fit(X[a],y[a]);p=check.predict(X[b])
            metadata.update(internal_holdout_accuracy=accuracy_score(y[b],p),internal_holdout_macro_f1=f1_score(y[b],p,labels=[0,1,2],average='macro',zero_division=0),holdout_size=len(b))
    else:
        import torch
        if device=='mps' and not torch.backends.mps.is_available():raise RuntimeError('MPS unavailable; no CPU fallback')
        if device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
        checkpoint=read_json(root/'tabpfn_checkpoint.json')
        from pathlib import Path
        if not Path(checkpoint['path']).exists():
            from huggingface_hub import hf_hub_download
            checkpoint['path']=hf_hub_download(checkpoint['repository'],checkpoint['filename'],revision=checkpoint['revision'],cache_dir=str(ROOT/'data/hub_cache'))
        assert hashlib.sha256(Path(checkpoint['path']).read_bytes()).hexdigest()==checkpoint['sha256']
        torch.manual_seed(cfg['seed'])
        if len(np.unique(y))<2:
            model=ConstantSelector(int(y[0])).fit(X,y);metadata={'constant_fallback':True}
        else:
            # Separate MPS smoke and internal held-out evaluation; never Validation labels.
            a,b=train_test_split(np.arange(len(X)),test_size=cfg['tabpfn']['holdout_fraction'],stratify=y,random_state=cfg['seed'])
            smoke=np.concatenate([a[y[a]==c][:8] for c in np.unique(y)])
            test_model=TabPFNV2Selector(cfg,checkpoint,device).fit(X[smoke],y[smoke])
            smoke_pred=test_model.predict(X[b[:8]]);assert set(smoke_pred)<=set(range(3))
            del test_model
            check=TabPFNV2Selector(cfg,checkpoint,device).fit(X[a],y[a]);p=check.predict(X[b])
            metadata={'internal_holdout_accuracy':accuracy_score(y[b],p),'internal_holdout_macro_f1':f1_score(y[b],p,labels=[0,1,2],average='macro',zero_division=0),'holdout_size':len(b)}
            del check
            import gc
            gc.collect()
            if device=='mps':torch.mps.empty_cache()
            model=TabPFNV2Selector(cfg,checkpoint,device).fit(X,y)
            actual=[str(d) for d in model.model.devices_]
            assert all(d.startswith(device) for d in actual),'TabPFN silently changed device'
            metadata['actual_devices']=actual
        metadata.update(package_version=importlib.metadata.version('tabpfn'),checkpoint=checkpoint,device=device,
                        n_estimators=cfg['tabpfn']['n_estimators'],version='v2',random_state=42)
    fit_seconds=time.perf_counter()-start;start=time.perf_counter();pred=model.predict(V);proba=model.predict_proba(V);prediction_seconds=time.perf_counter()-start
    output=val[['query_id']].copy();output['strategy_class']=pred;output['strategy']=np.array(['similar','diverse','balanced'])[pred]
    output['batch_mean_runtime_seconds']=prediction_seconds/len(V)
    probability_classes=model.model.classes_ if hasattr(model,'model') else np.arange(3)
    for i in range(proba.shape[1]):output[f'probability_class_{int(probability_classes[i])}']=proba[:,i]
    (root/'predictions').mkdir(exist_ok=True);output.to_csv(root/'predictions'/f'{method}_validation.csv',index=False)
    (root/'models').mkdir(exist_ok=True)
    if method=='logistic_regression':joblib.dump(model,root/'models/logistic_regression.joblib')
    else:
        # Portable fit context + pinned checkpoint are sufficient to reconstruct TabPFN fit.
        np.savez(root/'models/tabpfn_v2_fit_context.npz',X=X,y=y)
        if hasattr(model,'model'):
            model.model.save_fit_state(root/'models/tabpfn_v2.tabpfn_fit')
            metadata['resolved_n_estimators']=int(model.model.n_estimators_)
        metadata['model_parameters']=str(model.model.get_params(deep=False)) if hasattr(model,'model') else 'constant'
    metadata.update(fit_seconds=fit_seconds,validation_prediction_seconds=prediction_seconds,n_training=len(X),n_validation=len(V),features=FEATURES,
                    timing_note='fit_seconds includes internal CV/holdout; prediction_seconds includes predict and predict_proba; per-query CSV timing is batch mean, not individually measured')
    write_json(root/'models'/f'{method}_metadata.json',metadata)
    print(method,metadata,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('method',choices=['logistic_regression','tabpfn_v2']);p.add_argument('--device',default='mps',choices=['mps','cuda']);a=p.parse_args();train(a.method,a.device)
