"""Descriptive validation neighborhoods; no query/test gold label is inspected."""
from __future__ import annotations

from collections import Counter
from itertools import combinations
from pathlib import Path

import numpy as np

from .phase2_data import load_phase2_inputs
from .retrieval import SemanticRetriever
from .selection import select_demonstrations
from .utils import ROOT, read_json, write_json


def distribution(values):
    a = np.asarray(values, dtype=float)
    return {"mean": float(a.mean()), "std": float(a.std()), "min": float(a.min()),
            **{f"p{p}": float(np.percentile(a, p)) for p in (25, 50, 75, 90, 95)}, "max": float(a.max())}


def neighborhood_stats(candidate_labels):
    counts = np.array(list(Counter(candidate_labels).values()), dtype=float)
    probabilities = counts / counts.sum()
    return {"unique_intents": len(counts), "entropy_bits": float(-np.sum(probabilities * np.log2(probabilities))),
            "top_label_vote": float(probabilities.max())}


def run_diagnostics(config):
    phase1, frames, arrays, _, manifest, index = load_phase2_inputs(config)
    retriever = SemanticRetriever(frames["demonstration_pool"], arrays["demonstration_pool"],
                                  phase1["retrieval"]["exclude_identical_text"])
    threshold = config["diagnostics"]["dominant_vote_threshold"]
    if not 0.5 <= threshold <= 1:
        raise ValueError("Dominance threshold must be between .5 and 1")
    per_query = []
    for i, row in frames["validation"][["example_id", "text"]].iterrows():
        vector = arrays["validation"][i]
        pool = retriever.retrieve(vector, 32, query_id=row.example_id, query_text=row.text)
        stats = neighborhood_stats([d.label for d in pool])
        selections = {s: {d["example_id"] for d in select_demonstrations(
            vector, pool, s, config["k"], config["seed"], mmr_lambda=phase1["selection"]["mmr_lambda"])["demonstrations"]}
            for s in ("similar", "diverse", "balanced")}
        overlaps = {f"{a}/{b}": {"shared": len(selections[a] & selections[b]),
                                 "jaccard": len(selections[a] & selections[b]) / len(selections[a] | selections[b])}
                    for a, b in combinations(selections, 2)}
        per_query.append({"query_id": row.example_id, **stats, "overlap": overlaps})
    old_audit = read_json(Path(phase1["paths"]["splits"]) / "duplicate_report.json")
    # Existing audit contains text/IDs, not query/test labels. Do not recompute with test.
    relevant = {}
    for kind in ("exact_pairs", "near_pairs"):
        pairs = [p for p in old_audit[kind] if {p["left"]["split"], p["right"]["split"]} == {"demonstration_pool", "validation"}]
        ids = {p[side]["example_id"] for p in pairs for side in ("left", "right") if p[side]["split"] == "validation"}
        relevant[kind] = {"pairs": len(pairs), "validation_queries": len(ids)}
    result = {"query_split": "validation", "query_count": len(per_query),
              "uses_query_gold_labels": False, "uses_official_test_labels": False,
              "dataset_manifest": manifest["fingerprint"], "embedding_keys": index["keys"],
              "unique_intents_distribution": distribution([q["unique_intents"] for q in per_query]),
              "unique_intents_histogram": dict(sorted(Counter(str(q["unique_intents"]) for q in per_query).items())),
              "entropy_bits_distribution": distribution([q["entropy_bits"] for q in per_query]),
              "dominant_vote_threshold": threshold,
              "dominated_proportion": float(np.mean([q["top_label_vote"] >= threshold for q in per_query])),
              "pure_single_intent_proportion": float(np.mean([q["unique_intents"] == 1 for q in per_query])),
              "majority_over_half_proportion": float(np.mean([q["top_label_vote"] > .5 for q in per_query])),
              "overlap": {key: {metric: distribution([q["overlap"][key][metric] for q in per_query])
                                for metric in ("shared", "jaccard")} for key in per_query[0]["overlap"]},
              "known_duplicates": {"existing_audit_exact_pairs": old_audit["exact_cross_split_count"],
                                   "existing_audit_near_pairs": old_audit["near_cross_split_count"],
                                   "validation_vs_demo": relevant,
                                   "note": "Potential lexical leakage only; original test and retrieval unchanged. Normalized exact exclusions remain as Phase 1."},
              "per_query": per_query}
    destination = ROOT / config["results"]
    write_json(destination / "retrieval_diagnostics.json", result)
    print(f"Diagnostics: {len(per_query)} validation queries; mean intents={result['unique_intents_distribution']['mean']:.2f}; "
          f"mean entropy={result['entropy_bits_distribution']['mean']:.3f} bits; dominated={result['dominated_proportion']:.2%}")
    return result
