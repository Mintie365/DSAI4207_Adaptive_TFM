"""Phase 1 components, independent of downstream LLMs and meta-selectors."""
