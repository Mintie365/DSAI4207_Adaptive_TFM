"""Join fixed Phase 2 predictions by query ID, never by row position."""
import numpy as np
from .evaluation import classification_metrics
from .meta_features import STRATEGIES

def evaluate_strategy_choices(query_ids,choices,phase2_records,labels):
    if len(query_ids)!=len(choices) or len(set(query_ids))!=len(query_ids):raise ValueError('Invalid query alignment')
    indexed={}
    for r in phase2_records:
        if r['strategy'] in STRATEGIES:
            key=(r['query_id'],r['strategy'])
            if key in indexed:raise ValueError('Duplicate Phase 2 key')
            indexed[key]=r
    selected=[];similar=[];oracle=[]
    for q,c in zip(query_ids,choices):
        if int(c) not in range(3):raise ValueError('Unknown action')
        options=[indexed[(q,s)] for s in STRATEGIES]
        gold=options[0]['gold_label']
        assert all(r['gold_label']==gold for r in options)
        selected.append(options[int(c)])
        similar.append(options[0]['valid'] and options[0]['predicted_label']==gold)
        oracle.append(any(r['valid'] and r['predicted_label']==gold for r in options))
    correct=np.array([r['valid'] and r['predicted_label']==r['gold_label'] for r in selected],bool)
    similar=np.array(similar,bool);oracle=np.array(oracle,bool);switched=np.array(choices)!=0
    beneficial=int((~similar & correct & switched).sum());harmful=int((similar & ~correct & switched).sum())
    gain=float(correct.mean()-similar.mean())
    assert abs(gain-(beneficial-harmful)/len(query_ids))<1e-12
    assert np.all(correct<=oracle),'Adaptive result exceeds fixed-strategy Oracle'
    metrics={**classification_metrics(selected,labels),'gain_vs_similar':gain,'oracle_gap':float(oracle.mean()-correct.mean()),
             'correct_count':int(correct.sum()),'incorrect_count':int((~correct).sum()),'switch_rate':float(switched.mean()),
             'beneficial':beneficial,'harmful':harmful,'neutral_switches':int((switched & (correct==similar)).sum()),
             'recoverable_similar_errors':int((~similar & oracle).sum()),
             'rescue_rate':beneficial/int((~similar & oracle).sum()) if (~similar & oracle).any() else 0.,
             'selection_distribution':{s:int((np.asarray(choices)==i).sum()) for i,s in enumerate(STRATEGIES)}}
    return metrics,correct,similar,oracle
