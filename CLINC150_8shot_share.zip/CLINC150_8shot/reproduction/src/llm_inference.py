"""Frozen Qwen prediction and separate, exact-continuation teacher-forced scoring."""
from __future__ import annotations

import inspect
import os
import platform
import resource
import time

import torch

from .label_parsing import parse_intent
from .prompting import BuiltPrompt, build_prompt
from .utils import fingerprint, versions


def automatic_device(requested="auto"):
    if requested != "auto":
        return requested
    if torch.cuda.is_available():
        return "cuda"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def inference_dtype(device, requested="auto"):
    if requested != "auto":
        return {"float32": torch.float32, "float16": torch.float16, "bfloat16": torch.bfloat16}[requested]
    if device.startswith("cuda"):
        return torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    return torch.float16 if device.startswith("mps") else torch.float32


def greedy_generation_config(settings, tokenizer):
    from transformers import GenerationConfig
    if settings["do_sample"] is not False or settings["num_beams"] != 1:
        raise ValueError("Only deterministic greedy decoding is allowed")
    return GenerationConfig(do_sample=False, num_beams=1, max_new_tokens=settings["max_new_tokens"],
                            use_cache=settings["use_cache"], repetition_penalty=1.0,
                            bos_token_id=tokenizer.bos_token_id, eos_token_id=tokenizer.eos_token_id,
                            pad_token_id=tokenizer.pad_token_id if tokenizer.pad_token_id is not None else tokenizer.eos_token_id)


def normalized_label_score(prediction_logits, target_ids, target_mask=None):
    """Logits here predict ONLY target-label tokens, never prompt or EOS/padding.

    Shape [batch,target_length,vocab], [batch,target_length]. Caller aligns causal
    shift; mask permits padded synthetic batches and excludes those tokens.
    """
    if prediction_logits.shape[:2] != target_ids.shape:
        raise ValueError("Token/logit shapes disagree")
    mask = torch.ones_like(target_ids, dtype=torch.bool) if target_mask is None else target_mask.bool()
    if mask.shape != target_ids.shape or (mask.sum(dim=1) == 0).any():
        raise ValueError("Every target must contain at least one scored token")
    log_probs = torch.log_softmax(prediction_logits.float(), dim=-1).gather(-1, target_ids.unsqueeze(-1)).squeeze(-1)
    sums = torch.where(mask, log_probs, 0).sum(dim=1)
    counts = mask.sum(dim=1)
    return sums, sums / counts, counts


class QwenInference:
    def __init__(self, config, cache_dir, *, model=None, tokenizer=None):
        self.config = config
        spec = config["model"]
        self.device = automatic_device(spec["device"])
        self.dtype = inference_dtype(self.device, spec["precision"])
        if self.device.startswith("mps") and not torch.backends.mps.is_available():
            raise RuntimeError("MPS is unavailable in this process. Run the command in ordinary macOS Terminal; CPU fallback is not automatic.")
        if self.device.startswith("cuda") and not torch.cuda.is_available():
            raise RuntimeError("CUDA was explicitly requested but is unavailable")
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        torch.manual_seed(config["seed"])
        torch.set_num_threads(spec["cpu_threads"])
        torch.use_deterministic_algorithms(True)
        if self.device.startswith("cuda"):
            torch.backends.cuda.matmul.allow_tf32 = False
            torch.backends.cudnn.allow_tf32 = False
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.tokenizer = tokenizer if tokenizer is not None else AutoTokenizer.from_pretrained(
            spec["checkpoint"], revision=spec["tokenizer_revision"], cache_dir=cache_dir,
            local_files_only=spec["local_files_only"], trust_remote_code=False)
        self.model = model if model is not None else AutoModelForCausalLM.from_pretrained(
            spec["checkpoint"], revision=spec["revision"], cache_dir=cache_dir,
            local_files_only=spec["local_files_only"], trust_remote_code=False,
            torch_dtype=self.dtype, attn_implementation=spec["attention"])
        self.model.to(self.device)
        self.model.requires_grad_(False)
        self.model.eval()
        self.generation_config = greedy_generation_config(config["generation"], self.tokenizer)
        self.identity = {"checkpoint": spec["checkpoint"], "model_revision": spec["revision"],
                         "tokenizer_revision": spec["tokenizer_revision"], "device": self.device,
                         "precision": str(self.dtype), "attention": spec["attention"],
                         "generation": self.generation_config.to_dict(),
                         "chat_template_hash": fingerprint(self.tokenizer.chat_template),
                         "tokenization": {"add_special_tokens": False, "truncation": False, "padding": False},
                         "software": versions(), "cpu_threads": spec["cpu_threads"],
                         "all_parameters_frozen": all(not p.requires_grad for p in self.model.parameters()),
                         "evaluation_mode": not self.model.training,
                         "mps_fallback_environment": os.environ.get("PYTORCH_ENABLE_MPS_FALLBACK", "unset")}

    def _synchronize(self):
        if self.device.startswith("cuda"):
            torch.cuda.synchronize()
        elif self.device.startswith("mps"):
            torch.mps.synchronize()

    def prepare(self, prompt: BuiltPrompt):
        rendered = self.tokenizer.apply_chat_template(prompt.messages, tokenize=False, add_generation_prompt=True)
        batch = self.tokenizer(rendered, add_special_tokens=False, truncation=False, padding=False, return_tensors="pt")
        length = batch["input_ids"].shape[1]
        config_max = self.config["prompt"]["max_input_tokens"]
        context = getattr(self.model.config, "max_position_embeddings", config_max)
        if length > config_max or length + self.config["generation"]["max_new_tokens"] > context:
            raise ValueError(f"Prompt length {length} exceeds configured/model context; truncation is forbidden")
        return {key: value.to(self.device) for key, value in batch.items()}, rendered

    def memory_metadata(self):
        peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        result = {"process_peak_rss_bytes": int(peak if platform.system() == "Darwin" else peak * 1024)}
        if self.device.startswith("cuda"):
            result["cuda_peak_allocated_bytes"] = torch.cuda.max_memory_allocated()
        elif self.device.startswith("mps"):
            result["mps_current_allocated_bytes"] = torch.mps.current_allocated_memory()
        return result

    def predict_prepared(self, prompt, valid_labels, batch=None):
        if batch is None:
            batch, _ = self.prepare(prompt)
        length = batch["input_ids"].shape[1]
        self._synchronize()
        start = time.perf_counter()
        with torch.inference_mode():
            generated = self.model.generate(**batch, generation_config=self.generation_config)
        self._synchronize()
        elapsed = time.perf_counter() - start
        new_tokens = generated[0, length:]
        raw = self.tokenizer.decode(new_tokens, skip_special_tokens=True, clean_up_tokenization_spaces=False)
        return {**parse_intent(raw, valid_labels), "prompt_tokens": length,
                "generated_tokens": len(new_tokens), "runtime_seconds": elapsed,
                "prompt_hash": prompt.prompt_hash, "memory": self.memory_metadata(),
                "inference_identity_hash": fingerprint(self.identity)}

    def predict_intent(self, query, demonstrations, valid_labels):
        prompt = build_prompt(query, demonstrations, valid_labels, k=self.config["k"],
                              version=self.config["prompt"]["version"])
        return self.predict_prepared(prompt, valid_labels)

    def score_label(self, query, demonstrations, target_label, valid_labels):
        """Phase 3 utility only; not called by Phase 2 baseline evaluation.

        Tokenize the exact rendered prefix+canonical label jointly and verify that
        tokenization preserves the prompt boundary. Score the label without EOS.
        """
        if target_label not in valid_labels:
            raise ValueError("Scoring requires an exact canonical candidate label")
        prompt = build_prompt(query, demonstrations, valid_labels, k=self.config["k"],
                              version=self.config["prompt"]["version"])
        prefix, rendered = self.prepare(prompt)
        full = self.tokenizer(rendered + target_label, add_special_tokens=False, truncation=False,
                               padding=False, return_tensors="pt")
        n_prefix = prefix["input_ids"].shape[1]
        if not torch.equal(full["input_ids"][:, :n_prefix].cpu(), prefix["input_ids"].cpu()):
            raise ValueError("Tokenizer merges across response boundary; cannot score with an ambiguous mask")
        count = full["input_ids"].shape[1] - n_prefix
        if count < 1 or full["input_ids"].shape[1] > self.model.config.max_position_embeddings:
            raise ValueError("Target is empty or exceeds context")
        batch = {key: value.to(self.device) for key, value in full.items()}
        extra = {"logits_to_keep": count + 1} if "logits_to_keep" in inspect.signature(self.model.forward).parameters else {}
        with torch.inference_mode():
            logits = self.model(**batch, **extra).logits[:, -(count + 1):-1]
            summed, mean, counts = normalized_label_score(logits, batch["input_ids"][:, n_prefix:])
        return {"target_label": target_label, "label_token_count": int(counts.item()),
                "sum_log_likelihood": float(summed.item()), "mean_log_likelihood": float(mean.item()),
                "includes_eos": False, "prompt_tokens": n_prefix, "prompt_hash": prompt.prompt_hash}
