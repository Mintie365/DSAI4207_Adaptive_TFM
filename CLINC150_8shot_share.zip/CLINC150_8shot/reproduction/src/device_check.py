"""Reproducible device probe; run in both Codex and ordinary macOS Terminal."""
from __future__ import annotations

import argparse
import os
import platform
import subprocess
import sys
import time

import torch

from .utils import write_json


def device_report(context):
    result = {"context": context, "python_executable": sys.executable,
              "python_version": platform.python_version(), "platform": platform.platform(),
              "machine": platform.machine(), "torch_version": torch.__version__,
              "mps_built": torch.backends.mps.is_built(), "mps_available": torch.backends.mps.is_available(),
              "cuda_available": torch.cuda.is_available(), "mps_tensor_test": None,
              "pytorch_enable_mps_fallback": os.environ.get("PYTORCH_ENABLE_MPS_FALLBACK", "unset")}
    try:
        result["cpu_brand"] = subprocess.check_output(["sysctl", "-n", "machdep.cpu.brand_string"], stderr=subprocess.DEVNULL, text=True).strip()
        result["physical_memory_bytes"] = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"], stderr=subprocess.DEVNULL, text=True))
    except (OSError, subprocess.CalledProcessError, ValueError):
        result["hardware_query_note"] = "Hardware sysctl inaccessible in this process"
    if result["mps_available"]:
        try:
            start = time.perf_counter()
            value = torch.ones((64, 64), device="mps")
            answer = (value @ value).sum().item()
            torch.mps.synchronize()
            result["mps_tensor_test"] = {"passed": answer == 262144, "device": str(value.device),
                                         "seconds": time.perf_counter() - start,
                                         "allocated_bytes": torch.mps.current_allocated_memory()}
        except RuntimeError as error:
            result["mps_tensor_test"] = {"passed": False, "error": str(error)}
    return result


def main():
    import json
    parser = argparse.ArgumentParser()
    parser.add_argument("--context", default="macos-terminal")
    parser.add_argument("--output")
    args = parser.parse_args()
    result = device_report(args.context)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if args.output:
        write_json(args.output, result)


if __name__ == "__main__":
    main()
