"""Gold-free atomic inference cache, plus crash-recoverable evaluation JSONL."""
from __future__ import annotations

import json
import os
from pathlib import Path

from .utils import fingerprint, read_json, write_json


def inference_key(identity):
    forbidden = {"gold_label", "gold", "query_label", "target_label"}
    if forbidden & set(identity):
        raise ValueError("Gold labels must not enter inference cache identity")
    return fingerprint(identity)


class PredictionCache:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def get(self, identity):
        key = inference_key(identity)
        path = self.root / f"{key}.json"
        if not path.exists():
            return None
        record = read_json(path)
        if (record["identity"] != identity or record["key"] != key or
            fingerprint(record["prediction"]) != record["prediction_sha256"]):
            raise ValueError("Prediction cache integrity failed")
        return record["prediction"]

    def put(self, identity, prediction):
        if "gold_label" in prediction:
            raise ValueError("Inference cache must not store evaluation gold labels")
        key = inference_key(identity)
        write_json(self.root / f"{key}.json", {"key": key, "identity": identity, "prediction": prediction,
                                               "prediction_sha256": fingerprint(prediction)})
        return key


def append_record(path, record):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def read_records(path, repair_partial_tail=True):
    path = Path(path)
    if not path.exists():
        return []
    data = path.read_bytes()
    lines = data.splitlines(keepends=True)
    result, offset = [], 0
    for i, line in enumerate(lines):
        try:
            record = json.loads(line)
        except (ValueError, UnicodeDecodeError):
            if i != len(lines) - 1 or line.endswith(b"\n") or not repair_partial_tail:
                raise ValueError("Malformed evaluation JSONL (not a partial final write)")
            path.with_suffix(path.suffix + ".partial-tail").write_bytes(line)
            with path.open("r+b") as stream:
                stream.truncate(offset)
            break
        result.append(record)
        offset += len(line)
    # A complete JSON value without the final newline is also safe to resume.
    if lines and result and not lines[-1].endswith(b"\n") and len(result) == len(lines):
        with path.open("ab") as stream:
            stream.write(b"\n")
    keys = [r["cache_key"] for r in result]
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate evaluation records")
    return result
