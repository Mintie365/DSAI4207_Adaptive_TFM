"""Run authorized MPS full validation and zero-shot with the existing controls.

This adds orchestration/logging only; Phase 1 and ICL prompt/selection code stay fixed.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import time

import yaml
from filelock import FileLock

from .experiment_cache import PredictionCache, append_record, inference_key, read_records
from .llm_inference import QwenInference
from .phase2_data import load_phase2_config, load_phase2_inputs, stratified_query_order
from .phase2_pipeline import run_experiment
from .prompting import build_prompt
from .utils import ROOT, fingerprint, read_json, write_json


def load_analysis_config(path="configs/phase2_analysis.yaml"):
    return yaml.safe_load((ROOT / path).read_text(encoding="utf-8"))


def prepare_analysis_plan(config, analysis):
    """Freeze cutpoints from candidate labels before inspecting full outcomes."""
    import numpy as np
    _, frames, _, _, manifest, _ = load_phase2_inputs(config)
    diagnostics = read_json(ROOT / config["results"] / "retrieval_diagnostics.json")
    assert diagnostics["dataset_manifest"] == manifest["fingerprint"]
    assert len(frames["validation"]) == analysis["expected_queries"]
    values = [q["entropy_bits"] for q in diagnostics["per_query"]]
    plan = {"analysis": analysis, "dataset_manifest": manifest["fingerprint"],
            "entropy_cutpoints_bits": np.quantile(values, analysis["ambiguity"]["quantiles"]).tolist(),
            "phase2_config": config,
            "zero_shot_definition": "build_prompt(query, [], labels, k=0): unchanged instructions/labels/chat template; empty Demonstrations section",
            "uses_official_test": False, "fixed_before_full_prediction_analysis": True}
    path = ROOT / analysis["output"] / "analysis_plan.json"
    if path.exists():
        if read_json(path) != plan:
            raise ValueError("Existing preregistered analysis plan differs; use a separate output directory")
    else:
        write_json(path, plan)
    return plan


class LoggedInference:
    """Count every actual generate call, including consistency repeats, without changing identity."""
    def __init__(self, engine, log_path):
        self.engine, self.log_path = engine, log_path
        self.identity, self.device = engine.identity, engine.device
        self.context = "initializing"

    def prepare(self, prompt):
        return self.engine.prepare(prompt)

    def predict_prepared(self, prompt, valid_labels, batch=None):
        result = self.engine.predict_prepared(prompt, valid_labels, batch)
        append_record(self.log_path, {"timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "context": self.context, "prompt_hash": prompt.prompt_hash,
            "actual_device": self.device, "precision": self.identity["precision"],
            "valid": result["valid"], "prompt_tokens": result["prompt_tokens"],
            "runtime_seconds": result["runtime_seconds"], "memory": result["memory"]})
        return result


def run_zero_shot(config, analysis, engine, controls_hash, *, max_new_predictions=None):
    _, frames, _, labels, manifest, _ = load_phase2_inputs(config)
    root = ROOT / analysis["output"]
    identity = {"mode": "zero_shot", "controls_hash": controls_hash,
                "dataset_manifest": manifest["fingerprint"], "definition": analysis["zero_shot"]}
    run_id = fingerprint(identity)[:16]
    destination = root / f"zero_shot_{run_id}"
    destination.mkdir(parents=True, exist_ok=True)
    cache = PredictionCache(ROOT / config["results"] / "inference_cache")
    with FileLock(str(destination / ".writer.lock"), timeout=0):
        write_json(destination / "experiment_config.json", {"run_id": run_id, "phase2": config,
                   "zero_shot": analysis["zero_shot"], "inference": engine.identity, "controls_hash": controls_hash})
        path = destination / "zero_shot_predictions.jsonl"
        records = read_records(path)
        done = {r["cache_key"]: r for r in records}
        new_calls, hits = 0, 0
        start = time.perf_counter()
        for position in stratified_query_order(frames["validation"], config["seed"]):
            row = frames["validation"].iloc[position]
            prompt = build_prompt(str(row.text), [], labels, k=0, version=config["prompt"]["version"])
            batch, _ = engine.prepare(prompt)
            key_identity = {"query_id": str(row.example_id), "query_text": str(row.text), "strategy": "zero_shot",
                "random_seed": None, "demonstration_ids": [], "prompt_hash": prompt.prompt_hash,
                "template_hash": prompt.template_hash,
                "token_ids_hash": fingerprint(batch["input_ids"].detach().cpu().tolist()), "controls_hash": controls_hash}
            key = inference_key(key_identity)
            cached = cache.get(key_identity)
            if key in done:
                if cached is None or any(cached[k] != done[key][k] for k in ("raw_output", "predicted_label", "valid")):
                    raise ValueError("Zero-shot log/cache mismatch")
                hits += 1
                continue
            if max_new_predictions is not None and new_calls >= max_new_predictions:
                break
            cache_hit = cached is not None
            if cached is None:
                prediction = engine.predict_prepared(prompt, labels, batch)
                cache.put(key_identity, prediction)
                new_calls += 1
            else:
                prediction = cached
                hits += 1
            record = {**prediction, "cache_key": key, "query_id": str(row.example_id),
                "gold_label": str(row.label_name), "strategy": "zero_shot", "random_seed": None,
                "demonstration_ids": [], "candidate_ids": [], "cache_hit": cache_hit,
                "actual_device": engine.device, "controls_hash": controls_hash, "run_id": run_id}
            append_record(path, record)
            records.append(record)
            done[key] = record
            print(f"[zero-shot] {len(records)}/{len(frames['validation'])} valid={record['valid']} "
                  f"{record['runtime_seconds']:.3f}s device={engine.device}", flush=True)
        complete = len({r["query_id"] for r in records}) == len(frames["validation"]) == len(records)
        session = {"complete": complete, "records": len(records), "run_id": run_id,
                   "controls_hash": controls_hash, "new_inference_calls": new_calls, "cache_hits": hits,
                   "session_wall_seconds": time.perf_counter()-start, "device": engine.device}
        append_record(destination / "execution_sessions.jsonl", session)
        write_json(destination / "status.json", session)
        write_json(root / "latest_zero_shot.json", {"run_directory": destination.name})
    return destination, complete


def run_all(config, analysis):
    if config["model"]["device"] != "mps":
        raise ValueError("This experiment is fixed to MPS FP16; CPU fallback is forbidden")
    plan = prepare_analysis_plan(config, analysis)
    root = ROOT / analysis["output"]
    root.mkdir(parents=True, exist_ok=True)
    with FileLock(str(root / ".full_experiment.lock"), timeout=0):
        phase1, _, _, _, _, _ = load_phase2_inputs(config)
        engine = LoggedInference(QwenInference(config, phase1["paths"]["hub_cache"]), root / "inference_calls.jsonl")
        if engine.device != "mps" or engine.identity["precision"] != "torch.float16":
            raise RuntimeError("Required MPS FP16 is unavailable; experiment stopped")
        snapshot = {"analysis_plan": plan, "inference": engine.identity, "phase1": phase1,
                    "pilot_a_snapshot": read_json(ROOT/config["results"]/read_json(ROOT/config["results"]/"latest_pilot_a.json")["run_directory"]/"experiment_config.json")}
        snapshot_path = root / "experiment_config.json"
        if snapshot_path.exists() and read_json(snapshot_path) != snapshot:
            raise ValueError("Full experiment snapshot differs from previous run")
        write_json(snapshot_path, snapshot)
        for stage, count in (("pilot-b", 128), ("full", None)):
            engine.context = stage
            for attempt in range(20):
                start = time.perf_counter()
                directory, status = run_experiment(config, stage, query_count=count, inference=engine)
                append_record(root / "execution_sessions.jsonl", {"stage": stage, "attempt": attempt,
                    "run_directory": str(directory.relative_to(ROOT)), "wall_seconds": time.perf_counter()-start,
                    "status": status, "runtime": read_json(directory / "runtime.json")})
                if status["complete"]:
                    break
                if status["stop_reason"] != "session_wall_time_limit":
                    raise RuntimeError(f"{stage} did not complete: {status['stop_reason']}")
            else:
                raise RuntimeError("Resumption limit exceeded; rerun after inspecting logs")
        full_directory = directory
        controls_hash = status["controls_hash"]
        engine.context = "zero_shot"
        zero_directory, complete = run_zero_shot(config, analysis, engine, controls_hash)
        if not complete:
            raise RuntimeError("Zero-shot incomplete")
        write_json(root / "source_runs.json", {"full_directory": str(full_directory.relative_to(ROOT)),
                   "zero_directory": str(zero_directory.relative_to(ROOT)), "controls_hash": controls_hash,
                   "full_run_id": read_json(full_directory/"experiment_config.json")["run_id"]})
        print("All full-validation predictions completed; run python -m src.full_validation_analysis", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/phase2.yaml")
    parser.add_argument("--analysis-config", default="configs/phase2_analysis.yaml")
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    config = deepcopy(load_phase2_config(args.config))
    config["model"]["device"] = "mps"
    analysis = load_analysis_config(args.analysis_config)
    if args.prepare_only:
        prepare_analysis_plan(config, analysis)
    else:
        run_all(config, analysis)


if __name__ == "__main__":
    main()
