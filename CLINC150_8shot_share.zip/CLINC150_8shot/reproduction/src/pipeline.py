"""Run with python -m src.pipeline --help."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from .utils import load_config, write_json


def main():
    parser = argparse.ArgumentParser(description="DSAI4207 Phase 1; no LLM inference")
    parser.add_argument("--config", default="configs/phase1.yaml")
    commands = parser.add_subparsers(dest="command", required=True)
    for command in ("prepare", "embed", "demo", "all"):
        commands.add_parser(command)
    query_parser = commands.add_parser("query")
    query_parser.add_argument("--text", required=True)
    query_parser.add_argument("--strategy", choices=("all", "random", "similar", "diverse", "balanced"), default="all")
    query_parser.add_argument("--k", type=int)
    query_parser.add_argument("--seed", type=int)
    query_parser.add_argument("--output", help="Optional JSON output path")
    args = parser.parse_args()
    config = load_config(args.config)
    from .prepare_data import load_prepared, prepare_data
    from .embeddings import generate_embeddings, load_embeddings, SentenceEncoder
    from .demo import run_demo
    from .retrieval import SemanticRetriever
    from .selection import STRATEGIES, select_demonstrations

    if args.command in ("prepare", "all"):
        splits, manifest = prepare_data(config)
    else:
        splits, manifest = load_prepared(config)
    if args.command in ("embed", "all"):
        generate_embeddings(config, splits, manifest)
    if args.command in ("demo", "all", "query"):
        arrays, index = load_embeddings(config, splits, manifest)
        if args.command != "query":
            run_demo(config, splits, arrays, manifest, index)
        else:
            k = args.k if args.k is not None else config["selection"]["k"]
            if k not in config["selection"]["supported_k"]:
                parser.error("--k must belong to configured supported_k")
            encoder = SentenceEncoder(config, index["resolved_revision"])
            vector = encoder.encode([args.text])[0]
            retriever = SemanticRetriever(splits["demonstration_pool"], arrays["demonstration_pool"],
                                          config["retrieval"]["exclude_identical_text"])
            pool = retriever.retrieve(vector, config["retrieval"]["candidate_pool_size"], query_text=args.text)
            query_id = "custom_" + hashlib.sha256(args.text.encode()).hexdigest()[:16]
            strategies = STRATEGIES if args.strategy == "all" else [args.strategy]
            result = {"query_id": query_id, "query_text": args.text,
                      "candidate_pool": [c.as_dict() for c in pool],
                      "selections": [select_demonstrations(
                          vector, pool, s, k, args.seed if args.seed is not None else config["seed"],
                          mmr_lambda=config["selection"]["mmr_lambda"],
                          query_id=query_id, query_text=args.text) for s in strategies]}
            print(json.dumps(result, ensure_ascii=False, indent=2))
            if args.output:
                write_json(Path(args.output), result)


if __name__ == "__main__":
    main()
