"""Conservative canonical lookup; punctuation in official labels is meaningful."""
from __future__ import annotations


def parse_intent(raw_output: str, valid_labels):
    canonical = {}
    for label in valid_labels:
        canonical.setdefault(label.casefold(), []).append(label)
    value = raw_output.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'", '`'):
        value = value[1:-1].strip()
    matches = canonical.get(value.casefold(), [])
    valid = len(matches) == 1
    return {"predicted_label": matches[0] if valid else None, "valid": valid,
            "parse_status": "canonical_match" if valid else "invalid_or_ambiguous",
            "raw_output": raw_output}
