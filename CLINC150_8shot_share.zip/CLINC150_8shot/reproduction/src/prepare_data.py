"""Official-source ingestion, stratified partitions and a read-only leakage audit."""
from __future__ import annotations

from collections import defaultdict
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split

from .utils import SPLITS, fingerprint, normalized_text, read_json, versions, write_json


def source_frame(dataset, source_split, label_names):
    """Stable IDs identify rows in an immutable official source, not new split positions."""
    frame = dataset.to_pandas()[["text", "label"]].copy()
    if not frame["text"].map(lambda t: isinstance(t, str) and bool(t.strip())).all():
        raise ValueError("Source contains missing or empty text")
    frame["label"] = frame["label"].astype(int)
    if not frame.label.isin(range(len(label_names))).all():
        raise ValueError("Source label is outside ClassLabel metadata")
    frame.insert(0, "example_id", [f"{source_split}_{i:06d}" for i in range(len(frame))])
    frame["source_split"] = source_split
    frame["label_name"] = frame.label.map(dict(enumerate(label_names)))
    return frame


def stratified_splits(train, test, sizes, seed=42):
    if set(sizes) != set(SPLITS[:-1]) or any(type(n) is not int or n <= 0 for n in sizes.values()):
        raise ValueError("Provide positive integer sizes for the three training partitions")
    if sum(sizes.values()) != len(train):
        raise ValueError("Training split sizes must sum to official training size")
    demo, remainder = train_test_split(train, train_size=sizes["demonstration_pool"],
                                       stratify=train.label, random_state=seed)
    meta, val = train_test_split(remainder, train_size=sizes["meta_training"],
                                 stratify=remainder.label, random_state=seed)
    splits = dict(zip(SPLITS, (demo, meta, val, test.copy())))
    return {name: frame.assign(partition=name).sort_values("example_id").reset_index(drop=True)
            for name, frame in splits.items()}


def validate_splits(splits, label_names, expected_sizes=None):
    if set(splits) != set(SPLITS):
        raise ValueError("Unexpected partition names")
    seen = set()
    for name, frame in splits.items():
        ids = set(frame.example_id)
        if len(ids) != len(frame) or seen & ids:
            raise ValueError("Partition IDs must be unique and mutually exclusive")
        seen.update(ids)
        if expected_sizes is not None and len(frame) != expected_sizes[name]:
            raise ValueError(f"Unexpected sample count for {name}")
        expected_source = "test" if name == "test" else "train"
        if not frame.source_split.eq(expected_source).all():
            raise ValueError(f"Official source leakage in {name}")
        if not frame.partition.eq(name).all():
            raise ValueError(f"Partition provenance mismatch in {name}")
        if not frame.label.isin(range(len(label_names))).all():
            raise ValueError("Invalid label IDs")
        if frame.label.nunique() != len(label_names):
            raise ValueError(f"{name} does not represent every class; adjust split sizes")
        expected = frame.label.map(dict(enumerate(label_names)))
        if not frame.label_name.eq(expected).all():
            raise ValueError("Label ID/name mapping mismatch")


def duplicate_audit(splits, threshold=0.9, batch_size=256):
    """Enumerate all cross-partition normalized matches and high lexical-cosine pairs.

    TF-IDF is fitted ONLY for this audit, never as a predictive/retrieval feature.
    Character word-boundary 3–5 grams detect lexical near duplicates, not paraphrases.
    """
    if not 0 < threshold <= 1 or batch_size < 1:
        raise ValueError("Invalid audit threshold or batch size")
    records = []
    groups = defaultdict(list)
    for name, frame in splits.items():
        for row in frame.to_dict("records"):
            entry = {"example_id": row["example_id"], "split": name,
                     "text": row["text"]}
            entry["normalized"] = normalized_text(row["text"])
            groups[entry["normalized"]].append(len(records))
            records.append(entry)

    def pair(i, j, score):
        return {"left": {k: v for k, v in records[i].items() if k != "normalized"},
                "right": {k: v for k, v in records[j].items() if k != "normalized"},
                "similarity": float(score)}

    exact, near = [], []
    for indices in groups.values():
        for i, j in combinations(indices, 2):
            if records[i]["split"] != records[j]["split"]:
                exact.append(pair(i, j, 1.0))
    vectorizer = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), dtype=np.float32)
    matrix = vectorizer.fit_transform([r["normalized"] for r in records])
    for start in range(0, len(records), batch_size):
        similarities = (matrix[start:start + batch_size] @ matrix.T).tocoo()
        for local_i, j, score in zip(similarities.row, similarities.col, similarities.data):
            i = start + int(local_i)
            j = int(j)
            if j <= i or score < threshold or records[i]["split"] == records[j]["split"]:
                continue
            if records[i]["normalized"] != records[j]["normalized"]:
                near.append(pair(i, j, score))
    key = lambda p: (p["left"]["example_id"], p["right"]["example_id"])
    return {"method": "NFKC/casefold/punctuation/whitespace exact + char_wb TF-IDF(3,5) cosine",
            "threshold": threshold, "official_test_modified": False,
            "exact_cross_split_count": len(exact), "near_cross_split_count": len(near),
            "exact_pairs": sorted(exact, key=key), "near_pairs": sorted(near, key=key)}


def frame_fingerprint(frame):
    return fingerprint(frame.to_dict("records"))


def prepare_data(config):
    from datasets import load_dataset
    from huggingface_hub import HfApi

    spec = config["dataset"]
    revision = HfApi().dataset_info(spec["name"], revision=spec["revision"]).sha
    dataset = load_dataset(spec["name"], revision=revision, cache_dir=config["paths"]["hub_cache"])
    names = list(dataset["train"].features["label"].names)
    if list(dataset["test"].features["label"].names) != names:
        raise ValueError("Official splits disagree on label metadata")
    if len(names) != spec["expected_classes"]:
        raise ValueError("Unexpected number of classes")
    train = source_frame(dataset["train"], "train", names)
    test = source_frame(dataset["test"], "test", names)
    if (len(train), len(test)) != (spec["expected_train"], spec["expected_test"]):
        raise ValueError("Unexpected official dataset sizes")
    raw = Path(config["paths"]["raw"])
    raw.mkdir(parents=True, exist_ok=True)
    train.to_csv(raw / "official_train.csv", index=False)
    test.to_csv(raw / "official_test.csv", index=False)
    splits = stratified_splits(train, test, spec["sizes"], config["seed"])
    validate_splits(splits, names, {**spec["sizes"], "test": len(test)})
    audit = duplicate_audit(splits, config["audit"]["near_duplicate_threshold"],
                            config["audit"]["batch_size"])
    destination = Path(config["paths"]["splits"])
    destination.mkdir(parents=True, exist_ok=True)
    mapping = {"id_to_label": {str(i): name for i, name in enumerate(names)},
               "label_to_id": {name: i for i, name in enumerate(names)}}
    stats = {}
    for name, frame in splits.items():
        frame.to_csv(destination / f"{name}.csv", index=False)
        stats[name] = {"count": len(frame), "num_classes": int(frame.label.nunique()),
                       "label_distribution": {str(k): int(v) for k, v in sorted(frame.label.value_counts().items())},
                       "fingerprint": frame_fingerprint(frame)}
    manifest = {"schema_version": 1, "dataset": spec["name"], "resolved_revision": revision,
                "requested_revision": spec["revision"], "source_columns": list(dataset["train"].column_names),
                "audit_settings": config["audit"],
                "source_fingerprints": {s: dataset[s]._fingerprint for s in ("train", "test")},
                "seed": config["seed"], "split_algorithm": "two sequential stratified train_test_split; sorted source IDs",
                "label_mapping_fingerprint": fingerprint(mapping), "splits": stats,
                "software": versions()}
    manifest["fingerprint"] = fingerprint(manifest)
    write_json(destination / "label_mapping.json", mapping)
    write_json(destination / "duplicate_report.json", audit)
    write_json(destination / "dataset_statistics.json", {
        "splits": stats, "examples": {s: f.head(3).to_dict("records") for s, f in splits.items()},
        "text_lengths": {s: {k: float(v) for k, v in f.text.str.len().describe().items()}
                         for s, f in splits.items()}})
    write_json(destination / "split_manifest.json", manifest)
    for name, values in stats.items():
        print(f"{name}: {values['count']:,} samples; {values['num_classes']} intents")
    print(f"Cross-split duplicates: {len(audit['exact_pairs'])} normalized exact; {len(audit['near_pairs'])} lexical near")
    return splits, manifest


def load_prepared(config):
    destination = Path(config["paths"]["splits"])
    manifest = read_json(destination / "split_manifest.json")
    recorded = manifest["fingerprint"]
    if fingerprint({k: v for k, v in manifest.items() if k != "fingerprint"}) != recorded:
        raise ValueError("Manifest integrity check failed")
    spec = config["dataset"]
    if (manifest["dataset"] != spec["name"] or manifest["seed"] != config["seed"] or
        manifest["requested_revision"] != spec["revision"]):
        raise ValueError("Data configuration changed; rerun prepare")
    expected_sizes = {**spec["sizes"], "test": spec["expected_test"]}
    if sum(spec["sizes"].values()) != spec["expected_train"]:
        raise ValueError("Configured training counts are inconsistent")
    if manifest["audit_settings"] != config["audit"]:
        raise ValueError("Audit configuration changed; rerun prepare")
    mapping = read_json(destination / "label_mapping.json")
    if fingerprint(mapping) != manifest["label_mapping_fingerprint"]:
        raise ValueError("Label mapping changed")
    names = [mapping["id_to_label"][str(i)] for i in range(len(mapping["id_to_label"]))]
    if len(names) != spec["expected_classes"]:
        raise ValueError("Configured class count changed")
    splits = {name: pd.read_csv(destination / f"{name}.csv", keep_default_na=False) for name in SPLITS}
    validate_splits(splits, names, expected_sizes)
    for name, frame in splits.items():
        if frame_fingerprint(frame) != manifest["splits"][name]["fingerprint"]:
            raise ValueError(f"Saved {name} data changed; rerun prepare")
    return splits, manifest
