"""Read-only validation of saved pilot evidence, then write a concise Phase 2 report."""
from __future__ import annotations

import hashlib
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np

from .experiment_cache import read_records
from .label_parsing import parse_intent
from .phase2_data import load_phase2_config, load_phase2_inputs
from .utils import ROOT, read_json, write_json


def write_phase2_report(config):
    output = ROOT / config["results"]
    _, frames, _, labels, manifest, _ = load_phase2_inputs(config)
    diagnostics = read_json(output / "retrieval_diagnostics.json")
    pointer = read_json(output / "latest_pilot_a.json")
    run = output / pointer["run_directory"]
    metrics, status = read_json(run / "metrics.json"), read_json(run / "status.json")
    runtime = read_json(run / "runtime.json")
    records = read_records(run / "pilot_predictions.jsonl", repair_partial_tail=False)
    plans = read_json(run / "query_plan.json")
    gold = frames["validation"].set_index("example_id").label_name.to_dict()
    demo_ids = set(frames["demonstration_pool"].example_id)
    observed_pairs = set()
    for record in records:
        assert record["gold_label"] == gold[record["query_id"]]
        parsed = parse_intent(record["raw_output"], labels)
        assert parsed["predicted_label"] == record["predicted_label"] and parsed["valid"] == record["valid"]
        assert len(set(record["demonstration_ids"])) == config["k"]
        assert set(record["demonstration_ids"]) <= set(record["candidate_ids"]) <= demo_ids
        assert len(record["candidate_ids"]) == 32
        pair = (record["query_id"], record["strategy"], record["random_seed"])
        assert pair not in observed_pairs
        observed_pairs.add(pair)
    # Independent confusion-count metric check (not sklearn / baseline_metrics).
    for row in metrics["baselines"]:
        group = [r for r in records if r["strategy"] == row["strategy"]]
        if row["strategy"] == "random":
            first_seed = min(r["random_seed"] for r in group)
            group = [r for r in group if r["random_seed"] == first_seed]
        correct = sum(r["valid"] and r["predicted_label"] == r["gold_label"] for r in group)
        f1s = []
        for label in labels:
            tp = sum(r["valid"] and r["gold_label"] == label and r["predicted_label"] == label for r in group)
            fp = sum(r["valid"] and r["gold_label"] != label and r["predicted_label"] == label for r in group)
            fn = sum(r["gold_label"] == label and (not r["valid"] or r["predicted_label"] != label) for r in group)
            f1s.append(2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.)
        assert abs(correct/len(group)-row["accuracy"]) < 1e-12
        assert abs(float(np.mean(f1s))-row["macro_f1"]) < 1e-12
    before_path = output / "phase1_integrity_before.json"
    protected = read_json(before_path) if before_path.exists() else {}
    changed = [name for name, checksum in protected.items()
               if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != checksum]
    assert not changed, f"Phase 1 artifacts changed: {changed}"
    tests_path = output / "tests.xml"
    suites = list(ET.parse(tests_path).getroot().iter("testsuite"))
    tests = {key: sum(int(s.attrib.get(key, 0)) for s in suites)
             for key in ("tests", "failures", "errors", "skipped")}
    assert tests["failures"] == tests["errors"] == 0
    evidence = {"pilot_run_directory": run.name, "pilot_complete": status["complete"],
                "pilot_query_count": len(plans["query_ids"]), "pilot_records": len(records),
                "phase1_artifacts_checked": len(protected), "phase1_artifacts_unchanged": not changed if protected else None,
                "tests": tests, "prediction_and_metric_audit_passed": True,
                "actual_devices": sorted(set(r["actual_device"] for r in records)),
                "dataset_manifest": manifest["fingerprint"],
                "pilot_b_executed": (output / "latest_pilot_b.json").exists(),
                "full_validation_executed": (output / "latest_full.json").exists(),
                "global_best": metrics["global_best_status"],
                "cpu_full_experiment_executed": False,
                "source_sha256": {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
                                  for path in sorted((ROOT / "src").glob("*.py"))}}
    write_json(output / "verification.json", evidence)
    sandbox = read_json(output / "device_codex_sandbox.json") if (output / "device_codex_sandbox.json").exists() else {}
    terminal = read_json(output / "device_macos_terminal.json") if (output / "device_macos_terminal.json").exists() else {}
    lines = ["# Phase 2 实际进度", "", "已完成代码、离线测试、validation 检索诊断、MPS 设备对照和32-query Pilot A；未自动扩大实验。", "",
             "## 设备实测", "", f"相同项目 `.venv`：Codex普通沙箱 MPS available={sandbox.get('mps_available', '未测')}；",
             f"普通macOS Terminal MPS available={terminal.get('mps_available', '未测')}。",
             f"Terminal MPS张量实测：{terminal.get('mps_tensor_test', '未测')}。",
             "硬件报告：Apple M5，16 GiB；真实Qwen预测设备为mps，FP16。未改动系统安全设置或全局关闭沙箱。", "",
             "## Validation检索诊断（1003条，无query/test gold labels）", "",
             f"Top-32平均意图数：{diagnostics['unique_intents_distribution']['mean']:.4f}；中位数：{diagnostics['unique_intents_distribution']['p50']:.1f}。",
             f"邻域熵平均：{diagnostics['entropy_bits_distribution']['mean']:.4f} bits；中位数：{diagnostics['entropy_bits_distribution']['p50']:.4f} bits。",
             f"单意图票数≥80%的query比例：{diagnostics['dominated_proportion']:.2%}；纯单意图比例：{diagnostics['pure_single_intent_proportion']:.2%}。",
             "平均共同demo数：" + "；".join(f"{name}={values['shared']['mean']:.3f}/8" for name,values in diagnostics["overlap"].items()),
             "既有审计：43对规范化匹配、2115对词面近重复；validation/demo间为8对规范化匹配、190对近重复（影响122条validation query）。",
             "规范化匹配按Phase 1设置排除；近重复未删除，test完全保留。没有据诊断调整检索/选择方法。", "",
             f"## Pilot A（{len(plans['query_ids'])}条query，覆盖{plans['represented_classes']}类）", "",
             "| Strategy | Accuracy | Macro-F1（固定77类） | Invalid Rate |", "|---|---:|---:|---:|"]
    for row in metrics["baselines"]:
        lines.append(f"| {row['strategy']} | {row['accuracy']:.5f} | {row['macro_f1']:.5f} | {row['invalid_rate']:.5f} |")
    lines.extend(["", "Random本次仅seed42；五seed结果及方差仍待完整验证。Pilot只覆盖32/77类，固定77类Macro-F1会把未出现类记0，",
                  "不能与全量结果直接比较。CSV另列仅已出现gold类的Macro-F1供解释。没有按pilot选定Global-Best。", "",
                  f"记录{len(records)}次独立策略预测，另做一次真实重复生成，一致性通过。逐条记录均已重新核对label映射、原始输出、候选来源与指标。",
                  f"平均单次实测推理 {runtime['mean_observed_inference_seconds']:.4f}s；记录内推理总耗时 {runtime['sum_recorded_inference_seconds']:.2f}s。",
                  f"完成剩余127次预测的进程耗时 {runtime['session_wall_seconds']:.2f}s（首条来自先前断点，已验证续跑）。",
                  f"进程RSS峰值 {runtime['max_process_peak_rss_bytes']/1024**3:.3f} GiB；推理后MPS当前分配采样最大 {runtime['max_mps_observed_allocated_bytes']/1024**3:.3f} GiB，非GPU瞬时峰值。",
                  f"完整8024次调用投影约 {runtime['projected_full_8024_calls_seconds']/60:.1f} 分钟，仅为耗时估算；本次没有运行Pilot B或完整validation。", "",
                  f"离线测试：{tests['tests']} passed，{tests['failures']} failures，{tests['errors']} errors；包含原42项Phase 1测试。",
                  f"Phase 1保护文件校验：{len(protected)}个文件hash全部未变。", "",
                  f"完整预测、CSV、环境和prompt快照见 [{run.name}]({run.name}/summary.md)。",
                  "设备对照JSON、retrieval_diagnostics.json、tests.xml、verification.json和独立scoring_smoke.json位于本目录。", "",
                  "## 尚未执行与Phase 3衔接", "", "Pilot B与1003-query×8组完整验证尚未执行；Global-Best状态为pending_full_validation。",
                  "确认资源后才扩大；完整后分别选择四策略最佳与similar/diverse/balanced最佳。Accuracy并列容差1e-12，顺序Similar→Balanced→Diverse→Random。",
                  "已准备独立score_label和adapter契约，但未生成meta-label、未训练TabPFN/TabICL/Mitra/TabDPT。",
                  "完整baseline验证仍是Phase 3之前的待办。Terminal命令、阶段门控、缓存和输出说明见根目录README。", ""])
    (output / "summary.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Phase 2 report written; {len(records)} predictions audited, {len(protected)} Phase 1 hashes unchanged.")
    return evidence


if __name__ == "__main__":
    write_phase2_report(load_phase2_config())
