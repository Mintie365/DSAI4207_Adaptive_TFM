"""Download pinned resources and resolve checkpoint paths for THIS checkout."""
from pathlib import Path
import os,sys,json,hashlib,urllib.request
ROOT=Path(__file__).resolve().parents[1]
os.environ['HF_HUB_OFFLINE']='0'
sys.path.insert(0,str(ROOT))
from huggingface_hub import snapshot_download,hf_hub_download
from src.utils import read_json,write_json

def main():
 cache=ROOT/'data/hub_cache';cache.mkdir(parents=True,exist_ok=True)
 for model,revision in [('Qwen/Qwen2.5-1.5B-Instruct','989aa7980e4cf806f80c7fef2b1adb7bc71aa306'),('sentence-transformers/all-MiniLM-L6-v2','1110a243fdf4706b3f48f1d95db1a4f5529b4d41')]:
  snapshot_download(model,revision=revision,cache_dir=cache,allow_patterns=['*.json','*.safetensors','*.txt','*.model'])
 cp=read_json(ROOT/'configs/tabpfn_checkpoint.json')
 cp['path']=hf_hub_download(cp['repository'],cp['filename'],revision=cp['revision'],cache_dir=cache)
 assert hashlib.sha256(Path(cp['path']).read_bytes()).hexdigest()==cp['sha256']
 write_json(ROOT/'results/phase3/tabpfn_checkpoint.json',cp)
 data=ROOT/'experiments/clinc150_8shot/data'
 commit='828f8093932c8fe6ca7936c3d2e52903b1c523de'
 for name in ['data_full.json','domains.json']:
  p=data/name
  if not p.exists():
   p.parent.mkdir(parents=True,exist_ok=True)
   urllib.request.urlretrieve(f'https://raw.githubusercontent.com/clinc/oos-eval/{commit}/data/{name}',p)
 manifest=read_json(data/'manifest.json')
 assert hashlib.sha256((data/'data_full.json').read_bytes()).hexdigest()==manifest['data_sha256']
 print('Pinned resources ready. Run bash experiments/clinc150_8shot/run_experiment.sh from this reproduction directory.')

if __name__=='__main__':main()
