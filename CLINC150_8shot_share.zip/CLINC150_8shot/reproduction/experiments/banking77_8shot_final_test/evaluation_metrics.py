"""Evaluation-only numeric helpers; invalid predictions retain all false negatives."""
import numpy as np

def confusion_counts(gold,pred,n_labels=77):
    y=np.asarray(gold,int);p=np.asarray(pred,int)
    if y.ndim!=1 or y.shape!=p.shape or not np.isin(y,np.arange(n_labels)).all() or not np.isin(p,np.arange(n_labels+1)).all():raise ValueError('Aligned intent codes and invalid sink required')
    extended=np.bincount(y*(n_labels+1)+p,minlength=n_labels*(n_labels+1)).reshape(n_labels,n_labels+1)
    valid=extended[:,:n_labels];invalid=extended[:,n_labels]
    assert extended.sum()==len(y) and valid.sum()+invalid.sum()==len(y)
    return valid,invalid,extended

def numeric_metrics(gold,pred,n_labels=77):
    valid,invalid,extended=confusion_counts(gold,pred,n_labels)
    tp=np.diag(valid).astype(float);true=extended.sum(1);predicted=valid.sum(0)
    f1=np.divide(2*tp,true+predicted,out=np.zeros(n_labels),where=(true+predicted)>0)
    return {'accuracy':float(tp.sum()/len(gold)),'correct_count':int(tp.sum()),'macro_f1':float(f1.mean()),
            'invalid_count':int(invalid.sum()),'invalid_rate':float(invalid.sum()/len(gold))}

def oracle_choices(correct):
    c=np.asarray(correct,bool)
    if c.ndim!=2 or c.shape[1]!=3:raise ValueError('Current S/D/B correctness required')
    choices=np.zeros(len(c),int)
    choices[~c[:,0]&c[:,1]]=1
    choices[~c[:,0]&c[:,2]]=2
    assert np.array_equal(c[np.arange(len(c)),choices],c.any(1))
    return choices

def switching_counts(reference,selected,changed):
    s=np.asarray(reference,bool);c=np.asarray(selected,bool);changed=np.asarray(changed,bool)
    if s.shape!=c.shape or s.shape!=changed.shape or s.ndim!=1:raise ValueError('Aligned query outcomes required')
    benefit=int((~s&c&changed).sum());harm=int((s&~c&changed).sum());neutral=int((changed&(s==c)).sum())
    assert np.array_equal(s[~changed],c[~changed])
    assert np.isclose(c.mean()-s.mean(),(benefit-harm)/len(s))
    return {'beneficial':benefit,'harmful':harm,'neutral_switches':neutral,'changed_queries':int(changed.sum()),
            'switch_rate':float(changed.mean()),'gain_vs_similar':float(c.mean()-s.mean())}

def paired_bootstrap(gold,predictions,replicates=5000,seed=42,n_labels=77):
    y=np.asarray(gold,int);p=np.asarray(predictions,int)
    if p.ndim!=2 or p.shape[0]!=len(y) or len(y)==0 or not np.isin(p,np.arange(n_labels+1)).all():raise ValueError('Aligned prediction matrix required')
    rng=np.random.default_rng(seed);n=len(y);correct=p==y[:,None];cf=correct.astype(float)
    accuracy=np.empty((replicates,p.shape[1]));f1=np.empty_like(accuracy)
    for start in range(0,replicates,250):
        draws=rng.integers(0,n,size=(min(250,replicates-start),n))
        for offset,draw in enumerate(draws):
            weights=np.bincount(draw,minlength=n).astype(float);row=start+offset
            accuracy[row]=weights@cf/n
            true=np.bincount(y,weights=weights,minlength=n_labels)
            for j in range(p.shape[1]):
                predicted=np.bincount(p[:,j],weights=weights,minlength=n_labels+1)[:n_labels]
                tp=np.bincount(y,weights=weights*correct[:,j],minlength=n_labels)
                denom=true+predicted
                f1[row,j]=np.divide(2*tp,denom,out=np.zeros(n_labels),where=denom>0).mean()
    return accuracy,f1
