#!/bin/bash
set -euo pipefail
CLINC_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$CLINC_DIR/../.." && pwd)"
cd "$PROJECT_DIR"
export PYTHONDONTWRITEBYTECODE=1
export MPLCONFIGDIR="$CLINC_DIR/cache/matplotlib"
export HF_HUB_OFFLINE=1
PYTHON="$PROJECT_DIR/.venv/bin/python"
mkdir -p "$CLINC_DIR/logs"
run_step() {
  local stage="$1"
  shift
  printf '%s Starting %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$stage"
  "$PYTHON" -u "$@" > "$CLINC_DIR/logs/$stage.log" 2>&1
  printf '%s Completed %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$stage"
}
run_step prepare "$CLINC_DIR/pipeline.py" prepare
run_step plans "$CLINC_DIR/pipeline.py" plans
run_step tests -m pytest -q "$CLINC_DIR/test_clinc150.py" --junitxml="$CLINC_DIR/results/tests.xml"
run_step score "$CLINC_DIR/pipeline.py" score
run_step train_lr "$CLINC_DIR/pipeline.py" train_lr
run_step train_tabpfn "$CLINC_DIR/pipeline.py" train_tabpfn
run_step validation "$CLINC_DIR/pipeline.py" validation
run_step validation_analysis "$CLINC_DIR/analysis.py" validation
run_step freeze "$CLINC_DIR/pipeline.py" freeze
run_step test "$CLINC_DIR/pipeline.py" test
run_step test_analysis "$CLINC_DIR/analysis.py" test
run_step finalize "$CLINC_DIR/analysis.py" finalize
