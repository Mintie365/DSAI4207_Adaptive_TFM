"""Dataset compatibility, teacher-forced alignment and evaluation boundary tests."""
import sys, math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import *
import pytest
from pipeline import ClincQwen
from src.meta_scoring import choose_target
from src.label_parsing import parse_intent

def demo():
 return [{'example_id':f'train_{i:06d}','text':'example','label':f'label_{i}','similarity':1-i*.01} for i in range(8)]

def test_150_label_prompt_preserves_labels_and_strict_parser():
 names=[f'label_{i}' for i in range(150)];prompt=build_prompt('query',demo(),names)
 assert len(prompt.demonstration_ids)==8 and all('- '+s+'\n' in prompt.messages[1]['content']+'\n' for s in names)
 assert parse_intent('"label_149"',names)['valid']
 assert not parse_intent('The answer is label_149',names)['valid']
 with pytest.raises(ValueError):build_prompt('query',demo(),names[:-1])

def test_exact_mean_token_score_excludes_prompt_and_eos():
 from tests.test_phase2_inference import mock_engine
 wrapper=ClincQwen.__new__(ClincQwen);wrapper.engine=mock_engine()
 names=[f'label_{i}' for i in range(150)];prompt=build_prompt('query',demo(),names)
 prefix,_=wrapper.engine.prepare(prompt);wrapper.engine.model.prompt_token_count=prefix['input_ids'].shape[1]
 score=wrapper.score(prompt,'label_149')
 assert score['mean_log_likelihood']==pytest.approx(-math.log(256),abs=1e-5)
 assert score['label_token_count']==9 and not score['includes_eos']

def test_original_likelihood_tie_order():
 assert choose_target([0,0,0])[0]==0
 assert choose_target([-1,0,0])[0]==2

def test_official_data_and_gold_free_queries():
 if not (DATA/'manifest.json').exists():pytest.skip('Run prepare first')
 raw=read_json(DATA/'data_full.json');names=labels()
 assert names==list(dict.fromkeys(y for _,y in raw['train'])) and len(names)==150
 sets=[]
 for s in CONFIG['sizes']:
  q=queries(s);assert len(q)==CONFIG['sizes'][s] and not {'label','label_name','gold'}&set(q)
  f=pd.read_csv(DATA/f'{s}.csv');assert f.label.nunique()==150
  sets.append(set(q.example_id))
 for i in range(4):
  for j in range(i):assert not sets[i]&sets[j]
 for source,split in [('val','validation'),('test','test')]:
  f=pd.read_csv(DATA/f'{split}.csv',keep_default_na=False)
  assert list(zip(f.text,f.label_name))==[tuple(x) for x in raw[source]]

def test_invalid_retains_gold_false_negatives_and_oracle_witness():
 from analysis import ev
 m=ev.numeric_metrics(np.array([0,1]),np.array([150,1]),150)
 assert m['accuracy']==.5 and m['macro_f1']==pytest.approx(1/150) and m['invalid_count']==1
 c=np.array([[False,True,True],[False,True,False],[True,True,True],[False,False,False]])
 assert ev.oracle_choices(c).tolist()==[2,1,0,0]

def test_shared_retrieval_never_accepts_validation_as_pool():
 from src.retrieval import SemanticRetriever
 f=pd.DataFrame({'example_id':['x'],'text':['x'],'label':[0],'label_name':['x'],'source_split':['validation'],'partition':['validation']})
 with pytest.raises(ValueError):SemanticRetriever(f,np.ones((1,4)))
