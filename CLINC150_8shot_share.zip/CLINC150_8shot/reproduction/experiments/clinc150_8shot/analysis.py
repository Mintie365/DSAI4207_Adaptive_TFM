"""Evaluation only, after strategy predictions are complete; no tuning."""
from common import *
import argparse, importlib.util
from itertools import combinations
from src.strategy_analysis import exact_mcnemar,holm_adjust
from src.label_parsing import parse_intent
spec=importlib.util.spec_from_file_location('banking_evaluation',ROOT/'experiments/banking77_8shot_final_test/evaluation_metrics.py')
ev=importlib.util.module_from_spec(spec);spec.loader.exec_module(ev)
METHODS=['always_similar','always_diverse','always_balanced','logistic_regression','tabpfn_v2','oracle_retrospective']

def analyze(split):
 from pipeline import verify_frozen
 protocol=verify_frozen() if split=='test' else None
 raw=jsonl(OUT/f'{split}_fixed_predictions.jsonl');q=queries(split);ids=q.example_id.tolist();names=labels();n=len(q)
 ix={(r['query_id'],r['strategy']):r for r in raw};assert len(ix)==len(raw)==n*3
 assert set(ix)=={(qid,s) for qid in ids for s in STRATEGIES}
 plans={r['query_id']:r for r in jsonl(CACHE/f'{split}_plans.jsonl')}
 for (qid,s),r in ix.items():
  assert not {'gold_label','gold','target_label'}&set(r)
  parsed=parse_intent(r['raw_output'],names);assert parsed['valid']==r['valid'] and parsed['predicted_label']==r['predicted_label']
  assert r['prompt_hash']==plans[qid]['prompt_hashes'][s] and len(set(r['demo_ids']))==8
  assert set(r['demo_ids'])<=set(plans[qid]['candidate_ids']) and r['actual_device']=='mps'
 choices={f'always_{s}':np.full(n,i,int) for i,s in enumerate(STRATEGIES)}
 for m in ('logistic_regression','tabpfn_v2'):
  f=pd.read_csv(OUT/f'{m}_{split}_choices.csv').set_index('query_id');assert set(f.index)==set(ids) and f.index.is_unique
  choices[m]=f.loc[ids].strategy_class.to_numpy(int);assert np.isin(choices[m],range(3)).all()
 # Seal deployable predictions and routing before opening evaluation gold.
 seal={'unix':time.time(),'n':n,'prediction_sha256':sha(OUT/f'{split}_fixed_predictions.jsonl'),'choices':{m:sha(OUT/f'{m}_{split}_choices.csv') for m in ('logistic_regression','tabpfn_v2')}}
 write_json(OUT/f'{split}_sealed_predictions.json',seal)
 gold=pd.read_csv(DATA/f'{split}.csv',keep_default_na=False);assert gold.example_id.tolist()==ids
 y=gold.label.to_numpy(int);label_index={s:i for i,s in enumerate(names)}
 fixed=np.array([[label_index[ix[qid,s]['predicted_label']] if ix[qid,s]['valid'] else 150 for s in STRATEGIES] for qid in ids])
 cf=fixed==y[:,None];oracle=cf.any(1);recoverable=int((~cf[:,0]&oracle).sum())
 choices['oracle_retrospective']=ev.oracle_choices(cf)
 preds=np.column_stack([fixed[np.arange(n),choices[m]] for m in METHODS]);correct=preds==y[:,None]
 assert np.array_equal(correct[:,-1],oracle) and np.all(correct<=oracle[:,None])
 ab,fb=ev.paired_bootstrap(y,preds,5000,42,150);np.savez(CACHE/f'{split}_bootstrap.npz',accuracy=ab,macro_f1=fb)
 best=protocol['best_fixed_selected_using_validation'] if protocol else max(CONFIG['fixed_validation_tie_order'],key=lambda s:cf[:,STRATEGIES.index(s)].mean())
 bj=STRATEGIES.index(best);rows=[];swrows=[];perclass=[];confusions=[];long=[]
 domains=read_json(DATA/'domains.json');domain_for={s:d for d,ss in domains.items() for s in ss}
 for j,m in enumerate(METHODS):
  met=ev.numeric_metrics(y,preds[:,j],150);sw=ev.switching_counts(cf[:,0],correct[:,j],choices[m]!=0)
  row={'split':split,'method':m,'n':n,**met,**sw,'validation_best_fixed':best,'gain_vs_validation_best_fixed':float(correct[:,j].mean()-correct[:,bj].mean()),'oracle_gap':float(oracle.mean()-correct[:,j].mean()),'recoverable_similar_errors':recoverable,'oracle_gain_realized_net':(met['correct_count']-int(cf[:,0].sum()))/recoverable if recoverable else 0}
  for metric,arr in [('accuracy',ab),('macro_f1',fb)]:
   lo,hi=np.quantile(arr[:,j],[.025,.975]);row[metric+'_ci_low']=float(lo);row[metric+'_ci_high']=float(hi)
  for ref,k in [(0,'gain_vs_similar'),(bj,'gain_vs_validation_best_fixed')]:
   lo,hi=np.quantile(ab[:,j]-ab[:,ref],[.025,.975]);row[k+'_ci_low']=float(lo);row[k+'_ci_high']=float(hi)
  row.update({'selected_'+s:int((choices[m]==i).sum()) for i,s in enumerate(STRATEGIES)})
  row['rescue_rate']=sw['beneficial']/recoverable if recoverable else 0
  rows.append(row);swrows.append({k:v for k,v in row.items() if k not in ('accuracy_ci_low','accuracy_ci_high','macro_f1_ci_low','macro_f1_ci_high')})
  valid,invalid,ext=ev.confusion_counts(y,preds[:,j],150)
  folder=OUT/'confusion_matrices';folder.mkdir(exist_ok=True)
  pd.DataFrame(ext,index=names,columns=names+['__INVALID__']).rename_axis('gold_intent').to_csv(folder/f'{split}_{m}.csv')
  for c,name in enumerate(names):
   mask=y==c;perclass.append({'split':split,'method':m,'intent':name,'domain':domain_for.get(name,'unknown'),'n':int(mask.sum()),'correct':int(correct[mask,j].sum()),'accuracy':float(correct[mask,j].mean()),'invalid_count':int(invalid[c])})
   for pc,count in enumerate(ext[c]):
    if pc!=c and count:confusions.append({'split':split,'method':m,'gold_intent':name,'predicted_intent':names[pc] if pc<150 else '__INVALID__','count':int(count)})
  for i,qid in enumerate(ids):
   a=choices[m][i];r=ix[qid,STRATEGIES[a]]
   long.append({'split':split,'method':m,'query_id':qid,'gold_intent':gold.label_name.iloc[i],'prediction':r['predicted_label'],'raw_output':r['raw_output'],'strategy':STRATEGIES[a],'correct':bool(correct[i,j]),'similar_correct':bool(cf[i,0]),'oracle_correct':bool(oracle[i])})
 pd.DataFrame(rows).to_csv(OUT/f'{split}_metrics.csv',index=False)
 pd.DataFrame(swrows).to_csv(OUT/f'{split}_strategy_analysis.csv',index=False)
 pd.DataFrame(perclass).to_csv(OUT/f'{split}_per_class_accuracy.csv',index=False)
 pd.DataFrame(confusions).sort_values(['method','count'],ascending=[True,False]).to_csv(OUT/f'{split}_error_patterns.csv',index=False)
 pd.DataFrame(long).to_csv(OUT/f'{split}_evaluated_predictions.csv',index=False)
 pairs=[];disagreement=[]
 # Preserve invalid raw responses as separate categories for disagreement.
 tags={m:np.array([ix[qid,STRATEGIES[a]]['predicted_label'] if ix[qid,STRATEGIES[a]]['valid'] else '__INVALID__:'+ix[qid,STRATEGIES[a]]['raw_output'].strip() for qid,a in zip(ids,choices[m])],object) for m in METHODS}
 for a,b in combinations(range(6),2):
  left,right=METHODS[a],METHODS[b];row={'split':split,'left':left,'right':right,'delta_accuracy_pp':float((correct[:,a].mean()-correct[:,b].mean())*100),**exact_mcnemar(correct[:,a],correct[:,b]),'analysis_only_oracle':b==5}
  for metric,arr in [('accuracy',ab),('macro_f1',fb)]:
   lo,hi=np.quantile(arr[:,a]-arr[:,b],[.025,.975]);row[metric+'_delta_ci_low']=float(lo);row[metric+'_delta_ci_high']=float(hi)
  pairs.append(row)
  disagreement.append({'split':split,'left':left,'right':right,'prediction_disagreement_count':int((tags[left]!=tags[right]).sum()),'prediction_disagreement_rate':float((tags[left]!=tags[right]).mean()),'correctness_disagreement_count':int((correct[:,a]!=correct[:,b]).sum())})
 deploy=[r for r in pairs if not r['analysis_only_oracle']]
 for r,v in zip(deploy,holm_adjust([r['mcnemar_exact_p'] for r in deploy])):r['holm_p']=float(v)
 pd.DataFrame(pairs).to_csv(OUT/f'{split}_paired_comparisons.csv',index=False)
 pd.DataFrame(disagreement).to_csv(OUT/f'{split}_pairwise_disagreement.csv',index=False)
 write_json(OUT/f'{split}_oracle_analysis.json',{'split':split,'n':n,'similar_correct':int(cf[:,0].sum()),'oracle_correct':int(oracle.sum()),'oracle_accuracy':float(oracle.mean()),'recoverable_errors':recoverable,'oracle_gain_pp':100*recoverable/n,'all_strategies_wrong':int((~oracle).sum()),'correctness_patterns':{format(k,'03b'):int(np.all(cf==[bool(k&4),bool(k&2),bool(k&1)],axis=1).sum()) for k in range(8)},'retrospective_not_deployable':True})
 print(pd.DataFrame(rows)[['method','accuracy','macro_f1','correct_count','beneficial','harmful','selected_similar','selected_diverse','selected_balanced']].to_string(index=False),flush=True)

def finalize():
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from pipeline import verify_frozen
 protocol=verify_frozen();v=pd.read_csv(OUT/'validation_metrics.csv');t=pd.read_csv(OUT/'test_metrics.csv')
 assert read_json(OUT/'test_sealed_predictions.json')['unix']>protocol['unix']
 for stem in ('strategy_analysis','paired_comparisons','pairwise_disagreement'):
  pd.concat([pd.read_csv(OUT/f'{s}_{stem}.csv') for s in ('validation','test')]).to_csv(OUT/f'{stem}.csv',index=False)
 write_json(OUT/'oracle_analysis.json',{s:read_json(OUT/f'{s}_oracle_analysis.json') for s in ('validation','test')})
 both=v.merge(t,on='method',suffixes=('_validation','_test'));both['test_minus_validation_pp']=100*(both.accuracy_test-both.accuracy_validation);both.to_csv(OUT/'validation_vs_test.csv',index=False)
 before=read_json(OUT/'protected_before.json');changed=[p for p,h in before.items() if not (ROOT/p).exists() or sha(ROOT/p)!=h]
 assert not changed,changed
 figures=OUT/'figures';figures.mkdir(exist_ok=True)
 for s,df in [('validation',v),('test',t)]:
  fig,ax=plt.subplots(figsize=(10,4.8));x=np.arange(6);a=df.accuracy.to_numpy()*100
  ax.bar(x,a,color=['#477da2']*3+['#4b9d87','#d7903b','#9ca8b4']);ax.errorbar(x,a,yerr=[a-df.accuracy_ci_low.to_numpy()*100,df.accuracy_ci_high.to_numpy()*100-a],fmt='none',ecolor='#233a50',capsize=3)
  ax.set_xticks(x,['Similar','Diverse','Balanced','LR','TabPFN-v2','Oracle*']);ax.set_ylabel('Accuracy (%)');ax.set_ylim(max(0,a.min()-8),100);ax.set_title(f'CLINC150 {s}: query bootstrap 95% CI');fig.tight_layout();fig.savefig(figures/f'{s}_accuracy.png',dpi=180);plt.close(fig)
  subset=df[df.method.isin(['logistic_regression','tabpfn_v2'])];fig,ax=plt.subplots(figsize=(7,4));bottom=np.zeros(2)
  for strategy,color in zip(STRATEGIES,['#477da2','#4b9d87','#d7903b']):
   counts=subset['selected_'+strategy].to_numpy();ax.bar(['LR','TabPFN-v2'],counts,bottom=bottom,label=strategy,color=color);bottom+=counts
  ax.legend();ax.set_title(f'CLINC150 {s}: strategy selection');ax.set_ylabel('Queries');fig.tight_layout();fig.savefig(figures/f'{s}_selector_distributions.png',dpi=180);plt.close(fig)
 fig,ax=plt.subplots(figsize=(9,4));x=np.arange(5)
 for offset,(s,df) in zip([-.18,.18],[('Validation',v),('Test',t)]):ax.bar(x+offset,df.oracle_gap.iloc[:5]*100,width=.36,label=s)
 ax.set_xticks(x,['Similar','Diverse','Balanced','LR','TabPFN-v2']);ax.set_ylabel('Oracle gap (pp)');ax.legend();fig.tight_layout();fig.savefig(figures/'oracle_gap.png',dpi=180);plt.close(fig)
 verification={'complete':True,'all_original_files_unchanged':True,'protected_file_count':len(before),'phase1_sizes':CONFIG['sizes'],'oos_excluded':True,'prediction_counts':{'validation':9000,'test':13500,'training_scores':15000},'four_features_only':True,'train_labels_only_for_meta_supervision':True,'selectors_retrained':True,'test_protocol_verified':True,'frozen_protocol_sha256':sha(OUT/'frozen_protocol.json'),'strict_parser':True,'no_prompt_truncation':True,'qwen_device':'mps','bootstrap_replicates':5000,'bootstrap_scope':'query sampling only; not training seed uncertainty','source_hashes':source_hashes()}
 write_json(OUT/'verification.json',verification)
 report(v,t,protocol)

def report(v,t,protocol):
 def table(df):
  lines=['| 方法 | Accuracy | Macro-F1 | 正确数 | Invalid | S / D / B |','|---|---:|---:|---:|---:|---|']
  for _,r in df.iterrows():lines.append(f'| {r.method} | {r.accuracy:.3%} | {r.macro_f1:.5f} | {r.correct_count}/{r.n} | {r.invalid_rate:.3%} | {r.selected_similar}/{r.selected_diverse}/{r.selected_balanced} |')
  return '\n'.join(lines)
 metrics=t.set_index('method');tab=metrics.loc['tabpfn_v2'];sim=metrics.loc['always_similar'];oracle=read_json(OUT/'oracle_analysis.json');diag=read_json(OUT/'meta_label_diagnostics.json');audit=read_json(OUT/'duplicate_audit.json')
 pairs=pd.read_csv(OUT/'test_paired_comparisons.csv');r=pairs[(pairs.left=='always_similar')&(pairs.right=='tabpfn_v2')].iloc[0]
 def comparison(a,b):
  idx=METHODS.index(a);jdx=METHODS.index(b);rr=pairs[(pairs.left==METHODS[min(idx,jdx)])&(pairs.right==METHODS[max(idx,jdx)])].iloc[0];sign=1 if idx<jdx else -1
  lo,hi=rr.accuracy_delta_ci_low*100,rr.accuracy_delta_ci_high*100
  if sign<0:lo,hi=-hi,-lo
  return f'{a} − {b}：Δ={(metrics.loc[a,"accuracy"]-metrics.loc[b,"accuracy"])*100:+.3f}pp，配对95% CI=[{lo:+.3f}, {hi:+.3f}]pp，双侧精确 McNemar p={rr.mcnemar_exact_p:.6g}，Holm p={rr.holm_p:.6g}。'
 lines=['# CLINC150 查询自适应示例选择实验报告','',
 f'本实验已完成官方 in-scope CLINC150 全量运行。TabPFN-v2 Test Accuracy={tab.accuracy:.3%}；相对 Similar 净变化 {int(tab.correct_count-sim.correct_count):+d} 条、{100*(tab.accuracy-sim.accuracy):+.3f}pp。Validation 预选的固定策略为 {protocol["best_fixed_selected_using_validation"]}。本报告只使用真实运行产物。','',
 '## 实验方法','',
 '官方 clinc/oos-eval/data/data_full.json，commit '+CONFIG['dataset_commit']+'；仅取 train/val/test 中150个 in-scope 标签，OOS单独分组全部排除。官方训练15000条，经seed42分层划分为10000 Demo与5000 Meta；官方Validation 3000、Test 4500保持原顺序与内容。标签文本原样保留；原文件没有整数类ID，按官方Train首次出现顺序保存可逆映射。',
 '冻结 Qwen2.5-1.5B-Instruct（989aa7980e4cf806f80c7fef2b1adb7bc71aa306），原生MPS FP16、greedy、max_new_tokens32；嵌入冻结all-MiniLM-L6-v2（1110a243fdf4706b3f48f1d95db1a4f5529b4d41），CPU、256 token编码上限，与原Banking77编码约定一致。推理提示上限4096，预检全量提示，无截断。',
 '仅Demo可作为检索候选。归一化cosine Top32，排除自身ID和规范化完全相同文本；Similar取最相关8条，Diverse从最相关候选开始greedy MaxMin，Balanced用MMR λ=.5；所有提示按query相似度降序、ID打破平局统一排列。提示结构沿用Banking77，仅将银行领域文字适配为150 intents的通用任务。',
 '四维特征为max_similarity、mean_similarity、entropy_bits、top_label_vote。元标签在5000 Meta查询上，比较三种提示下gold intent continuation的平均token log-likelihood，不含prompt、padding、EOS；容差1e-6，优先Similar→Balanced→Diverse。LR原StandardScaler与嵌套分层CV；TabPFN官方v2、4 estimators、seed42，复用固定checkpoint但重新训练CLINC上下文，不加载Banking77已训练选择器。',
 '先完成元评分、选择器训练、无gold的Validation/Test路由和Validation评估，随后封存模型/配置/路由/Validation最佳固定策略，最后运行Test预测并在预测封存后连接Test gold。跨split重复审计使用文本，不参与调参或预测。','',
 '## 数据完整性与元标签','',
 f'规范化跨分区完全重复对数={audit["exact_cross_split_count"]}；char_wb 3–5 gram TF-IDF cosine≥.90近重复对数={audit["near_cross_split_count"]}。完整配对见duplicate_audit.json。这些是潜在重叠风险，不等于全部是泄漏；保留官方分区、不删除测试样本。候选排除规范化完全相同文本，近重复保留并披露。',
 '元标签诊断：`'+json.dumps(diag,ensure_ascii=False)+'`。似然策略标签准确率不是下游分类准确率；内部holdout只用于诊断，不选择Test策略或阈值。内部holdout与嵌套OOF详情见models元数据及internal_holdout.csv。','',
 '## 官方 Validation 结果','',table(v),'',
 '## 官方 Test 结果','',table(t),'',
 'Oracle行是gold-assisted事后上界，不可部署。为完整计算其F1/invalid，见证规则为正确Similar优先，其次Balanced、Diverse，全部失败则Similar；这些附属指标属于该见证，不是Oracle上界的固有属性。Macro-F1固定150类，invalid记错误及对应gold类FN；不修复或模糊匹配模型输出。','',
 '## 策略切换与互补空间','',
 f'Test Similar错误={int(sim.n-sim.correct_count)}；可由D/B挽救={oracle["test"]["recoverable_errors"]}；Oracle余量={oracle["test"]["oracle_gain_pp"]:.3f}pp；三策略全部错误={oracle["test"]["all_strategies_wrong"]}。',
 ]
 for m in ('logistic_regression','tabpfn_v2'):
  x=metrics.loc[m];lines+=['',f'{m}：有益={int(x.beneficial)}、有害={int(x.harmful)}、中性切换={int(x.neutral_switches)}；切换率={x.switch_rate:.3%}；挽救率={x.rescue_rate:.3%}；净兑现Oracle余量={x.oracle_gain_realized_net:.3%}。Accuracy gain=(有益−有害)/N；中性包括同对或同错，切换率本身不代表收益。']
 lines+=['','## 配对统计','',comparison('tabpfn_v2','always_similar'),'',comparison('logistic_regression','always_similar'),'',comparison('tabpfn_v2','always_'+protocol['best_fixed_selected_using_validation']),'',
 '每个split用5000次seed42查询级配对bootstrap，所有方法共享重抽样索引；同时输出Accuracy和Macro-F1的单方法区间与配对差区间。双侧精确McNemar基于逐题对错不一致对。Holm比较家族事先固定为5个可部署方法之间10个无序比较；Oracle比较单列，仅解释上界。Test不能重新选择最佳固定策略；若Validation最优与Test最优不同，仍按封存的Validation选择作主要对照。查询bootstrap不覆盖训练划分随机性。','',
 '数值提升与显著提升分别判断：净正确数可为正，但应同时检查配对CI是否跨0、主要检验p及预声明Holm结果。Validation已经用于固定基线选择，其探索性结果不当作独立确认；Test结果不用于修改模型。','',
 '## 与 Banking77 原始 8-shot 的描述性对照','',
 '| 方法 | Banking77 Test | CLINC150 Test |','|---|---:|---:|']
 for (m,bank) in zip(METHODS,[.8883116883,.8792207792,.8896103896,.8873376623,.8883116883,.9175324675]):lines.append(f'| {m} | {bank:.3%} | {metrics.loc[m,"accuracy"]:.3%} |')
 best_test=t.iloc[:3].sort_values('accuracy',ascending=False).iloc[0]
 choices=[int(tab['selected_'+s]) for s in STRATEGIES];distinct=sum(x>0 for x in choices)
 lines+=['',f'CLINC150 Test数值最佳固定策略为 {best_test.method}（{best_test.accuracy:.3%}）；Similar为{sim.accuracy:.3%}。这个Test排名仅事后描述，实际对照仍由Validation冻结。TabPFN选择S/D/B={choices}，使用{distinct}种策略；需要将集中偏好、切换行为和有益净收益分别评价，不能仅由选择分布证明有效自适应。',
 f'Banking77原始TabPFN所有3080条均选Similar，增益0；Oracle余量2.922pp。CLINC150的对应余量为{oracle["test"]["oracle_gain_pp"]:.3f}pp，净兑现为{tab.oracle_gain_realized_net:.3%}。余量反映三种既定上下文的互补潜力，是否可预测取决于路由是否命中有益查询。',
 '策略互补可预测性的证据需合看：元标签holdout/OOF、正负切换、相对Validation最佳固定策略的净收益与配对区间。仅有更大的Oracle或更均衡的选择分布，不能证明四特征已学到可部署规律。若相对Similar领先但未超过Validation选定的固定策略，应把结论限制为基线替换收益；若没有提升，应如实保留负结果。',
 '两个数据集的样本量、标签数、领域、Demo/Meta分配均不同，本比较是描述性的。不能据此认定CLINC150更难、某种语义结构导致收益，或TFM必然优于固定ICL。','',
 '## 逐类表现与误差模式','',
 ]
 errors=pd.read_csv(OUT/'test_error_patterns.csv');per=pd.read_csv(OUT/'test_per_class_accuracy.csv')
 for m in ('always_similar','tabpfn_v2'):
  lines+=['',m+'主要混淆：']
  for _,e in errors[errors.method==m].head(10).iterrows():lines.append(f'- {e.gold_intent} → {e.predicted_intent}：{e["count"]}条。')
  lines+=['',m+'准确率最低的10类（每类30条，小样本波动需谨慎）：']
  for _,e in per[per.method==m].sort_values(['accuracy','intent']).head(10).iterrows():lines.append(f'- {e.intent}：{e.correct}/{e.n}，{e.accuracy:.1%}。')
 lines+=['','完整150类表、无效输出、150×151混淆矩阵、全部逐题预测及15组方法对的预测/正确性分歧已保存。不同无效raw输出在预测分歧统计中保持不同类别；在Accuracy中一律错误。','',
 '## 复现与限制','',
 '运行入口为 ../run_experiment.sh；原始配置见experiment_config.json；阶段日志位于../logs；输入/嵌入位于../data；共享提示缓存位于../cache；CLINC新训练上下文与模型位于../models。results/verification.json核验原Banking77及共享源代码未改、全量计数、冻结协议和来源hash。',
 '三策略如果生成完全相同的完整提示，复用同一冻结模型输出；不同提示仍分别真实推理。自适应答案逐ID查表复用固定预测，不重复调用Qwen。所有成功操作原子缓存并fsync保存日志；中断后同命令恢复。',
 '本轮只有seed42与一个LLM，结论不涵盖跨seed或跨模型稳定性；似然元标签可能与greedy正确性不一致；近重复可能使评估偏乐观；多数中性样本会掩盖稀少正负切换。后续应在新的独立协议下研究，不使用本Test反复调参。','',
 '数据来源：[CLINC150官方仓库](https://github.com/clinc/oos-eval/tree/'+CONFIG['dataset_commit']+')。Banking77对照来源：项目experiments/banking77_8shot_final_test/results/test_metrics.csv与summary.md。']
 (OUT/'summary.md').write_text('\n\n'.join(lines)+'\n',encoding='utf-8')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('step',choices=['validation','test','finalize']);a=p.parse_args()
 if a.step=='finalize':finalize()
 else:analyze(a.step)
