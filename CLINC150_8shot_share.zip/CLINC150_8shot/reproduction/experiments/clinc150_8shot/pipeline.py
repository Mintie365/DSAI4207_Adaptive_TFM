"""Real, resumable CLINC150 execution. Each command runs in a separate process."""
from common import *
import argparse, shutil, gc, inspect
from filelock import FileLock
from src.experiment_cache import PredictionCache,append_record

def prepare():
 from sklearn.model_selection import train_test_split
 from src.prepare_data import duplicate_audit,frame_fingerprint
 from src.embeddings import SentenceEncoder,save_or_load_embeddings
 from threadpoolctl import threadpool_limits
 if not (OUT/'protected_before.json').exists():write_json(OUT/'protected_before.json',protected_hashes())
 write_json(OUT/'experiment_config.json',CONFIG)
 for name in ('data_full.json','domains.json'):
  target=DATA/name
  if not target.exists():shutil.copyfile(Path('/private/tmp/clinc150_official/data')/name,target)
 raw=read_json(DATA/'data_full.json'); domains=read_json(DATA/'domains.json')
 # Official JSON has string labels, not canonical integer IDs. Preserve their first
 # occurrence order from official train rather than assigning an alphabetic remap.
 names=list(dict.fromkeys(label for text,label in raw['train']))
 assert len(names)==150 and 'oos' not in names
 mapping={x:i for i,x in enumerate(names)}
 write_json(DATA/'label_mapping.json',{'id_to_label':names,'label_to_id':mapping,'convention':'official train first occurrence; original label strings unchanged'})
 frames={}
 for key,source,n,perclass in [('train','train',15000,100),('validation','val',3000,20),('test','test',4500,30)]:
  pairs=raw[source];assert len(pairs)==n and all(y in names for _,y in pairs)
  f=pd.DataFrame([{'example_id':f'{key}_{i:06d}','text':t,'label':mapping[y],'label_name':y,'source_split':'train' if key=='train' else key} for i,(t,y) in enumerate(pairs)])
  assert f.label.value_counts().eq(perclass).all() and f.label.nunique()==150
  frames[key]=f
 demo,meta=train_test_split(frames.pop('train'),train_size=10000,stratify=[y for _,y in raw['train']],random_state=42)
 frames={'demonstration_pool':demo,'meta_training':meta,**frames}
 for name,f in frames.items():
  f=f.sort_values('example_id').reset_index(drop=True);f['partition']=name;frames[name]=f
  assert len(f)==CONFIG['sizes'][name] and f.label.nunique()==150
  f.to_csv(DATA/f'{name}.csv',index=False)
  f[['example_id','text','source_split','partition']].to_csv(DATA/f'{name}_queries.csv',index=False)
 if not (OUT/'duplicate_audit.json').exists():
  print('Auditing exact and lexical near duplicates across partitions',flush=True)
  write_json(OUT/'duplicate_audit.json',duplicate_audit(frames,.90,128))
 stats={name:{'n':len(f),'fingerprint':frame_fingerprint(f),'label_counts':f.label_name.value_counts().sort_index().to_dict(),'internal_normalized_duplicate_rows':int(f.text.map(normalized_text).duplicated().sum())} for name,f in frames.items()}
 manifest={'dataset_commit':CONFIG['dataset_commit'],'data_sha256':sha(DATA/'data_full.json'),'excluded_oos':{k:len(v) for k,v in raw.items() if k.startswith('oos')},'split_seed':42,'splits':stats,'software':versions()}
 manifest['fingerprint']=fingerprint(manifest);write_json(DATA/'manifest.json',manifest)
 cfg={'seed':42,'paths':{'embeddings':str(DATA/'embeddings'),'hub_cache':str(ROOT/'data/hub_cache')},'embedding':{'model':'sentence-transformers/all-MiniLM-L6-v2','revision':'1110a243fdf4706b3f48f1d95db1a4f5529b4d41','batch_size':64,'max_seq_length':256,'device':'cpu'}}
 encoder=SentenceEncoder(cfg,cfg['embedding']['revision']);keys={}
 for name,f in frames.items():
  _,key=save_or_load_embeddings(cfg,manifest,f,name,cfg['embedding']['revision'],encoder);keys[name]=key
 write_json(DATA/'embeddings/index.json',{'keys':keys,'manifest':manifest['fingerprint'],'config':cfg})
 print('Preparation complete', {k:len(v) for k,v in frames.items()},flush=True)

def plans():
 from src.retrieval import SemanticRetriever
 from src.selection import select_demonstrations
 from src.embeddings import load_cache
 from threadpoolctl import threadpool_limits
 ix=read_json(DATA/'embeddings/index.json');pool=pd.read_csv(DATA/'demonstration_pool.csv',keep_default_na=False)
 def array(split):
  key=ix['keys'][split];meta=read_json(DATA/'embeddings'/f'{split}-{key}.json');f=pd.read_csv(DATA/f'{split}.csv',keep_default_na=False)
  return load_cache(DATA/'embeddings',key,meta['identity'],f)
 retriever=SemanticRetriever(pool,array('demonstration_pool'),True);names=labels()
 from transformers import AutoTokenizer
 cfg=qwen_config();tok=AutoTokenizer.from_pretrained(cfg['model']['checkpoint'],revision=cfg['model']['tokenizer_revision'],cache_dir=str(ROOT/'data/hub_cache'),local_files_only=True)
 for split in ('meta_training','validation','test'):
  path=CACHE/f'{split}_plans.jsonl';q=queries(split);vec=array(split);existing={r['query_id']:r for r in jsonl(path)}
  with threadpool_limits(limits=1):
   for i,row in q.iterrows():
    if row.example_id in existing:continue
    candidates=retriever.retrieve(vec[i],32,query_id=row.example_id,query_text=row.text)
    demos={s:select_demonstrations(vec[i],candidates,s,8,42,mmr_lambda=.5)['demonstrations'] for s in STRATEGIES}
    hashes={};lengths={}
    for s,ds in demos.items():
     prompt=build_prompt(row.text,ds,names);hashes[s]=prompt.prompt_hash
     text=tok.apply_chat_template(prompt.messages,tokenize=False,add_generation_prompt=True)
     lengths[s]=len(tok(text,add_special_tokens=False,truncation=False)['input_ids'])
     if lengths[s]>4096:raise ValueError(f'Prompt overflow {split}/{row.example_id}/{s}: {lengths[s]}; no truncation')
    record={'query_id':row.example_id,'cache_key':row.example_id,'text':row.text,'features':feature_vector(candidates),'candidate_ids':[d.example_id for d in candidates],'demonstrations':demos,'prompt_hashes':hashes,'prompt_tokens':lengths}
    append_record(path,record)
    if (i+1)%250==0:print(f'Plans {split} {i+1}/{len(q)}',flush=True)
  rows=jsonl(path);assert len(rows)==len(q)
  pd.DataFrame([{'query_id':r['query_id'],**r['features']} for r in rows]).to_csv(OUT/f'{split}_features.csv',index=False)
 write_json(OUT/'plan_manifest.json',{s:{'sha256':sha(CACHE/f'{s}_plans.jsonl'),'n':len(queries(s))} for s in ('meta_training','validation','test')})

class ClincQwen:
 """Delegate frozen inference to original engine; adapt only the 77-label prompt."""
 def __init__(self):
  from src.llm_inference import QwenInference
  self.engine=QwenInference(qwen_config(),str(ROOT/'data/hub_cache'))
  assert self.engine.device=='mps' and self.engine.identity['all_parameters_frozen']
  self.identity={**self.engine.identity,'clinc_prompt_version':CONFIG['prompt_version']}
 def score(self,prompt,target):
  import torch
  from src.llm_inference import normalized_label_score
  e=self.engine;prefix,rendered=e.prepare(prompt)
  full=e.tokenizer(rendered+target,add_special_tokens=False,truncation=False,padding=False,return_tensors='pt')
  n=prefix['input_ids'].shape[1]
  if not torch.equal(full['input_ids'][:,:n],prefix['input_ids'].cpu()):raise ValueError('Ambiguous continuation token boundary')
  count=full['input_ids'].shape[1]-n
  assert count>0 and full['input_ids'].shape[1]<=e.model.config.max_position_embeddings
  batch={k:v.to(e.device) for k,v in full.items()}
  extra={'logits_to_keep':count+1} if 'logits_to_keep' in inspect.signature(e.model.forward).parameters else {}
  with torch.inference_mode():
   logits=e.model(**batch,**extra).logits[:,-(count+1):-1]
   summed,mean,counts=normalized_label_score(logits,batch['input_ids'][:,n:])
  return {'target_label':target,'label_token_count':int(counts.item()),'sum_log_likelihood':float(summed.item()),'mean_log_likelihood':float(mean.item()),'includes_eos':False,'prompt_hash':prompt.prompt_hash,'prompt_tokens':n}

def inference(mode,limit=None):
 if mode=='test':verify_frozen()
 e=ClincQwen();names=labels();split='meta_training' if mode=='score' else mode
 manifest=read_json(OUT/'plan_manifest.json');assert sha(CACHE/f'{split}_plans.jsonl')==manifest[split]['sha256']
 plans=jsonl(CACHE/f'{split}_plans.jsonl');path=OUT/('meta_label_scores.jsonl' if mode=='score' else f'{split}_fixed_predictions.jsonl')
 existing=jsonl(path);done={r['cache_key'] for r in existing}
 cache=PredictionCache(CACHE/('scores' if mode=='score' else 'predictions'))
 prompt_cache=PredictionCache(CACHE/'shared_prompt_outputs')
 gold=pd.read_csv(DATA/'meta_training.csv',keep_default_na=False).set_index('example_id').label_name.to_dict() if mode=='score' else None
 write_json(OUT/f'{mode}_inference_identity.json',e.identity)
 start=time.perf_counter();new=0
 with FileLock(str(HERE/'.qwen.lock'),timeout=0):
  for i,plan in enumerate(plans):
   if limit and i>=limit:break
   for s in STRATEGIES:
    prompt=build_prompt(plan['text'],plan['demonstrations'][s],names)
    assert prompt.prompt_hash==plan['prompt_hashes'][s]
    ident={'query_id':plan['query_id'],'strategy':s,'prompt_hash':prompt.prompt_hash,'inference':e.identity,'manifest':read_json(DATA/'manifest.json')['fingerprint'],'operation':mode}
    # Gold enters only training-score identity, encoded as a target hash rather
    # than passed into a prediction interface. Evaluation caches contain no gold.
    if mode=='score':ident['training_target_hash']=fingerprint(gold[plan['query_id']])
    key=fingerprint(ident)
    if key in done:
     assert cache.get(ident) is not None
     continue
    result=cache.get(ident)
    if result is None:
     shared={'prompt_hash':prompt.prompt_hash,'inference':e.identity,'operation':'score' if mode=='score' else 'greedy'}
     if mode=='score':shared['training_target_hash']=fingerprint(gold[plan['query_id']])
     result=prompt_cache.get(shared);reused=result is not None
     if result is None:
      e.engine._synchronize();t=time.perf_counter()
      result=e.score(prompt,gold[plan['query_id']]) if mode=='score' else e.engine.predict_prepared(prompt,names)
      e.engine._synchronize();result['runtime_seconds']=time.perf_counter()-t
      prompt_cache.put(shared,result);new+=1
     result=dict(result);result.update(query_id=plan['query_id'],strategy=s,cache_key=key,demo_ids=prompt.demonstration_ids,actual_device='mps',identical_prompt_reused=reused)
     assert cache.put(ident,result)==key
     if not existing and len(done)==0:
      repeated=e.score(prompt,gold[plan['query_id']]) if mode=='score' else e.engine.predict_prepared(prompt,names)
      assert abs(repeated['mean_log_likelihood']-result['mean_log_likelihood'])<1e-5 if mode=='score' else repeated['raw_output']==result['raw_output']
      write_json(OUT/f'{mode}_smoke.json',{'passed':True,'repeat_consistent':True,'first_prompt_tokens':result['prompt_tokens'],'device':'mps','repeated':repeated})
    append_record(path,result);done.add(key)
   if (i+1)%20==0:
    write_json(OUT/'progress.json',{'mode':mode,'completed_operations':len(done),'total_operations':len(plans)*3,'new_operations_this_session':new,'elapsed_seconds':time.perf_counter()-start,'updated_unix':time.time()})
    print(f'{mode}: {i+1}/{len(plans)} queries; {len(done)}/{len(plans)*3} operations; elapsed {time.perf_counter()-start:.1f}s',flush=True)
 write_json(OUT/f'{mode}_session.json',{'complete':len(done)==len(plans)*3,'operations':len(done),'new_operations':new,'elapsed_seconds':time.perf_counter()-start,'memory':e.engine.memory_metadata(),'device':'mps'})
 if mode=='score' and len(done)==15000:build_meta()

def build_meta():
 from src.meta_scoring import choose_target
 rows=jsonl(OUT/'meta_label_scores.jsonl');assert len(rows)==15000
 ix={(r['query_id'],r['strategy']):r for r in rows};assert len(ix)==15000
 f=pd.read_csv(OUT/'meta_training_features.csv');data=[]
 for _,r in f.iterrows():
  group=[ix[r.query_id,s] for s in STRATEGIES];scores=[x['mean_log_likelihood'] for x in group]
  target,margin,ties=choose_target(scores,1e-6)
  data.append({**r.to_dict(),'target_class':target,'target_strategy':STRATEGIES[target],'score_margin':margin,'tied_strategies':ties,**{s+'_log_likelihood':v for s,v in zip(STRATEGIES,scores)}})
 df=pd.DataFrame(data);df.to_csv(OUT/'meta_training_dataset.csv',index=False)
 write_json(OUT/'meta_label_diagnostics.json',{'n':5000,'distribution':df.target_strategy.value_counts().to_dict(),'mean_margin':float(df.score_margin.mean()),'median_margin':float(df.score_margin.median()),'effectively_tied_queries':int((df.tied_strategies>1).sum()),'small_margin_counts':{str(t):int((df.score_margin<=t).sum()) for t in (1e-6,1e-4,1e-3,.01,.1)},'majority_meta_label_accuracy':float(df.target_class.value_counts().max()/5000),'tie_order':['similar','balanced','diverse']})

def train(method):
 from src.meta_selectors import LogisticSelector,TabPFNV2Selector,ConstantSelector
 from sklearn.model_selection import train_test_split
 from sklearn.metrics import accuracy_score,f1_score
 import joblib, torch
 meta_path=MODELS/f'{method}_metadata.json'
 if meta_path.exists():
  stored=read_json(meta_path)
  assert stored['training_dataset_sha256']==sha(OUT/'meta_training_dataset.csv')
  for path,digest in stored['saved_artifact_hashes'].items():assert sha(HERE/path)==digest
  print('Reusing completed CLINC selector and sealed choices',method,flush=True);return
 assert torch.backends.mps.is_available(),'MPS required'
 cfg=read_json(ROOT/'results/phase3/experiment_config.json')['phase3']
 checkpoint=read_json(ROOT/'results/phase3/tabpfn_checkpoint.json');assert sha(checkpoint['path'])==checkpoint['sha256']
 frame=pd.read_csv(OUT/'meta_training_dataset.csv');assert len(frame)==5000
 X=frame[FEATURES].to_numpy();y=frame.target_class.to_numpy(int)
 start=time.perf_counter();metadata={}
 factory=lambda: LogisticSelector(cfg) if method=='logistic_regression' else TabPFNV2Selector(cfg,checkpoint,'mps')
 a,b=train_test_split(np.arange(5000),test_size=.2,stratify=y,random_state=42)
 check=factory().fit(X[a],y[a]);pred=check.predict(X[b])
 metadata.update(internal_holdout_accuracy=float(accuracy_score(y[b],pred)),internal_holdout_macro_f1=float(f1_score(y[b],pred,labels=[0,1,2],average='macro',zero_division=0)),holdout_size=len(b))
 pd.DataFrame({'query_id':frame.query_id.iloc[b],'target_class':y[b],'predicted_class':pred}).to_csv(OUT/f'{method}_internal_holdout.csv',index=False)
 del check;gc.collect();torch.mps.empty_cache()
 model=factory().fit(X,y);metadata.update(getattr(model,'diagnostics',{}));metadata['fit_seconds']=time.perf_counter()-start
 if method=='logistic_regression':joblib.dump(model,MODELS/f'{method}.joblib')
 else:
  np.savez(MODELS/'tabpfn_v2_fit_context.npz',X=X,y=y)
  model.model.save_fit_state(MODELS/'tabpfn_v2.tabpfn_fit')
  metadata.update(actual_devices=[str(d) for d in model.model.devices_],checkpoint=checkpoint)
  assert all(d.startswith('mps') for d in metadata['actual_devices'])
 # All Validation AND Test routing decisions are made from features alone.
 for split in ('validation','test'):
  f=pd.read_csv(OUT/f'{split}_features.csv');V=f[FEATURES].to_numpy();pred=model.predict(V);proba=model.predict_proba(V)
  result=f[['query_id']].copy();result['strategy_class']=pred;result['strategy']=[STRATEGIES[i] for i in pred]
  for j,c in enumerate(model.model.classes_):result[f'probability_class_{int(c)}']=proba[:,j]
  result.to_csv(OUT/f'{method}_{split}_choices.csv',index=False)
  if split=='validation':
   if method=='logistic_regression':restored=joblib.load(MODELS/f'{method}.joblib')
   else:
    from tabpfn import TabPFNClassifier
    restored=TabPFNClassifier.load_from_fit_state(MODELS/'tabpfn_v2.tabpfn_fit',device='mps')
   replay=restored.predict(V[:16]);assert np.array_equal(replay,pred[:16])
   del restored;gc.collect();torch.mps.empty_cache()
 metadata.update(n_training=5000,features=FEATURES,software=versions(),class_counts={str(k):int(v) for k,v in frame.target_class.value_counts().items()},retrained_on_clinc150=True,validation_used_for_tuning=False,test_gold_used=False)
 artifacts=[OUT/f'{method}_{s}_choices.csv' for s in ('validation','test')]
 artifacts+=[MODELS/f'{method}.joblib'] if method=='logistic_regression' else [MODELS/'tabpfn_v2_fit_context.npz',MODELS/'tabpfn_v2.tabpfn_fit']
 metadata.update(training_dataset_sha256=sha(OUT/'meta_training_dataset.csv'),reload_predictions_verified=True,saved_artifact_hashes={str(p.relative_to(HERE)):sha(p) for p in artifacts})
 write_json(meta_path,metadata)
 print('Trained',method,metadata,flush=True)

def freeze():
 val=pd.read_csv(OUT/'validation_metrics.csv').set_index('method')
 best=max(CONFIG['fixed_validation_tie_order'],key=lambda s:val.loc['always_'+s,'accuracy'])
 files=[OUT/'meta_training_dataset.csv',OUT/'validation_metrics.csv',OUT/'experiment_config.json',DATA/'manifest.json',OUT/'plan_manifest.json']
 files+=list(MODELS.glob('*'))
 files+=[OUT/f'{m}_{s}_choices.csv' for m in ('logistic_regression','tabpfn_v2') for s in ('validation','test')]
 obj={'unix':time.time(),'best_fixed_selected_using_validation':best,'config':CONFIG,'source_hashes':source_hashes(),'files':{str(p.relative_to(HERE)):sha(p) for p in files}}
 path=OUT/'frozen_protocol.json'
 if path.exists():verify_frozen()
 else:write_json(path,obj)
 print('Frozen before Test evaluation; validation-selected fixed=',best,flush=True)

def verify_frozen():
 obj=read_json(OUT/'frozen_protocol.json');assert obj['config']==CONFIG and obj['source_hashes']==source_hashes()
 for p,h in obj['files'].items():assert sha(HERE/p)==h,p
 return obj

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('step',choices=['prepare','plans','score','validation','test','train_lr','train_tabpfn','freeze']);p.add_argument('--limit',type=int);a=p.parse_args()
 if a.step in ('prepare','plans','freeze'):globals()[a.step]()
 elif a.step.startswith('train'):train('logistic_regression' if a.step=='train_lr' else 'tabpfn_v2')
 else:inference(a.step,a.limit)
