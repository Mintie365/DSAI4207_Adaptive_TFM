"""Recheck completed artifacts and polish the report without changing frozen methods.

Run AFTER analysis.py finalize. This script does not train or invoke an LLM.
"""
from pathlib import Path
import sys, json, time, re, importlib.metadata
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
from common import OUT,CACHE,ROOT,MODELS,FEATURES,STRATEGIES,read_json,write_json,sha,jsonl,fingerprint
from pipeline import verify_frozen
import numpy as np,pandas as pd
from sklearn.metrics import accuracy_score,f1_score

protocol=verify_frozen()
cache_checks={}
for filename,folder in [('meta_label_scores.jsonl','scores'),('validation_fixed_predictions.jsonl','predictions'),('test_fixed_predictions.jsonl','predictions')]:
 rows=jsonl(OUT/filename)
 for r in rows:
  c=read_json(CACHE/folder/f"{r['cache_key']}.json")
  assert c['prediction']==r and c['prediction_sha256']==fingerprint(r) and fingerprint(c['identity'])==r['cache_key']
 cache_checks[filename]=len(rows)
assert cache_checks=={'meta_label_scores.jsonl':15000,'validation_fixed_predictions.jsonl':9000,'test_fixed_predictions.jsonl':13500}

v=pd.read_csv(OUT/'validation_metrics.csv').set_index('method')
t=pd.read_csv(OUT/'test_metrics.csv').set_index('method')
names=read_json(HERE/'data/label_mapping.json')['id_to_label']
measured=[];routing=[];examples=[]
for split,metrics in [('validation',v),('test',t)]:
 long=pd.read_csv(OUT/f'{split}_evaluated_predictions.csv',keep_default_na=False)
 gold=pd.read_csv(HERE/f'data/{split}.csv',keep_default_na=False).set_index('example_id')
 ix={m:f.set_index('query_id').loc[gold.index] for m,f in long.groupby('method')}
 for m,f in ix.items():
  y=gold.label_name.to_numpy();pred=f.prediction.replace('','__INVALID__').to_numpy()
  acc=accuracy_score(y,pred);f1=f1_score(y,pred,labels=names,average='macro',zero_division=0)
  assert np.isclose(acc,metrics.loc[m,'accuracy'],atol=1e-14)
  assert np.isclose(f1,metrics.loc[m,'macro_f1'],atol=1e-14)
  measured.append({'split':split,'method':m,'sklearn_accuracy':float(acc),'sklearn_macro_f1':float(f1),'matches_saved_metrics':True})
 fixed_acc=np.array([metrics.loc['always_'+s,'accuracy'] for s in STRATEGIES])
 for m in ['logistic_regression','tabpfn_v2']:
  counts=np.array([metrics.loc[m,'selected_'+s] for s in STRATEGIES]);expected=float(counts@fixed_acc/counts.sum())
  routing.append({'split':split,'method':m,'actual_accuracy':metrics.loc[m,'accuracy'],'same_proportion_random_routing_expected_accuracy':expected,'actual_minus_random_expectation_pp':100*(metrics.loc[m,'accuracy']-expected),'posthoc_descriptive_only':True})
 if split=='test':
  s=ix['always_similar'];b=ix['always_balanced'];tab=ix['tabpfn_v2']
  base_hit=s.prediction.eq(gold.label_name);hit=tab.prediction.eq(gold.label_name)
  for outcome,mask in [('beneficial',~base_hit&hit),('harmful',base_hit&~hit)]:
   for qid in sorted(gold.index[mask])[:5]:
    examples.append({'query_id':qid,'outcome_vs_similar':outcome,'query':gold.loc[qid,'text'],'gold_intent':gold.loc[qid,'label_name'],'similar_prediction':s.loc[qid,'prediction'],'balanced_prediction':b.loc[qid,'prediction'],'tabpfn_strategy':tab.loc[qid,'strategy']})
pd.DataFrame(measured).to_csv(OUT/'independent_metric_checks.csv',index=False)
pd.DataFrame(routing).to_csv(OUT/'routing_expectation_diagnostics.csv',index=False)
pd.DataFrame(examples).to_csv(OUT/'tabpfn_switch_examples.csv',index=False)

weights={}
for model,revision in [('Qwen--Qwen2.5-1.5B-Instruct','989aa7980e4cf806f80c7fef2b1adb7bc71aa306'),('sentence-transformers--all-MiniLM-L6-v2','1110a243fdf4706b3f48f1d95db1a4f5529b4d41')]:
 folder=ROOT/'data/hub_cache'/('models--'+model)/'snapshots'/revision
 for p in folder.rglob('*.safetensors'):
  digest=sha(p);blob=p.resolve().name
  assert digest==blob,(p,blob)
  weights[str(p.relative_to(ROOT))]={'sha256':digest,'matches_hub_blob_sha256':True}
assert len(weights)>=2
before=read_json(OUT/'protected_before.json')
assert all((ROOT/p).is_file() and sha(ROOT/p)==h for p,h in before.items())
software={p:importlib.metadata.version(p) for p in ['numpy','pandas','scikit-learn','torch','transformers','sentence-transformers','tabpfn']}
write_json(OUT/'execution_environment.json',{'software':software,'checkpoint_weight_integrity':weights,'all_cached_records_verified':cache_checks,'original_files_unchanged':True})

path=OUT/'summary.md';text=path.read_text()
text=re.sub(r'\n{3,}','\n\n',text)
text=re.sub(r'(?m)^(\|[^\n]*\|)\n\n(?=\|)',r'\1\n',text)
text=text.replace('[-0.000, +0.556]','[0.000, +0.556]')
opening='本实验已完成官方 in-scope CLINC150 全量运行。TabPFN-v2 Test Accuracy=91.333%；相对 Similar 净变化 +12 条、+0.267pp。Validation 预选的固定策略为 balanced。本报告只使用真实运行产物。'
text=text.replace(opening,'CLINC150 全量实验已完成。TabPFN-v2 在 Test 上为 **91.333%（4110/4500）**，相对 Similar 净增12条、+0.267个百分点；双侧精确 McNemar p=0.08069，Holm p=0.72621，未达到统计显著。Validation 预先选定的固定 Balanced 为 **91.533%（4119/4500）**，比 TabPFN 多对9条。因此，本轮观察到策略切换与小幅数值收益，但没有确认自适应选择优于固定策略的可靠优势。')
raw='元标签诊断：`'+json.dumps(read_json(OUT/'meta_label_diagnostics.json'),ensure_ascii=False)+'`。似然策略标签准确率不是下游分类准确率；内部holdout只用于诊断，不选择Test策略或阈值。内部holdout与嵌套OOF详情见models元数据及internal_holdout.csv。'
clean='''元标签分布为 Similar 1950条（39.00%）、Diverse 1246条（24.92%）、Balanced 1804条（36.08%）。top-two 似然差均值为0.036386，中位数仅0.00009535；3844/5000条（76.88%）margin≤0.001，134条在1e-6容差内并列。均值不能代表大多数查询的标签分离程度。

| 训练诊断 | LR | TabPFN-v2 |
|---|---:|---:|
| 同一1000条内部holdout元标签准确率 | 34.90% | 39.20% |
| 内部holdout元标签Macro-F1 | 0.34253 | 0.29166 |
| 嵌套OOF元标签准确率 | 37.48% | 未运行 |
| 嵌套OOF元标签Macro-F1 | 0.36803 | 未运行 |

内部holdout多数元标签基线为39.00%，TabPFN的39.20%仅高0.20个百分点；这提示似然argmax标签的可预测信号有限。这里不能断言模型完全没有学到信息，也不能把内部元标签准确率当作下游意图准确率。LR的最优参数是C=10、class_weight=balanced，全部由Meta-training内部CV选择。两模型均重新在完整5000条Meta上拟合；没有使用Validation或Test调参。'''
if raw in text:text=text.replace(raw,clean)
if '### 分区规模与跨分区重叠' not in text:
 from collections import Counter
 lines=['### 分区规模与跨分区重叠','','| 分区 | 样本数 | 意图数 | 每个意图的样本数 |','|---|---:|---:|---|']
 for split in ['demonstration_pool','meta_training','validation','test']:
  f=pd.read_csv(HERE/f'data/{split}.csv');counts=f.label_name.value_counts()
  lines.append(f'| {split} | {len(f)} | {len(counts)} | {int(counts.min())} 至 {int(counts.max())} |')
 audit=read_json(OUT/'duplicate_audit.json')
 paircounts={}
 for key in ['exact_pairs','near_pairs']:
  counts=Counter()
  for pair in audit[key]:
   ss=[('train' if pair[side]['split'] in ['demonstration_pool','meta_training'] else pair[side]['split']) for side in ['left','right']]
   counts[' / '.join(sorted(ss))]+=1
  paircounts[key]=dict(counts)
 lines+=['','| 记录对所属分区 | 规范化完全重复对数 | 词面近重复对数 |','|---|---:|---:|']
 for key in sorted(set(paircounts['exact_pairs'])|set(paircounts['near_pairs'])):
  lines.append(f"| {key} | {paircounts['exact_pairs'].get(key,0)} | {paircounts['near_pairs'].get(key,0)} |")
 lines+=['','表中train / train指Demo与Meta之间，不含单个分区内的重复。计数单位是记录对，不是唯一查询数。Train与Test之间有20对规范化完全重复，Train与Validation有16对，Validation与Test有5对；这些官方分区重叠会限制评估独立性。检索候选的完全匹配排除降低了直接复用同文本Demo的风险，但不能消除元训练重叠、近重复或预训练数据的影响。本轮按任务保留官方数据，不以审计结果重新筛选Test。']
 write_json(OUT/'duplicate_overlap_summary.json',paircounts)
 text=text.replace('## 官方 Validation 结果','\n'.join(lines)+'\n\n## 官方 Validation 结果')
conditional='策略互补可预测性的证据需合看：元标签holdout/OOF、正负切换、相对Validation最佳固定策略的净收益与配对区间。仅有更大的Oracle或更均衡的选择分布，不能证明四特征已学到可部署规律。若相对Similar领先但未超过Validation选定的固定策略，应把结论限制为基线替换收益；若没有提升，应如实保留负结果。'
text=text.replace(conditional,'CLINC150 的 TabPFN 已摆脱原始 Banking77 的全Similar输出，但其Test收益只占可挽救错误余量的8.70%，且低于固定Balanced。这支持“数据集改变会影响选择器行为”的描述性结论，尚不支持“互补性已被更可靠地预测”或“TFM优于固定ICL”。')
note='''本轮 Accuracy 增益的bootstrap区间下端恰为0，属于离散小样本事件下的边界结果，不能按舍入后的正值解释为显著。Accuracy 的精确 McNemar p=0.08069，没有拒绝零假设。TabPFN−Similar 的 Macro-F1 差为+0.00284，未校正bootstrap 95%区间约为[+0.00019,+0.00580]；这是次要指标的探索性结果，不能替代主要Accuracy检验，也没有进行Macro-F1家族校正。所有可部署方法两两比较的Test Holm p均大于0.05。

Balanced−Similar 的Test差为+0.467pp、精确p=0.14124；Balanced是本轮合理的部署候选和预选基线，但不能把其数值最高写成已证实统计优胜。'''
if note not in text:text=text.replace('## 与 Banking77 原始 8-shot 的描述性对照',note+'\n\n## 与 Banking77 原始 8-shot 的描述性对照')

extra='''## 对研究问题的直接回答

1. **Similar是否仍然强。** 是，Test达到91.067%；Diverse为91.044%，几乎持平。增加意图类别数并未使Similar基线失效。
2. **哪种固定策略最好。** Balanced在Validation和Test均数值最高，分别为92.467%和91.533%；本轮在Test之前已根据Validation冻结了Balanced，未用Test挑选基线。
3. **TabPFN是否自适应。** 它在Test上选择2789次Similar（61.98%）和1711次Balanced（38.02%），未选择Diverse。行为上存在逐查询切换；准确率上未证实优于固定Balanced。
4. **Oracle空间是否变大。** CLINC150的Oracle−Similar为3.067pp，Banking77原始Test为2.922pp，只大约0.145pp，不能称为互补空间大幅扩张。CLINC150仍有264条三策略全错，单纯路由无法挽救。
5. **策略互补是否更可预测。** TabPFN取得26次有益与14次有害切换，说明存在正向数值信号；但主要检验不显著，内部元标签准确率仅接近多数类基线，相对Balanced又少对9条。证据不足以认定可预测性有可靠提升。
6. **何时使用固定或自适应策略。** 在本轮设置下，应优先采用Validation选定的固定Balanced作为后续验证/部署候选。要主张自适应值得增加复杂度，仍需在新数据或多seed独立协议中确认它超过预选固定策略，并持续满足有益切换大于有害切换；本轮不据Test继续调参。

## 为什么切换增加了 收益却仍然有限

**大多数样本对策略变化不敏感。** Test中3964条三策略全对，264条三策略全错，两者合计4228/4500（93.96%）；只有272条（6.04%）的对错状态会随策略变化。TabPFN虽然切换了1711条，却仅改变48条的完整预测类别、40条的对错状态；1671次切换为中性，占切换的97.66%。这解释了38.02%的策略切换率为何只转化为0.267pp的净收益。

**似然监督与greedy准确率没有完全对齐。** 76.88%的训练查询三策略top-two似然差≤0.001；即使三者都给出正确标签，似然微差仍会产生某个唯一meta-label。训练目标会为这些对准确率没有贡献的变化分配监督，而真正决定净收益的是稀少的错转对与对转错事件。这是与观测相容的机制解释，不是对噪声来源的因果证明。

**四个特征遗漏了具体意图边界。** 它们只概括邻域相关性与标签分布，没有直接保留“查看还是更新列表”“AI名字还是用户名字”“何时换油还是如何换油”等语义差别。本轮错误集中在这些细粒度边界：TabPFN仍有26条todo_list→todo_list_update、21条change_ai_name→change_user_name；oil_change_when正确数由Similar的13/30提高到18/30，但insurance由17/30降到16/30，damaged_card由16/30降到15/30。类别变化仅为每类30条的描述性分析，不作逐类显著性宣称。

**Baseline的选择会改变结论。** 相对Similar，TabPFN净增12条；相对预选Balanced，则有68条独有正确、77条独有错误，净少9条。固定Balanced相对Similar本身已净增21条。不能只以Similar为对照，就把模型学到的策略偏好解释为额外的自适应价值。

## 相同策略比例的事后描述性诊断

下表假设把现有S/D/B选择次数保持不变，再将策略独立随机分配给查询。其期望准确率可直接由“各策略选择占比×对应固定策略准确率”的总和计算。这里没有重新训练、调用LLM或按Test选择配置；这是事后描述性诊断，不属于预声明主要检验，也不是显著性证明。

| Split | 选择器 | 实际Accuracy | 同比例随机分配的期望Accuracy | 实际高于期望的差值 |
|---|---|---:|---:|---:|
'''
for r in routing:extra+=f"| {r['split']} | {r['method']} | {r['actual_accuracy']:.3%} | {r['same_proportion_random_routing_expected_accuracy']:.3%} | {r['actual_minus_random_expectation_pp']:+.3f}pp |\n"
extra+='''
TabPFN在Validation低于同策略比例随机分配的期望，在Test仅略高于该期望。这进一步限制了“查询特征已经提供稳定路由优势”的解释；仅凭策略占比与正净收益，无法确认匹配query本身的独立贡献。

## 图表与可追溯产物

![官方Test准确率与查询bootstrap置信区间](figures/test_accuracy.png)

![Test选择器的策略分布](figures/test_selector_distributions.png)

![Validation和Test的Oracle余量](figures/oracle_gap.png)

所有要求的CSV、配置、Oracle分析、验证文件均在本目录。`independent_metric_checks.csv`用sklearn独立重算两split全部六方法的Accuracy/Macro-F1，逐项与保存指标一致；`execution_environment.json`记录依赖版本、模型权重blob校验及全部37500条逻辑记录的缓存核验。`tabpfn_switch_examples.csv`保存按query_id排序的前5个有益和前5个有害切换案例，避免只挑成功案例。

本次运行经历两次用户要求的暂停，均在校验断点后恢复；完整推理缓存与模型没有丢失。Qwen和MiniLM权重SHA256与固定Hub blob一致；原项目682个受保护文件未变。原项目162项测试及CLINC150新增6项测试通过，两模型的保存/重载预测核验通过。TabPFN包版本为'''+software['tabpfn']+'。本轮仅完成当前冻结配置，不将负结果隐去，也不把Test数值差异当成后续调参依据。\n'
if '## 对研究问题的直接回答' not in text:
 text=text.replace('## 复现与限制',extra+'\n## 复现与限制')
for name in ['test_accuracy.png','test_selector_distributions.png','oracle_gap.png']:
 text=text.replace('(figures/'+name+')','('+str(OUT/'figures'/name)+')')
text+='\n报告排版及独立核验复现：完成原入口脚本后，运行 `.venv/bin/python experiments/clinc150_8shot/results/finish_report.py`。该脚本只核验已有产物并整理报告，不改变冻结的模型或统计方案。\n' if '报告排版及独立核验复现' not in text else ''
path.write_text(text,encoding='utf-8')
verification=read_json(OUT/'verification.json')
verification.update(all_37500_records_cache_verified=True,independent_sklearn_metrics_match=True,hub_weight_checks_passed=True,tests={'original_project':162,'clinc150':6},user_requested_pauses_resumed_successfully=True,final_summary_sha256=sha(path),finished_unix=time.time())
write_json(OUT/'verification.json',verification)
write_json(OUT/'execution_state.json',{'status':'complete','all_required_stages_completed':True,'user_pauses_preserved_in_history':True,'finished_unix':time.time()})
required=['summary.md','test_metrics.csv','validation_metrics.csv','paired_comparisons.csv','strategy_analysis.csv','oracle_analysis.json','validation_vs_test.csv','experiment_config.json','verification.json']
assert all((OUT/p).is_file() and (OUT/p).stat().st_size for p in required)
print('Final report polished. All 37500 logical records verified; all 12 metric rows independently matched; frozen protocol and original files unchanged.')
