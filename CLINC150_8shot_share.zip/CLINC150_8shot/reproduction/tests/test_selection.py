from dataclasses import replace

import numpy as np
import pytest

from src.retrieval import Candidate, SemanticRetriever
from src.selection import STRATEGIES, select_demonstrations
from src.utils import unit_vectors


@pytest.mark.parametrize("strategy", STRATEGIES)
@pytest.mark.parametrize("k", [4, 8, 12])
def test_budgets_uniqueness_membership_and_no_label_dependence(retrieval_case, strategy, k):
    frame, vectors, query = retrieval_case
    pool = SemanticRetriever(frame, vectors).retrieve(query)
    result = select_demonstrations(query, pool, strategy, k, query_id="val", query_text="Question")
    ids = [d["example_id"] for d in result["demonstrations"]]
    assert len(ids) == len(set(ids)) == k
    assert set(ids) <= {d.example_id for d in pool}
    assert result["candidate_pool_size"] == 32
    changed = [replace(d, label="changed", label_id=999) for d in pool]
    assert ids == [d["example_id"] for d in select_demonstrations(query, changed, strategy, k)["demonstrations"]]
    assert ids == [d["example_id"] for d in select_demonstrations(query, list(reversed(pool)), strategy, k)["demonstrations"]]
    if strategy == "similar":
        assert ids == [d.example_id for d in pool[:k]]


def test_random_is_query_local_and_seeded(retrieval_case):
    frame, vectors, query = retrieval_case
    pool = SemanticRetriever(frame, vectors).retrieve(query)
    first = select_demonstrations(query, pool, "random", seed=42)
    select_demonstrations(vectors[0], SemanticRetriever(frame, vectors).retrieve(vectors[0]), "random", seed=42)
    np.random.seed(1000)
    assert first == select_demonstrations(query, pool, "random", seed=42)
    assert len({tuple(d["example_id"] for d in select_demonstrations(query, pool, "random", seed=s)["demonstrations"])
                for s in [42, 43, 44, 45, 46]}) == 5


def geometric_pool():
    # Exact unit axes avoid floating point ties in this hand-calculated example.
    query = unit_vectors([1., 1., 0.])
    vectors = np.array([[1., 0., 0.], [0., 1., 0.], [0., 0., 1.], [-1., 0., 0.], [0., -1., 0.]], dtype=np.float32)
    scores = vectors @ query
    return query, [Candidate(str(i), f"text {i}", i, f"intent_{i}", float(scores[i]), i + 1, v)
                   for i, v in enumerate(vectors)]


def ids(result):
    return [d["example_id"] for d in result["demonstrations"]]


def test_diverse_manual_maxmin_rule():
    query, pool = geometric_pool()
    # Start +x; opposite -x is farthest; all remaining axes tie at min distance 1, so ID 1 wins.
    assert ids(select_demonstrations(query, pool, "diverse", 3)) == ["0", "3", "1"]


def test_mmr_manual_formula_and_lambda_controls():
    query, pool = geometric_pool()
    # After +x: +y has .5/sqrt(2), -x has .5-.5/sqrt(2), +z has 0.
    # After +y: +z has 0 and -x/-y have -.5/sqrt(2), so +z wins.
    assert ids(select_demonstrations(query, pool, "balanced", 3, mmr_lambda=0.5)) == ["0", "1", "2"]
    assert ids(select_demonstrations(query, pool, "balanced", 3, mmr_lambda=0)) == ["0", "3", "1"]
    assert ids(select_demonstrations(query, pool, "balanced", 5, mmr_lambda=1)) == ids(select_demonstrations(query, pool, "similar", 5))


@pytest.mark.parametrize("strategy", STRATEGIES)
def test_greedy_and_similarity_stable_ties(strategy):
    query, pool = geometric_pool()
    first = select_demonstrations(query, pool, strategy, 4)
    assert first == select_demonstrations(query, list(reversed(pool)), strategy, 4)


def test_invalid_selection_inputs(retrieval_case):
    frame, vectors, query = retrieval_case
    pool = SemanticRetriever(frame, vectors).retrieve(query)
    for k in (0, -1, 33):
        with pytest.raises(ValueError):
            select_demonstrations(query, pool, "similar", k)
    with pytest.raises(ValueError, match="distinct"):
        select_demonstrations(query, [pool[0]] * 8)
    with pytest.raises(ValueError, match="lambda"):
        select_demonstrations(query, pool, "balanced", mmr_lambda=1.1)
    with pytest.raises(ValueError, match="Unknown"):
        select_demonstrations(query, pool, "unknown")
