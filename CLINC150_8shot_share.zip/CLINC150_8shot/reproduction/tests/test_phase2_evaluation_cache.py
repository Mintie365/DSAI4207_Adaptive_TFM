from copy import deepcopy
import json

import numpy as np
import pytest

from src.evaluation import baseline_metrics, classification_metrics
from src.experiment_cache import PredictionCache, append_record, inference_key, read_records
from src.phase2_data import stratified_query_order
from src.retrieval_diagnostics import neighborhood_stats
from .conftest import make_frame
from .test_phase2_prompting import OFFICIAL_LABELS


def record(gold, predicted, *, query_id="q", strategy="similar", seed=None):
    return {"query_id": query_id, "gold_label": gold, "predicted_label": predicted,
            "valid": predicted is not None, "strategy": strategy, "random_seed": seed}


def test_accuracy_macro_f1_and_invalid_denominator():
    records = [record("a", "a"), record("b", "a"), record("c", None), record("c", "c")]
    values = classification_metrics(records, ["a", "b", "c"])
    assert values["accuracy"] == .5
    assert values["macro_f1"] == pytest.approx(4/9)
    assert values["invalid_rate"] == .25


def test_random_mean_std_and_no_pilot_winner():
    queries = [str(i) for i in range(10)]
    records = []
    for seed, correct in zip(range(42,47), (2,4,6,8,10)):
        records.extend(record("a", "a" if i < correct else "b", query_id=q, strategy="random", seed=seed)
                       for i,q in enumerate(queries))
    for strategy in ("similar", "diverse", "balanced"):
        records.extend(record("a", "a", query_id=q, strategy=strategy) for q in queries)
    metrics = baseline_metrics(records, ["a", "b"], queries, [42,43,44,45,46], full_validation=True)
    assert metrics["complete"]
    assert metrics["baselines"][0]["accuracy"] == pytest.approx(.6)
    assert metrics["baselines"][0]["accuracy_std"] == pytest.approx(np.std([.2,.4,.6,.8,1]))
    assert metrics["global_best_all_four"] is None  # 10 queries are not full validation.


def test_only_complete_full_validation_selects_both_winners_and_breaks_ties():
    queries = [str(i) for i in range(1003)]
    records = []
    for strategy in ("similar", "diverse", "balanced", "random"):
        for seed in ([42,43,44,45,46] if strategy == "random" else [None]):
            records.extend(record(OFFICIAL_LABELS[i%77], OFFICIAL_LABELS[i%77],
                                  query_id=q, strategy=strategy, seed=seed) for i,q in enumerate(queries))
    result = baseline_metrics(records, OFFICIAL_LABELS, queries, [42,43,44,45,46], full_validation=True)
    assert result["global_best_all_four"] == result["global_best_adaptive_candidates"] == "similar"
    assert baseline_metrics(records[:-1], OFFICIAL_LABELS, queries, [42,43,44,45,46], full_validation=True)["global_best_all_four"] is None
    for r in records:
        if r["strategy"] != "random":
            r["predicted_label"] = None
            r["valid"] = False
    result = baseline_metrics(records, OFFICIAL_LABELS, queries, [42,43,44,45,46], full_validation=True)
    assert result["global_best_all_four"] == "random"
    assert result["global_best_adaptive_candidates"] == "similar"


def test_stratified_nested_plan_and_descriptive_entropy():
    frame = make_frame(1003, 77, partition="validation")
    order = stratified_query_order(frame)
    assert order == stratified_query_order(frame)
    assert len(set(order)) == 1003
    assert frame.iloc[order[:32]].label.nunique() == 32
    assert frame.iloc[order[:128]].label.nunique() == 77
    assert neighborhood_stats(["a"]*16+["b"]*16) == {"unique_intents": 2, "entropy_bits":1., "top_label_vote":.5}
    assert neighborhood_stats(["a"]*32)["entropy_bits"] == 0


@pytest.mark.parametrize("key", ["query_id", "strategy", "demonstration_ids", "model_revision",
                                  "tokenizer_revision", "template_hash", "generation", "controls_hash"])
def test_cache_key_includes_all_controls(key):
    identity = {"query_id":"q", "strategy":"similar", "demonstration_ids":["1","2"],
                "model_revision":"commit", "tokenizer_revision":"commit", "template_hash":"v1",
                "generation":{"do_sample":False}, "controls_hash":"config"}
    changed = deepcopy(identity)
    changed[key] = "changed"
    assert inference_key(identity) != inference_key(changed)


def test_cache_roundtrip_integrity_and_gold_rejection(tmp_path):
    cache = PredictionCache(tmp_path)
    identity, result = {"query_id":"q"}, {"predicted_label":"a", "valid":True, "raw_output":"a"}
    assert cache.get(identity) is None
    key = cache.put(identity,result)
    assert cache.get(identity) == result
    with pytest.raises(ValueError,match="Gold"):
        inference_key({**identity,"gold_label":"a"})
    path = tmp_path/f"{key}.json"
    data = json.loads(path.read_text())
    data["prediction"]["raw_output"] = "tampered"
    path.write_text(json.dumps(data))
    with pytest.raises(ValueError,match="integrity"):
        cache.get(identity)


def test_jsonl_resume_recovers_only_partial_tail(tmp_path):
    path = tmp_path/"predictions.jsonl"
    append_record(path, {"cache_key":"1", "raw":"a"})
    with path.open("ab") as stream:
        stream.write(b'{"cache_key": "2", "raw":')
    assert read_records(path) == [{"cache_key":"1","raw":"a"}]
    assert path.with_suffix(".jsonl.partial-tail").exists()
    append_record(path, {"cache_key":"2","raw":"b"})
    assert len(read_records(path)) == 2
    path.write_text('broken\n{}\n')
    with pytest.raises(ValueError,match="Malformed"):
        read_records(path)
