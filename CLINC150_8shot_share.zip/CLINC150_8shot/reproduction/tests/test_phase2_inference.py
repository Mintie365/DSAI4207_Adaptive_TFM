from copy import deepcopy
import math
from types import SimpleNamespace

import pytest
import torch

from src.llm_inference import (QwenInference, automatic_device, greedy_generation_config,
                               inference_dtype, normalized_label_score)
from src.phase2_data import load_phase2_config
from src.prompting import build_prompt
from .test_phase2_prompting import OFFICIAL_LABELS, demo_fixture


class CharacterTokenizer:
    bos_token_id, eos_token_id, pad_token_id = 1, 2, 0
    chat_template = "synthetic-chat-template-test-only"

    def apply_chat_template(self, messages, tokenize=False, add_generation_prompt=True):
        assert tokenize is False and add_generation_prompt is True
        return "".join(m["role"] + ":\n" + m["content"] + "\n" for m in messages) + "assistant:\n"

    def __call__(self, text, **kwargs):
        assert kwargs["add_special_tokens"] is False and kwargs["truncation"] is False
        ids = torch.tensor([[ord(c) % 256 for c in text]], dtype=torch.long)
        return {"input_ids": ids, "attention_mask": torch.ones_like(ids)}

    def decode(self, values, **kwargs):
        return "".join(chr(i) for i in values.tolist())


class TinyModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.ones(1))
        self.config = SimpleNamespace(max_position_embeddings=30000)
        self.prompt_token_count = 0

    def generate(self, input_ids, attention_mask, generation_config):
        assert not generation_config.do_sample and generation_config.num_beams == 1
        assert not torch.is_grad_enabled() and not self.training
        answer = torch.tensor([[ord(c) for c in "reverted_card_payment?"]], device=input_ids.device)
        return torch.cat((input_ids, answer), dim=1)

    def forward(self, input_ids, attention_mask, logits_to_keep=0):
        logits = torch.zeros((*input_ids.shape, 256), device=input_ids.device)
        # Very bad scores on prompt positions and the final token's next-token
        # prediction: neither belongs to the candidate-label likelihood.
        if self.prompt_token_count:
            logits[:, :self.prompt_token_count-1, 0] = 40
        logits[:, -1, 0] = 40
        return SimpleNamespace(logits=logits[:, -logits_to_keep:] if logits_to_keep else logits)


def mock_engine():
    config = deepcopy(load_phase2_config())
    config["model"]["device"] = "cpu"
    config["prompt"]["max_input_tokens"] = 20000
    return QwenInference(config, "/unused", model=TinyModel(), tokenizer=CharacterTokenizer())


def test_frozen_greedy_inference_and_raw_output():
    engine = mock_engine()
    assert not engine.model.training and not any(p.requires_grad for p in engine.model.parameters())
    result = engine.predict_intent("A query", demo_fixture(), OFFICIAL_LABELS)
    assert result["valid"] and result["predicted_label"] == "reverted_card_payment?"
    assert result["prompt_tokens"] > 0 and result["runtime_seconds"] >= 0
    assert engine.identity["all_parameters_frozen"]
    assert engine.identity["tokenization"]["truncation"] is False


def test_overflow_fails_instead_of_truncating():
    engine = mock_engine()
    engine.config["prompt"]["max_input_tokens"] = 10
    with pytest.raises(ValueError, match="truncation is forbidden"):
        engine.predict_intent("query", demo_fixture(), OFFICIAL_LABELS)


def test_exact_continuation_causal_alignment_excludes_prompt_and_eos():
    engine = mock_engine()
    prompt = build_prompt("query", demo_fixture(), OFFICIAL_LABELS)
    batch, _ = engine.prepare(prompt)
    engine.model.prompt_token_count = batch["input_ids"].shape[1]
    score = engine.score_label("query", demo_fixture(), "reverted_card_payment?", OFFICIAL_LABELS)
    assert score["label_token_count"] == len("reverted_card_payment?")
    assert score["mean_log_likelihood"] == pytest.approx(-math.log(256), abs=1e-5)
    assert score["sum_log_likelihood"] == pytest.approx(-math.log(256)*len("reverted_card_payment?"), abs=1e-4)
    assert not score["includes_eos"]


def test_label_scoring_masks_padding_and_normalizes_token_count():
    logits = torch.zeros(2, 3, 4)
    targets = torch.tensor([[1, 2, 3], [3, 0, 0]])
    mask = torch.tensor([[True, True, True], [True, False, False]])
    logits[1, 1:, 0] = -100
    sums, means, counts = normalized_label_score(logits, targets, mask)
    assert counts.tolist() == [3, 1]
    torch.testing.assert_close(means, torch.tensor([-math.log(4)]*2))
    torch.testing.assert_close(sums, torch.tensor([-3*math.log(4), -math.log(4)]))


def test_device_priority_and_mps_precision(monkeypatch):
    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)
    monkeypatch.setattr(torch.backends.mps, "is_available", lambda: True)
    assert automatic_device() == "mps"
    assert inference_dtype("mps") is torch.float16
    monkeypatch.setattr(torch.cuda, "is_available", lambda: True)
    assert automatic_device() == "cuda"
    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)
    monkeypatch.setattr(torch.backends.mps, "is_available", lambda: False)
    assert automatic_device() == "cpu"
    assert inference_dtype("cpu") is torch.float32
    config = deepcopy(load_phase2_config())
    config["model"]["device"] = "mps"
    with pytest.raises(RuntimeError, match="ordinary macOS Terminal"):
        QwenInference(config, "/unused", model=TinyModel(), tokenizer=CharacterTokenizer())


def test_non_greedy_generation_is_rejected():
    config = deepcopy(load_phase2_config())
    config["generation"]["do_sample"] = True
    with pytest.raises(ValueError, match="greedy"):
        greedy_generation_config(config["generation"], CharacterTokenizer())
