from copy import deepcopy

import numpy as np
import pytest

from src.embeddings import cache_identity, load_cache, save_or_load_embeddings
from src.utils import load_config
from .conftest import make_frame


class FakeEncoder:
    device = "synthetic-test-only"

    def __init__(self):
        self.calls = 0

    def encode(self, texts):
        self.calls += 1
        return np.random.default_rng(42).normal(size=(len(texts), 6))


def cache_case(tmp_path):
    config = load_config()
    config["paths"]["embeddings"] = str(tmp_path)
    frame = make_frame(12, 3, partition="demonstration_pool")
    manifest = {"fingerprint": "synthetic-manifest"}
    return config, frame, manifest


def test_cache_roundtrip_reuses_without_encoding(tmp_path):
    config, frame, manifest = cache_case(tmp_path)
    encoder = FakeEncoder()
    a, key = save_or_load_embeddings(config, manifest, frame, "demonstration_pool", "commit-a", encoder)
    b, again = save_or_load_embeddings(config, manifest, frame, "demonstration_pool", "commit-a", encoder)
    assert encoder.calls == 1
    assert key == again
    np.testing.assert_array_equal(a, b)
    np.testing.assert_allclose(np.linalg.norm(a, axis=1), 1, atol=1e-6)


@pytest.mark.parametrize("change", ["model", "revision", "dataset", "text", "order", "max_seq_length"])
def test_cache_identity_changes_with_inputs(tmp_path, change):
    config, frame, manifest = cache_case(tmp_path)
    original = cache_identity(config, manifest, frame, "demonstration_pool", "commit-a")
    modified_config, modified_frame, modified_manifest = deepcopy(config), frame.copy(), dict(manifest)
    revision = "commit-a"
    if change == "model":
        modified_config["embedding"]["model"] = "another-model"
    elif change == "revision":
        revision = "commit-b"
    elif change == "dataset":
        modified_manifest["fingerprint"] = "different-splits"
    elif change == "text":
        modified_frame.loc[0, "text"] = "changed"
    elif change == "order":
        modified_frame = modified_frame.iloc[::-1]
    else:
        modified_config["embedding"]["max_seq_length"] = 128
    assert cache_identity(modified_config, modified_manifest, modified_frame, "demonstration_pool", revision) != original


def test_cache_rejects_corrupted_values_or_alignment(tmp_path):
    config, frame, manifest = cache_case(tmp_path)
    a, key = save_or_load_embeddings(config, manifest, frame, "demonstration_pool", "commit-a", FakeEncoder())
    identity = cache_identity(config, manifest, frame, "demonstration_pool", "commit-a")
    with pytest.raises(ValueError, match="alignment"):
        load_cache(tmp_path, key, identity, frame.iloc[::-1])
    a[0, 0] = 100
    np.save(tmp_path / f"demonstration_pool-{key}.npy", a)
    with pytest.raises(ValueError, match="integrity"):
        load_cache(tmp_path, key, identity, frame)
