from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from src.utils import unit_vectors


def make_frame(n, classes=77, source="train", partition=None):
    labels = np.arange(n) % classes
    frame = pd.DataFrame({"example_id": [f"{source}_{i:06d}" for i in range(n)],
                          "text": [f"Original customer utterance {i} from {source}" for i in range(n)],
                          "label": labels, "source_split": source,
                          "label_name": [f"intent_{label}" for label in labels]})
    if partition is not None:
        frame["partition"] = partition
    return frame


@pytest.fixture
def retrieval_case():
    frame = make_frame(48, classes=3, partition="demonstration_pool")
    rng = np.random.default_rng(101)
    return frame, unit_vectors(rng.normal(size=(48, 10))), unit_vectors(rng.normal(size=10))
