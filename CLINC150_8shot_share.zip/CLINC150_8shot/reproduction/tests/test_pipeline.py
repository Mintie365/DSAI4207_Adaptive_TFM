"""Offline full persistence→encode/cache→retrieval→selection→demo contract test."""
from copy import deepcopy
from types import SimpleNamespace

import numpy as np
import pytest

from src.demo import run_demo
from src.embeddings import generate_embeddings, load_embeddings
from src.prepare_data import load_prepared, prepare_data
from src.utils import load_config, read_json
from .conftest import make_frame


def test_offline_end_to_end_and_stale_data_rejection(tmp_path, monkeypatch):
    import datasets
    import huggingface_hub
    import src.embeddings as embedding_module

    config = deepcopy(load_config())
    config["paths"] = {name: str(tmp_path / name) for name in config["paths"]}
    config["dataset"].update(expected_train=100, expected_test=30, expected_classes=3,
                              sizes={"demonstration_pool": 60, "meta_training": 20, "validation": 20})
    names = [f"intent_{i}" for i in range(3)]

    class FakeSource:
        features = {"label": SimpleNamespace(names=names)}
        column_names = ["text", "label"]
        _fingerprint = "synthetic-source"

        def __init__(self, n, source):
            self.frame = make_frame(n, 3, source)

        def to_pandas(self):
            return self.frame.copy()

    class FakeApi:
        def dataset_info(self, *args, **kwargs):
            return SimpleNamespace(sha="synthetic-dataset-commit")

        def model_info(self, *args, **kwargs):
            return SimpleNamespace(sha="synthetic-model-commit")

    class FakeEncoder:
        device = "synthetic-offline-test"

        def __init__(self, *args):
            pass

        def encode(self, texts):
            import hashlib
            return np.stack([np.frombuffer(hashlib.sha256(t.encode()).digest(), dtype=np.uint8).astype(float) + 1
                             for t in texts])

    monkeypatch.setattr(huggingface_hub, "HfApi", FakeApi)
    monkeypatch.setattr(datasets, "load_dataset", lambda *a, **k: {"train": FakeSource(100, "train"), "test": FakeSource(30, "test")})
    monkeypatch.setattr(embedding_module, "SentenceEncoder", FakeEncoder)
    splits, manifest = prepare_data(config)
    restored, restored_manifest = load_prepared(config)
    assert restored_manifest == manifest
    for name in splits:
        assert splits[name].equals(restored[name])
    generate_embeddings(config, restored, manifest)
    arrays, index = load_embeddings(config, restored, manifest)
    output = run_demo(config, restored, arrays, manifest, index)
    persisted = read_json(tmp_path / "results" / "demo_examples.json")
    assert output == persisted
    assert len(output["examples"]) == 8
    assert all(len(example["candidate_pool"]) == 32 and len(example["selections"]) == 8
               for example in output["examples"])
    assert "synthetic-model-commit" in (tmp_path / "results" / "summary.md").read_text()
    changed = deepcopy(config)
    changed["embedding"]["max_seq_length"] = 128
    with pytest.raises(ValueError, match="configuration"):
        load_embeddings(changed, restored, manifest)
    changed = deepcopy(config)
    changed["seed"] = 99
    with pytest.raises(ValueError, match="configuration"):
        load_prepared(changed)
    restored["validation"].loc[0, "text"] = "tampered text"
    restored["validation"].to_csv(tmp_path / "splits" / "validation.csv", index=False)
    with pytest.raises(ValueError, match="changed"):
        load_prepared(config)
