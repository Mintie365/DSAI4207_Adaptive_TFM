import numpy as np
import pytest

from src.prepare_data import duplicate_audit, source_frame, stratified_splits, validate_splits
from .conftest import make_frame

SIZES = {"demonstration_pool": 7000, "meta_training": 2000, "validation": 1003}


def test_default_sizes_disjoint_coverage_mapping_and_reproducibility():
    train, test = make_frame(10003), make_frame(3080, source="test")
    names = [f"intent_{i}" for i in range(77)]
    splits = stratified_splits(train, test, SIZES, 42)
    validate_splits(splits, names, {**SIZES, "test": 3080})
    assert sum(map(len, splits.values())) == 13083
    assert set().union(*(set(f.example_id) for f in splits.values())) == set(train.example_id) | set(test.example_id)
    again = stratified_splits(train, test, SIZES, 42)
    changed = stratified_splits(train, test, SIZES, 43)
    for name, frame in splits.items():
        assert frame.equals(again[name])
        assert frame.label.nunique() == 77
        for row in frame.itertuples():
            original = (test if name == "test" else train).iloc[int(row.example_id.rsplit("_", 1)[1])]
            assert row.text == original.text
            assert row.label == original.label
    assert not splits["validation"].equals(changed["validation"])
    assert splits["test"].drop(columns="partition").equals(test)


def test_metadata_mapping_comes_from_dataset_not_sorted_names():
    class Dataset:
        def to_pandas(self):
            frame = make_frame(4, classes=2)
            frame["text"] = ["  Keep this!  ", "é", "Question?", "Original"]
            return frame
    frame = source_frame(Dataset(), "train", ["zebra_intent", "alpha_intent"])
    assert frame.label_name.tolist() == ["zebra_intent", "alpha_intent"] * 2
    assert frame.text.iloc[0] == "  Keep this!  "
    assert frame.example_id.tolist() == [f"train_{i:06d}" for i in range(4)]


def test_duplicate_detection_does_not_modify_test():
    left, right = make_frame(2, classes=2), make_frame(2, classes=2, source="test")
    left["text"] = ["My card payment was declined!", "Please help me track my missing bank card delivery"]
    right["text"] = [" my CARD payment was declined ", "Please help me track my missing bank card delivery today"]
    original = right.copy(deep=True)
    report = duplicate_audit({"demonstration_pool": left, "test": right}, threshold=0.7, batch_size=1)
    assert report["exact_cross_split_count"] == 1
    assert report["near_cross_split_count"] >= 1
    assert right.equals(original)
    assert not report["official_test_modified"]


def test_validation_rejects_overlap_and_incorrect_mapping():
    sizes = {"demonstration_pool": 60, "meta_training": 20, "validation": 20}
    splits = stratified_splits(make_frame(100, 3), make_frame(30, 3, "test"), sizes)
    splits["validation"].loc[0, "example_id"] = splits["meta_training"].loc[0, "example_id"]
    with pytest.raises(ValueError, match="IDs"):
        validate_splits(splits, [f"intent_{i}" for i in range(3)])
    splits = stratified_splits(make_frame(100, 3), make_frame(30, 3, "test"), sizes)
    splits["test"].loc[0, "label_name"] = "wrong"
    with pytest.raises(ValueError, match="mapping"):
        validate_splits(splits, [f"intent_{i}" for i in range(3)])


def test_invalid_sizes_fail_clearly():
    with pytest.raises(ValueError, match="sum"):
        stratified_splits(make_frame(100, 3), make_frame(30, 3, "test"), SIZES)
