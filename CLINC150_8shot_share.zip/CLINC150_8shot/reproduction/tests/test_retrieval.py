import inspect

import numpy as np
import pytest

from src.retrieval import SemanticRetriever


def test_top32_sorted_pool_membership_and_exact_cosines(retrieval_case):
    frame, vectors, query = retrieval_case
    retriever = SemanticRetriever(frame, vectors)
    candidates = retriever.retrieve(query)
    assert len(candidates) == len({c.example_id for c in candidates}) == 32
    assert {c.example_id for c in candidates} <= set(frame.example_id)
    assert [c.rank for c in candidates] == list(range(1, 33))
    reference = sorted(zip(frame.example_id, vectors @ query), key=lambda p: (-p[1], p[0]))[:32]
    assert [c.example_id for c in candidates] == [p[0] for p in reference]
    np.testing.assert_allclose([c.similarity for c in candidates], [p[1] for p in reference], atol=1e-6)


def test_stable_ties_independent_of_pool_order(retrieval_case):
    frame, vectors, query = retrieval_case
    vectors[:] = query
    a = SemanticRetriever(frame, vectors).retrieve(query)
    b = SemanticRetriever(frame.iloc[::-1], vectors[::-1]).retrieve(query)
    assert [c.example_id for c in a] == sorted(frame.example_id)[:32]
    assert [c.as_dict() for c in a] == [c.as_dict() for c in b]


def test_self_and_normalized_identical_text_exclusion(retrieval_case):
    frame, vectors, query = retrieval_case
    candidates = SemanticRetriever(frame, vectors).retrieve(query, query_id=frame.example_id.iloc[0],
                                                           query_text=frame.text.iloc[1].upper() + "!")
    assert len(candidates) == 32
    assert frame.example_id.iloc[0] not in {c.example_id for c in candidates}
    assert frame.example_id.iloc[1] not in {c.example_id for c in candidates}


def test_query_label_cannot_be_passed_or_affect_ranking(retrieval_case):
    frame, vectors, query = retrieval_case
    assert "query_label" not in inspect.signature(SemanticRetriever.retrieve).parameters
    original = SemanticRetriever(frame, vectors).retrieve(query)
    frame["label"] = frame.label + 100
    frame["label_name"] = "changed"
    changed = SemanticRetriever(frame, vectors).retrieve(query)
    assert [c.example_id for c in original] == [c.example_id for c in changed]
    with pytest.raises(TypeError):
        SemanticRetriever(frame, vectors).retrieve(query, query_label=1)


@pytest.mark.parametrize("partition,source", [("test", "test"), ("validation", "train"), ("meta_training", "train")])
def test_non_demo_partitions_rejected(retrieval_case, partition, source):
    frame, vectors, _ = retrieval_case
    frame["source_split"], frame["partition"] = source, partition
    with pytest.raises(ValueError):
        SemanticRetriever(frame, vectors)


def test_insufficient_pool_and_invalid_vectors(retrieval_case):
    frame, vectors, query = retrieval_case
    retriever = SemanticRetriever(frame, vectors)
    with pytest.raises(ValueError, match="enough"):
        retriever.retrieve(query, 100)
    with pytest.raises(ValueError):
        retriever.retrieve(np.zeros_like(query))
