from copy import deepcopy
from itertools import combinations

import numpy as np
import pandas as pd
import pytest

from src.strategy_analysis import (ambiguity_groups, ambiguity_summary, bootstrap_means, complementarity,
                                  exact_mcnemar, holm_adjust, metrics_tables, statistical_comparisons,
                                  validate_records,prediction_arrays)


def test_prediction_and_correctness_disagreement_are_distinct():
    predictions = {"similar":np.array(["a","a","x","x","x"],object),
                   "diverse":np.array(["a","b","y","x","b"],object),
                   "balanced":np.array(["a","b","z","x","c"],object)}
    gold = np.array(["a","b","a","a","c"],object)
    correct = {s:p==gold for s,p in predictions.items()}
    result = complementarity(predictions,correct)
    assert result["prediction_agreement"] == {"all_three_same":.4,"exactly_two_agree":.2,"all_three_different":.4}
    assert result["success_counts"] == {"0":2,"1":1,"2":1,"3":1}
    sd = next(row for row in result["pairwise"] if row["left"]=="similar" and row["right"]=="diverse")
    assert sd["prediction_disagreement_count"] == 3
    assert sd["correctness_disagreement_count"] == 1
    assert sd["different_but_both_wrong_count"] == 2
    assert result["rescue"]["similar_wrong_at_least_one_alternative_correct"]["count"] == 2
    assert sum(result["correctness_patterns"].values())==5


def test_quartile_boundary_ties_stay_together():
    entropy = np.array([0,0,.5,1,1,2,3,4])
    cutpoints = [.5,1,3]
    groups = ambiguity_groups(entropy,cutpoints)
    assert groups.tolist()==[0,0,0,1,1,2,2,3]
    assert np.all(groups[entropy==1]==1)


def test_oracle_gain_uses_global_and_within_group_reference_separately():
    correct = {"similar":np.array([1,1,0,0],bool),"diverse":np.array([0,0,1,1],bool),
               "balanced":np.array([0,1,0,1],bool)}
    predictions = {s:np.where(v,"a","x") for s,v in correct.items()}
    features = pd.DataFrame({"entropy_bits":[0.,1.,2.,3.],"top_label_vote":[1.,.8,.5,.2]})
    summary,correlations,groups = ambiguity_summary(features,predictions,correct,"similar",[.5,1.5,2.5])
    assert summary.oracle_accuracy.tolist()==[1.,1.,1.,1.]
    assert summary.oracle_gain_over_global_best.tolist()==[0.,0.,1.,1.]
    assert summary.oracle_gain_over_group_best.tolist()==[0.,0.,0.,0.]
    assert len(correlations)==10


def test_paired_bootstrap_reproducibility_and_shared_query_resampling():
    values = np.array([[0.,0.],[1.,1.],[0.,0.],[1.,1.]])
    a=bootstrap_means(values,500,42,50)
    b=bootstrap_means(values,500,42,50)
    np.testing.assert_array_equal(a,b)
    np.testing.assert_array_equal(a[:,0]-a[:,1],np.zeros(500))
    np.testing.assert_array_equal(bootstrap_means(np.ones(4),100),np.ones((100,1)))


def test_exact_mcnemar_and_holm_known_values():
    assert exact_mcnemar([1,1,1,1],[0,0,0,0])["mcnemar_exact_p"]==.125
    assert exact_mcnemar([1,0],[1,0])["mcnemar_exact_p"]==1.
    np.testing.assert_allclose(holm_adjust([.01,.04,.03]),[.03,.06,.06])


def test_random_bootstrap_keeps_five_predictions_as_one_query_cluster():
    correct = {"similar":np.array([1,0,1,0],bool),"diverse":np.array([0,1,1,0],bool),
               "balanced":np.array([0,0,1,0],bool),"zero_shot":np.array([0,0,0,0],bool)}
    random = np.repeat(correct["similar"][:,None],5,axis=1)
    config={"replicates":200,"seed":42,"batch_size":50,"confidence":.95}
    comparisons,sensitivity = statistical_comparisons(correct,random,"similar",config)
    same = comparisons.query("left=='random_mean' and right=='similar'").iloc[0]
    assert same.accuracy_difference==same.ci_95_low==same.ci_95_high==0.
    assert same.n==4
    assert same.random_unit=="query, averaging the same five fixed seeds"
    oracle=comparisons.query("left=='oracle'").iloc[0]
    assert oracle.accuracy_difference==.25


def validation_case():
    validation=pd.DataFrame({"example_id":["q1","q2"],"label_name":["a","b"]})
    records=[]
    for q,gold in zip(validation.example_id,validation.label_name):
        for strategy,seed in [(s,None) for s in ("similar","diverse","balanced","zero_shot")]+[("random",s) for s in range(42,47)]:
            records.append({"query_id":q,"gold_label":gold,"predicted_label":gold,"valid":True,
                            "raw_output":gold,"strategy":strategy,"random_seed":seed,"controls_hash":"frozen",
                            "actual_device":"mps","runtime_seconds":.1,
                            "demonstration_ids":[] if strategy=="zero_shot" else list(map(str,range(8))),
                            "candidate_ids":[] if strategy=="zero_shot" else list(map(str,range(32)))})
    return validation,records


def test_missing_duplicate_and_mixed_control_predictions_rejected():
    validation,records=validation_case()
    args=(validation,["a","b"],list(range(42,47)),"frozen")
    assert len(validate_records(records,*args))==18
    with pytest.raises(ValueError,match="Missing"):
        validate_records(records[:-1],*args)
    with pytest.raises(ValueError,match="duplicate"):
        validate_records(records+[records[0]],*args)
    changed=deepcopy(records);changed[0]["controls_hash"]="different"
    with pytest.raises(ValueError,match="controls"):
        validate_records(changed,*args)
    changed=deepcopy(records);changed[0]["gold_label"]="b"
    with pytest.raises(ValueError,match="gold"):
        validate_records(changed,*args)


def test_random_metrics_average_seeds_not_best_seed():
    validation,records=validation_case()
    # Five seeds have query accuracies .5,.5,.5,.5,1 -> mean=.6, best=1.
    for r in records:
        if r["strategy"]=="random" and r["random_seed"]!=46 and r["query_id"]=="q1":
            r["predicted_label"]="b";r["raw_output"]="b"
    table,seeds=metrics_tables(records,["a","b"],list(range(42,47)))
    random=table.set_index("strategy").loc["random"]
    assert random.accuracy==pytest.approx(.6)
    assert random.accuracy_std==pytest.approx(.2)
    assert random.correct_count==pytest.approx(1.2)
    assert random.incorrect_count==pytest.approx(.8)
    assert random.n==2
    assert len(seeds)==5


def test_invalid_raw_outputs_remain_distinct_and_never_oracle_successes():
    validation,records=validation_case()
    for r in records:
        if r["query_id"]=="q1" and r["strategy"] in ("similar","diverse","balanced"):
            r["valid"]=False;r["predicted_label"]=None;r["raw_output"]="unknown_"+r["strategy"]
    indexed=validate_records(records,validation,["a","b"],list(range(42,47)),"frozen")
    predictions,correct,_,_=prediction_arrays(indexed,validation.example_id.tolist(),["a","b"],list(range(42,47)))
    result=complementarity(predictions,correct)
    assert result["prediction_agreement"]["all_three_different"]==.5
    assert result["success_counts"]["0"]==1
    assert result["all_three_valid_query_count"]==1
