from copy import deepcopy
import json

import numpy as np
import pytest
import torch

from src.phase2_data import load_phase2_config
from src.phase2_pipeline import run_experiment, stage_plan
from src.utils import load_config, unit_vectors, write_json
from .conftest import make_frame
from .test_phase2_prompting import OFFICIAL_LABELS


class FakeInference:
    device = "cpu"
    identity = {"device":"cpu", "precision":"float32", "synthetic_model":True}

    def __init__(self):
        self.calls = 0

    def prepare(self,prompt):
        return {"input_ids":torch.tensor([[1,2,3]])}, json.dumps(prompt.messages)

    def predict_prepared(self,prompt,valid_labels,batch):
        self.calls += 1
        assert "gold_label" not in json.dumps(prompt.messages)
        return {"predicted_label":valid_labels[0], "valid":True, "raw_output":valid_labels[0],
                "prompt_tokens":3, "generated_tokens":1, "runtime_seconds":.01,
                "memory":{"process_peak_rss_bytes":1024}}


def fake_inputs(tmp_path,monkeypatch):
    import src.phase2_pipeline as pipeline
    config = deepcopy(load_phase2_config())
    config["results"] = str(tmp_path)
    phase1 = load_config()
    rng = np.random.default_rng(202)
    frames = {"demonstration_pool":make_frame(48,3,partition="demonstration_pool"),
              "validation":make_frame(20,3,source="val",partition="validation")}
    for frame in frames.values():
        frame["label_name"] = frame.label.map(dict(enumerate(OFFICIAL_LABELS)))
    arrays = {key:unit_vectors(rng.normal(size=(len(frame),10))) for key,frame in frames.items()}
    monkeypatch.setattr(pipeline,"load_phase2_inputs",lambda c:(phase1,frames,arrays,OFFICIAL_LABELS,
                                                              {"fingerprint":"fake"},{"keys":{"demo":"frozen"}}))
    write_json(tmp_path/"retrieval_diagnostics.json",{"dataset_manifest":"fake","query_count":20})
    return config,frames


def test_interrupt_resume_and_no_duplicate_inference(tmp_path,monkeypatch):
    config,frames = fake_inputs(tmp_path,monkeypatch)
    inference = FakeInference()
    path,status = run_experiment(config,query_count=20,inference=inference,allow_cpu_pilot=True,max_new_predictions=3)
    assert not status["complete"] and inference.calls == 4  # 3 predictions + one repeat
    again,status = run_experiment(config,query_count=20,inference=inference,allow_cpu_pilot=True)
    assert again == path and status["complete"] and inference.calls == 81
    predictions = [json.loads(line) for line in (path/"pilot_predictions.jsonl").read_text().splitlines()]
    assert len(predictions) == len({r["cache_key"] for r in predictions}) == 80
    assert all(r["random_seed"] == 42 for r in predictions if r["strategy"] == "random")
    run_experiment(config,query_count=20,inference=inference,allow_cpu_pilot=True)
    assert inference.calls == 81
    assert not any('"gold_label"' in p.read_text() for p in (tmp_path/"inference_cache").glob("*.json"))
    assert json.loads((path/"metrics.json").read_text())["global_best_status"] == "pending_full_validation"


def test_cpu_experiments_require_explicit_pilot_opt_in(tmp_path,monkeypatch):
    config,frames = fake_inputs(tmp_path,monkeypatch)
    with pytest.raises(RuntimeError,match="ordinary macOS Terminal"):
        run_experiment(config,query_count=20,inference=FakeInference())
    frame = make_frame(1003,77,partition="validation")
    _,seeds = stage_plan(config,"full",frame)
    assert seeds == [42,43,44,45,46]
    with pytest.raises(ValueError):
        stage_plan(config,"pilot-a",frame,10)
