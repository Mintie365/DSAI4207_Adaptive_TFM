`banking77_label_mapping.json` is copied verbatim from Phase 1's generated
`data/splits/label_mapping.json`, whose source is the Hugging Face Banking77
ClassLabel metadata at commit `1846984189f2bc0ac51c6fc3a600fa9e1714e0c6`.
It is a small offline test fixture, not a manually reconstructed intent list.
It permits testing all 77 labels without downloading data in the test suite.
