from copy import deepcopy

from src.full_validation_run import run_zero_shot
from src.phase2_data import load_phase2_config
from src.prompting import build_prompt
from src.utils import read_json
import json
from .conftest import make_frame
from .test_phase2_pipeline import FakeInference
from .test_phase2_prompting import OFFICIAL_LABELS,demo_fixture


def test_zero_shot_removes_only_demos_and_preserves_instructions_labels():
    icl=build_prompt("customer query",demo_fixture(),OFFICIAL_LABELS,k=8)
    zero=build_prompt("customer query",[],OFFICIAL_LABELS,k=0)
    assert zero.messages[0]==icl.messages[0]
    assert zero.messages[1]["content"].split("\n\n")[0]==icl.messages[1]["content"].split("\n\n")[0]
    assert zero.template_hash==icl.template_hash
    assert zero.demonstration_ids==[]
    body=zero.messages[1]["content"]
    assert all(f"- {label}\n" in body+"\n" for label in OFFICIAL_LABELS)
    assert "Demonstrations:" in body and "Demonstration 1" not in body
    assert 'Query: "customer query"\nIntent:' in body


def test_zero_shot_incremental_resume_has_no_duplicate_calls(tmp_path,monkeypatch):
    import src.full_validation_run as runner
    config=deepcopy(load_phase2_config())
    config["results"]=str(tmp_path/"phase2")
    analysis={"output":str(tmp_path/"full"),"zero_shot":{"method":"same_template_k_zero","eligible_for_adaptive_selection":False}}
    frame=make_frame(3,3,partition="validation")
    frame["label_name"]=frame.label.map(dict(enumerate(OFFICIAL_LABELS)))
    monkeypatch.setattr(runner,"load_phase2_inputs",lambda c:({}, {"validation":frame},{},OFFICIAL_LABELS,{"fingerprint":"frozen"},{}))
    engine=FakeInference()
    directory,complete=run_zero_shot(config,analysis,engine,"controls",max_new_predictions=1)
    assert not complete and engine.calls==1
    again,complete=run_zero_shot(config,analysis,engine,"controls")
    assert complete and again==directory and engine.calls==3
    run_zero_shot(config,analysis,engine,"controls")
    assert engine.calls==3
    assert read_json(directory/"status.json")["records"]==3
    sessions=[json.loads(line) for line in (directory/"execution_sessions.jsonl").read_text().splitlines()]
    assert len(sessions)==3 and sum(s["new_inference_calls"] for s in sessions)==3
    assert sessions[-1]["new_inference_calls"]==0 and sessions[-1]["cache_hits"]==3
