from pathlib import Path
import json

import pytest

from src.label_parsing import parse_intent
from src.prompting import build_prompt

MAPPING = json.loads((Path(__file__).parent / "fixtures/banking77_label_mapping.json").read_text())
OFFICIAL_LABELS = [MAPPING["id_to_label"][str(i)] for i in range(77)]


def demo_fixture():
    return [{"example_id": f"demo_{i}", "text": f"Bank query {i}", "label": OFFICIAL_LABELS[i],
             "similarity": 1.0 - i / 100} for i in range(8)]


def test_full_prompt_budget_labels_order_and_no_gold_input():
    demos = demo_fixture()
    a = build_prompt("Unique new utterance", list(reversed(demos)), OFFICIAL_LABELS)
    b = build_prompt("Unique new utterance", demos, OFFICIAL_LABELS)
    assert a == b
    assert a.demonstration_ids == [d["example_id"] for d in demos]
    body = a.messages[1]["content"]
    assert body.count("Demonstration ") == 8
    assert all(f"- {label}\n" in body + "\n" for label in OFFICIAL_LABELS)
    assert 'New Query:\nQuery: "Unique new utterance"\nIntent:' in body
    assert a.messages[0]["role"] == "system"
    with pytest.raises(TypeError):
        build_prompt("q", demos, OFFICIAL_LABELS, gold_label="LEAK")
    with pytest.raises(ValueError, match="exactly k"):
        build_prompt("q", demos[:-1], OFFICIAL_LABELS)
    with pytest.raises(ValueError, match="77"):
        build_prompt("q", demos, OFFICIAL_LABELS[:-1])


def test_equal_similarity_uses_id_tie_breaking():
    demos = demo_fixture()
    for demo in demos:
        demo["similarity"] = .5
    assert build_prompt("q", demos[::-1], OFFICIAL_LABELS).demonstration_ids == sorted(d["example_id"] for d in demos)


@pytest.mark.parametrize("label", OFFICIAL_LABELS)
def test_every_official_label_parses_exactly(label):
    assert parse_intent(label, OFFICIAL_LABELS)["predicted_label"] == label
    assert parse_intent(" \n" + label.upper() + "\n", OFFICIAL_LABELS)["predicted_label"] == label


def test_punctuation_preserved_and_invalid_outputs_not_repaired():
    assert "reverted_card_payment?" in OFFICIAL_LABELS
    assert parse_intent('"reverted_card_payment?"', OFFICIAL_LABELS)["valid"]
    assert not parse_intent("reverted_card_payment", OFFICIAL_LABELS)["valid"]
    for raw in ("", "unknown_intent", "Intent: " + OFFICIAL_LABELS[0], OFFICIAL_LABELS[0] + ".",
                OFFICIAL_LABELS[0] + "\n" + OFFICIAL_LABELS[1]):
        parsed = parse_intent(raw, OFFICIAL_LABELS)
        assert not parsed["valid"] and parsed["predicted_label"] is None
        assert parsed["raw_output"] == raw
    assert not parse_intent("duplicate", ["duplicate", "DUPLICATE"])["valid"]
