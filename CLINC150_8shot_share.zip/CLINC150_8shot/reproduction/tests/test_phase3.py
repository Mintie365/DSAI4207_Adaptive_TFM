import numpy as np
import pytest
from types import SimpleNamespace
from src.meta_features import feature_vector,FEATURES,STRATEGIES
from src.meta_scoring import choose_target
from src.meta_selectors import ConstantSelector,LogisticSelector,TabPFNV2Selector
from src.adaptive_evaluation import evaluate_strategy_choices

def test_features_are_exactly_four_and_use_only_candidate_metadata():
    pool=[SimpleNamespace(label=str(i%2),similarity=.9-i/100) for i in range(32)]
    z=feature_vector(pool)
    assert list(z)==FEATURES and z['entropy_bits']==1 and z['top_label_vote']==.5
    assert z['max_similarity']==.9 and z['mean_similarity']==pytest.approx(np.mean([p.similarity for p in pool]))
    with pytest.raises(TypeError):feature_vector(pool,gold_label='leak')

def test_mapping_ties_and_margin():
    assert STRATEGIES==('similar','diverse','balanced')
    assert choose_target([0,0,0])==(0,0.,3)
    assert choose_target([-3,-1,-1])==(2,0.,2)
    assert choose_target([-2,-1,0])==(2,1.,1)
    with pytest.raises(ValueError):choose_target([0,np.nan,1])

def test_adaptive_join_switching_invalid_and_oracle():
    rows=[]
    answers={'a':['x','gold','x'],'b':['gold','x','gold'],'c':['gold','gold','gold']}
    for q,values in answers.items():
        for s,p in zip(STRATEGIES,values):rows.append({'query_id':q,'strategy':s,'gold_label':'gold','predicted_label':p,'valid':p=='gold'})
    m,correct,similar,oracle=evaluate_strategy_choices(['c','a','b'],[1,1,1],rows,['gold','x'])
    assert m['beneficial']==1 and m['harmful']==1 and m['neutral_switches']==1
    assert m['gain_vs_similar']==0 and m['oracle_gap']==pytest.approx(1/3)
    assert correct.tolist()==[True,True,False]
    with pytest.raises(ValueError):evaluate_strategy_choices(['a'],[3],rows,['gold'])
    with pytest.raises(ValueError):evaluate_strategy_choices(['a'],[0],rows+[rows[0]],['gold'])

def test_tabpfn_factory_pins_version_device_and_checkpoint():
    observed={}
    class Model:
        def fit(self,X,y):observed['train_rows']=len(X);return self
        def predict(self,X):return np.ones(len(X),int)
        def predict_proba(self,X):return np.ones((len(X),3))/3
    def factory(version,**kwargs):observed.update(version=version,**kwargs);return Model()
    c={'seed':42,'tabpfn':{'device':'mps','n_estimators':4}}
    m=TabPFNV2Selector(c,{'path':'pinned.ckpt'},factory=factory).fit(np.ones((20,4)),np.arange(20)%3)
    assert observed['version']=='v2' and observed['model_path']=='pinned.ckpt' and observed['device']=='mps'
    assert len(m.predict(np.ones((3,4))))==3

def test_logistic_scaler_fits_training_only():
    r=np.random.default_rng(42);X=r.normal(size=(45,4));y=np.arange(45)%3
    cfg={'seed':42,'cv_folds':3,'logistic_c':[1.],'logistic_class_weight':[None,'balanced']}
    m=LogisticSelector(cfg).fit(X,y);before=m.model.named_steps['scale'].mean_.copy()
    m.predict(np.full((4,4),1000.))
    np.testing.assert_allclose(before,X.mean(axis=0));np.testing.assert_array_equal(before,m.model.named_steps['scale'].mean_)
    assert 'nested_oof_accuracy' in m.diagnostics

def test_constant_policy():
    assert ConstantSelector().predict(np.ones((4,4))).tolist()==[0]*4

def test_meta_scoring_resumes_without_repeating_model_calls(tmp_path,monkeypatch):
    import pandas as pd
    import src.meta_scoring as scoring
    from tests.conftest import make_frame
    from tests.test_phase2_prompting import OFFICIAL_LABELS
    from src.utils import read_json as real_read
    rng=np.random.default_rng(42)
    demo=make_frame(48,3,partition='demonstration_pool');meta=make_frame(2,3,source='meta',partition='meta_training')
    for f in (demo,meta):f['label_name']=f.label.map(dict(enumerate(OFFICIAL_LABELS)))
    arrays={'demonstration_pool':rng.normal(size=(48,4)),'meta_training':rng.normal(size=(2,4))}
    class Fake:
        calls=0;device='mps';identity={'frozen':'mock'}
        def __init__(self,*a):pass
        def _synchronize(self):pass
        def score_label(self,query,demos,target,labels):
            Fake.calls+=1
            return {'mean_log_likelihood':-1.,'sum_log_likelihood':-2.,'target_label':target,'label_token_count':2,'prompt_hash':'mock','includes_eos':False}
    cfg=scoring.config()
    p1={'paths':{'hub_cache':'unused'},'retrieval':{'exclude_identical_text':False}}
    p2={'model':{'device':'mps','revision':'pinned'}}
    pd.DataFrame([{'query_id':q,**dict.fromkeys(FEATURES,.5)} for q in meta.example_id]).to_csv(tmp_path/'meta_features_train.csv',index=False)
    monkeypatch.setattr(scoring,'prepare',lambda:tmp_path)
    monkeypatch.setattr(scoring,'inputs',lambda:(p2,p1,{'meta_training':meta,'demonstration_pool':demo},arrays,OFFICIAL_LABELS,{'fingerprint':'fixed'},{}))
    monkeypatch.setattr(scoring,'QwenInference',Fake)
    monkeypatch.setattr(scoring,'read_json',lambda p: {'inference':Fake.identity} if str(p).endswith('full_validation/experiment_config.json') else real_read(p))
    scoring.score(1)
    assert Fake.calls==4
    before=(tmp_path/'meta_label_scores.jsonl').read_bytes()
    scoring.score(1)
    assert Fake.calls==4 and (tmp_path/'meta_label_scores.jsonl').read_bytes()==before
    scoring.score()
    assert Fake.calls==7 and len(pd.read_csv(tmp_path/'meta_training_dataset.csv'))==2
