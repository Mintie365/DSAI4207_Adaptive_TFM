from __future__ import annotations

import json
import hashlib
from collections import Counter
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from scipy.stats import binomtest

import src.pipeline as p

STRATEGIES = p.STRATEGIES
FEATURES = p.FEATURES
TIE_ORDER = p.TIE_ORDER


def _write_jsonl(path: Path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    tmp.replace(path)


def prepare_correctness_predictions():
    """Generate and cache actual Qwen predictions for meta-training queries only."""
    records = p.load_query_records("meta_training")
    cache_path = p.CACHE / "predictions" / "meta_training_correctness.jsonl"
    cache_path.parent.mkdir(parents=True, exist_ok=True)

    cached = {}
    if cache_path.exists():
        for line in cache_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                print("Ignoring an incomplete final cache line; it will be regenerated.", flush=True)
                continue
            cached[(row["query_id"], row["strategy"])] = row

    required = {(r["query_id"], s) for r in records for s in STRATEGIES}
    unexpected = set(cached) - required
    if unexpected:
        raise RuntimeError(f"Correctness cache contains unexpected rows: {len(unexpected)}")

    missing = required - set(cached)
    if missing:
        labels_map = p.read_json(p.DATA / "splits" / "label_mapping.json")
        labels = [labels_map[str(i)] for i in range(64)]
        runner = p.QwenRunner(labels)
        # Do not mix predictions made by different model/checkpoint/prompt identities.
        old_hashes = {r.get("inference_identity_hash") for r in cached.values()}
        if old_hashes and old_hashes != {runner.inference_identity_hash}:
            print("Correctness cache identity changed; rebuilding it.", flush=True)
            cached = {}
            missing = required
        with cache_path.open("w", encoding="utf-8") as f:
            for record in records:
                qid = record["query_id"]
                for strategy in STRATEGIES:
                    key = (qid, strategy)
                    if key in cached:
                        f.write(json.dumps(cached[key], ensure_ascii=False) + "\n")
                        continue
                    result = runner.predict(record["query"], record["demonstrations"][strategy])
                    row = {
                        "query_id": qid,
                        "strategy": strategy,
                        "prediction": result["prediction"],
                        "valid": bool(result["valid"]),
                        "raw_output": result["raw_output"],
                        "prompt_hash": result["prompt_hash"],
                        "inference_identity_hash": runner.inference_identity_hash,
                        "model_revision": runner.model_revision,
                        "runtime_seconds": float(result.get("runtime_seconds", 0.0)),
                    }
                    cached[key] = row
                    f.write(json.dumps(row, ensure_ascii=False) + "\n")
                f.flush()
                if len(cached) % 150 == 0 or len(cached) == len(required):
                    print(f"Correctness predictions: {len(cached)}/{len(required)}", flush=True)
    else:
        print(f"Using complete correctness prediction cache: {len(cached)} rows", flush=True)

    if set(cached) != required:
        raise RuntimeError(f"Incomplete correctness predictions: {len(cached)}/{len(required)}")
    return cached


def build_correctness_training_data(prediction_lookup):
    records = p.load_query_records("meta_training")
    rows = []
    for record in records:
        row = {"query_id": record["query_id"], **record["features"],
               "gold_label": record["gold_label"]}
        for strategy in STRATEGIES:
            pred = prediction_lookup[(record["query_id"], strategy)]
            row[f"{strategy}_prediction"] = pred["prediction"]
            row[f"{strategy}_valid"] = bool(pred["valid"])
            row[f"{strategy}_correct"] = int(bool(pred["valid"]) and pred["prediction"] == record["gold_label"])
        rows.append(row)
    frame = pd.DataFrame(rows)
    if frame["query_id"].duplicated().any():
        raise ValueError("Duplicate query IDs in correctness training data")
    if not np.isfinite(frame[list(FEATURES)].to_numpy(dtype=float)).all():
        raise ValueError("Non-finite meta-features")
    for strategy in STRATEGIES:
        if not set(frame[f"{strategy}_correct"].unique()).issubset({0, 1}):
            raise ValueError(f"Invalid correctness targets for {strategy}")
    out = p.ARTIFACTS / "correctness_meta_training_dataset.csv"
    frame.to_csv(out, index=False)
    counts = {
        s: {"correct": int(frame[f"{s}_correct"].sum()),
            "incorrect": int((1 - frame[f"{s}_correct"]).sum())}
        for s in STRATEGIES
    }
    diag = {
        "target_method": "actual greedy Qwen prediction compared with meta-training ground-truth intent; correct=1, incorrect=0",
        "n_queries": int(len(frame)),
        "n_strategy_predictions": int(len(frame) * len(STRATEGIES)),
        "strategy_correctness_counts": counts,
        "features": list(FEATURES),
        "validation_or_test_gold_used_for_training": False,
        "invalid_generations_counted_as_incorrect": True,
        "selector_design": "three independent binary probability predictors; choose the strategy with highest predicted correctness probability",
    }
    p.write_json(p.ARTIFACTS / "correctness_meta_diagnostics.json", diag)
    print("Correctness target counts:", counts, flush=True)
    return frame, diag


def _positive_probability(model, X):
    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(X)
        classes = list(model.classes_)
        return probs[:, classes.index(1)] if 1 in classes else np.zeros(len(X), dtype=float)
    return model.predict(X).astype(float)


def train_binary_selectors(meta: pd.DataFrame):
    X = meta[list(FEATURES)].to_numpy(dtype=np.float64)
    lr_models, tab_models, training = {}, {}, {}

    import torch
    cfg = p.read_config()["meta_selector"]
    requested = cfg["tabpfn_device"]
    if requested == "auto":
        tab_device = "cuda" if torch.cuda.is_available() else ("mps" if torch.backends.mps.is_available() else "cpu")
    else:
        tab_device = requested

    for strategy in STRATEGIES:
        y = meta[f"{strategy}_correct"].to_numpy(dtype=int)
        classes, counts = np.unique(y, return_counts=True)
        class_counts = {str(int(c)): int(n) for c, n in zip(classes, counts)}
        if len(classes) == 1:
            lr = DummyClassifier(strategy="constant", constant=int(classes[0])).fit(X, y)
            tab = DummyClassifier(strategy="constant", constant=int(classes[0])).fit(X, y)
            lr_kind = tab_kind = "constant_fallback_single_target_class"
        else:
            lr = Pipeline([
                ("scale", StandardScaler()),
                ("classifier", LogisticRegression(C=1.0, class_weight="balanced",
                                                   max_iter=2000, random_state=42)),
            ]).fit(X, y)
            if tab_device == "cpu" and len(X) > 1000:
                raise RuntimeError("TabPFN-v2 with 1,791 rows requires the configured MPS/CUDA device; CPU fallback is disabled.")
            tab, _ = p.make_tabpfn(tab_device)
            tab.fit(X, y)
            lr_kind, tab_kind = "logistic_regression", "tabpfn_v2"
        lr_models[strategy] = lr
        tab_models[strategy] = tab
        training[strategy] = {"class_counts": class_counts,
                              "logistic_regression": lr_kind,
                              "tabpfn": tab_kind}
        print(f"Fitted {strategy}: target counts={class_counts}", flush=True)

    joblib.dump(lr_models, p.MODELS / "correctness_logistic_regression.joblib")
    # Save the target matrix and model diagnostics; TabPFN objects are kept in memory for evaluation.
    np.savez_compressed(p.MODELS / "correctness_selector_fit_context.npz",
                        X=X, **{f"y_{s}": meta[f"{s}_correct"].to_numpy(dtype=int) for s in STRATEGIES})
    p.write_json(p.MODELS / "correctness_selector_metadata.json", {
        "training_rows": int(len(meta)), "features": list(FEATURES),
        "device": tab_device, "tabpfn_version": "v2",
        "tabpfn_estimators": int(cfg["tabpfn_estimators"]),
        "per_strategy": training,
    })
    return lr_models, tab_models, training


def _choice_from_probabilities(prob_matrix):
    # Ties follow the project's predeclared Similar > Balanced > Diverse order.
    tie_ids = [STRATEGIES.index(s) for s in TIE_ORDER]
    result = []
    for row in prob_matrix:
        best = max(row)
        result.append(next(i for i in tie_ids if np.isclose(row[i], best, atol=1e-12, rtol=0)))
    return np.asarray(result, dtype=int)


def freeze_heldout_decisions(lr_models, tab_models):
    prepared = {}
    for split in ("validation", "test"):
        records = p.load_query_records(split)
        predictions = p.load_predictions(split).pivot(index="query_id", columns="strategy", values="prediction")
        X = np.asarray([r["features"] for r in records], dtype=np.float64)
        lr_probs = np.column_stack([_positive_probability(lr_models[s], X) for s in STRATEGIES])
        tab_probs = np.column_stack([_positive_probability(tab_models[s], X) for s in STRATEGIES])
        lr_choice = _choice_from_probabilities(lr_probs)
        tab_choice = _choice_from_probabilities(tab_probs)
        qids = [r["query_id"] for r in records]
        selected_lr = [predictions.loc[qid, STRATEGIES[i]] for qid, i in zip(qids, lr_choice)]
        selected_tab = [predictions.loc[qid, STRATEGIES[i]] for qid, i in zip(qids, tab_choice)]
        rows = []
        for i, qid in enumerate(qids):
            row = {"query_id": qid,
                   "similar": predictions.loc[qid, "similar"],
                   "diverse": predictions.loc[qid, "diverse"],
                   "balanced": predictions.loc[qid, "balanced"],
                   "correctness_lr_prediction": selected_lr[i],
                   "correctness_tabpfn_prediction": selected_tab[i],
                   "correctness_lr_selected_strategy": STRATEGIES[lr_choice[i]],
                   "correctness_tabpfn_selected_strategy": STRATEGIES[tab_choice[i]]}
            for j, strategy in enumerate(STRATEGIES):
                row[f"lr_p_correct_{strategy}"] = float(lr_probs[i, j])
                row[f"tabpfn_p_correct_{strategy}"] = float(tab_probs[i, j])
            rows.append(row)
        pd.DataFrame(rows).to_csv(p.ARTIFACTS / f"correctness_{split}_decisions_frozen.csv", index=False)
        prepared[split] = {"records": records, "rows": rows,
                           "lr_choices": [STRATEGIES[i] for i in lr_choice],
                           "tab_choices": [STRATEGIES[i] for i in tab_choice]}
        print(f"Frozen {split} decisions: {len(rows)} queries", flush=True)
    return prepared


def _paired_vs_similar(gold, outputs, replicates=5000):
    base_ok = np.asarray(outputs["similar"], dtype=object) == np.asarray(gold, dtype=object)
    rng = np.random.default_rng(42)
    n = len(gold)
    names = [x for x in outputs if x != "similar"]
    rows, raw_p = [], []
    for name in names:
        other_ok = np.asarray(outputs[name], dtype=object) == np.asarray(gold, dtype=object)
        b = int(np.sum((~base_ok) & other_ok))
        c = int(np.sum(base_ok & (~other_ok)))
        pv = float(binomtest(min(b, c), b + c, 0.5).pvalue) if b + c else 1.0
        diff = other_ok.astype(float) - base_ok.astype(float)
        samples = rng.integers(0, n, size=(replicates, n))
        boot = diff[samples].mean(axis=1) * 100
        rows.append({"comparison": f"{name} - similar",
                     "delta_accuracy_pp": float(diff.mean() * 100),
                     "bootstrap_95ci_pp": [float(np.quantile(boot, .025)), float(np.quantile(boot, .975))],
                     "mcnemar_p": pv, "method_better_only": b, "similar_better_only": c})
        raw_p.append(pv)
    order = np.argsort(raw_p)
    adjusted = np.empty(len(raw_p), dtype=float)
    running = 0.0
    for rank, idx in enumerate(order):
        running = max(running, min(1.0, (len(raw_p) - rank) * raw_p[idx]))
        adjusted[idx] = running
    for row, pv in zip(rows, adjusted):
        row["holm_adjusted_p"] = float(pv)
    return rows


def evaluate_and_report(prepared, target_diag):
    # All selector choices and selected predictions were frozen before reading held-out gold labels.
    split_frames, _, _ = p.load_splits()
    label_map = p.read_json(p.DATA / "splits" / "label_mapping.json")
    label_names = [label_map[str(i)] for i in range(64)]
    report = {"method": "Correctness-based, three independent binary selectors",
              "target_diagnostics": target_diag, "splits": {}}

    for split in ("validation", "test"):
        item = prepared[split]
        qids = [r["query_id"] for r in item["records"]]
        gold_by_id = split_frames[split].set_index("example_id")["label_name"].to_dict()
        gold = [gold_by_id[qid] for qid in qids]
        frozen = pd.DataFrame(item["rows"])
        baseline_path = p.ARTIFACTS / f"{split}_predictions_and_choices.csv"
        if not baseline_path.exists():
            raise FileNotFoundError(f"Missing completed baseline results: {baseline_path}")
        baseline = pd.read_csv(baseline_path, keep_default_na=False)
        baseline = baseline.set_index("query_id").loc[qids]
        outputs = {
            "similar": baseline["similar"].tolist(),
            "diverse": baseline["diverse"].tolist(),
            "balanced": baseline["balanced"].tolist(),
            "likelihood_lr": baseline["logistic_regression"].tolist(),
            "likelihood_tabpfn": baseline["tabpfn_v2"].tolist(),
            "correctness_lr": frozen["correctness_lr_prediction"].tolist(),
            "correctness_tabpfn": frozen["correctness_tabpfn_prediction"].tolist(),
        }
        metrics = {name: p.metric_row(gold, pred, label_names) for name, pred in outputs.items()}
        metrics["correctness_lr_switch_analysis"] = p.switch_analysis(
            gold, outputs["similar"], outputs["correctness_lr"], item["lr_choices"])
        metrics["correctness_tabpfn_switch_analysis"] = p.switch_analysis(
            gold, outputs["similar"], outputs["correctness_tabpfn"], item["tab_choices"])
        metrics["correctness_lr_strategy_distribution"] = dict(Counter(item["lr_choices"]))
        metrics["correctness_tabpfn_strategy_distribution"] = dict(Counter(item["tab_choices"]))
        metrics["paired_comparisons_vs_similar"] = _paired_vs_similar(
            gold, outputs, p.read_config()["evaluation"]["bootstrap_replicates"])

        out_rows = []
        for i, qid in enumerate(qids):
            row = {"query_id": qid, "gold_label": gold[i]}
            for name, values in outputs.items():
                row[name] = values[i]
                row[f"{name}_correct"] = bool(values[i] == gold[i])
            row["correctness_lr_selected_strategy"] = item["lr_choices"][i]
            row["correctness_tabpfn_selected_strategy"] = item["tab_choices"][i]
            out_rows.append(row)
        pd.DataFrame(out_rows).to_csv(p.ARTIFACTS / f"correctness_{split}_predictions_and_choices.csv", index=False)
        report["splits"][split] = metrics
        print(f"{split} correctness-based results:", {
            name: f"{value['correct']}/{value['n']} ({value['accuracy']*100:.3f}%)"
            for name, value in metrics.items() if isinstance(value, dict) and "accuracy" in value
        }, flush=True)

    p.write_json(p.ARTIFACTS / "correctness_experiment.json", report)
    lines = ["# HWU64 Correctness-based Selector Experiment", "",
             "Meta-labels are constructed by comparing each greedy Qwen prediction with the HWU64 ground-truth intent. Invalid outputs count as incorrect.",
             "Three independent binary selectors estimate the probability that Similar, Diverse, and Balanced will be correct; the highest estimated probability is selected.",
             "", "## Target counts", ""]
    for s, counts in target_diag["strategy_correctness_counts"].items():
        lines.append(f"- **{s}:** {counts['correct']} correct, {counts['incorrect']} incorrect")
    for split in ("validation", "test"):
        lines += ["", f"## {split.title()} results", "",
                  "| Method | Correct | Accuracy | Macro-F1 |", "|---|---:|---:|---:|"]
        metrics = report["splits"][split]
        for name in ("similar", "diverse", "balanced", "likelihood_lr", "likelihood_tabpfn", "correctness_lr", "correctness_tabpfn"):
            m = metrics[name]
            lines.append(f"| {name} | {m['correct']}/{m['n']} | {m['accuracy']*100:.3f}% | {m['macro_f1']:.5f} |")
        lines += ["", "### Strategy switching", "",
                  f"- Correctness LR: {metrics['correctness_lr_switch_analysis']}",
                  f"- Correctness TabPFN: {metrics['correctness_tabpfn_switch_analysis']}",
                  "", "### Paired comparisons against fixed Similar", "",
                  "| Comparison | Δ Accuracy (pp) | Bootstrap 95% CI | McNemar p | Holm p |",
                  "|---|---:|---:|---:|---:|"]
        for row in metrics["paired_comparisons_vs_similar"]:
            ci = row["bootstrap_95ci_pp"]
            lines.append(f"| {row['comparison']} | {row['delta_accuracy_pp']:.3f} | [{ci[0]:.3f}, {ci[1]:.3f}] | {row['mcnemar_p']:.4f} | {row['holm_adjusted_p']:.4f} |")
    lines += ["", "## Leakage controls", "",
              "- Ground-truth labels are used to construct targets only for the meta-training split.",
              "- Validation/test selector decisions are frozen before their ground-truth labels are loaded for evaluation.",
              "- Existing likelihood-based results are read from the completed baseline CSVs and are not overwritten.", ""]
    (p.REPORT / "HWU64_Correctness_实验报告.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"JSON: {p.ARTIFACTS / 'correctness_experiment.json'}", flush=True)
    print(f"CSV: {p.ARTIFACTS / 'correctness_meta_training_dataset.csv'}", flush=True)
    print(f"Report: {p.REPORT / 'HWU64_Correctness_实验报告.md'}", flush=True)


def main():
    p.ensure_dirs()
    for required in (p.DATA / "splits" / "manifest.json",
                     p.CACHE / "queries" / "meta_training.jsonl",
                     p.CACHE / "queries" / "validation.jsonl",
                     p.CACHE / "queries" / "test.jsonl",
                     p.CACHE / "predictions" / "validation.jsonl",
                     p.CACHE / "predictions" / "test.jsonl",
                     p.ARTIFACTS / "validation_predictions_and_choices.csv",
                     p.ARTIFACTS / "test_predictions_and_choices.csv"):
        if not required.exists():
            raise FileNotFoundError(f"Required completed baseline artifact is missing: {required}. Run the original baseline first.")
    print("Step 1/4: generating/reusing Qwen correctness predictions for meta-training...", flush=True)
    pred_lookup = prepare_correctness_predictions()
    print("Step 2/4: constructing correctness targets...", flush=True)
    meta, diag = build_correctness_training_data(pred_lookup)
    print("Step 3/4: training three binary LR models and three binary TabPFN models...", flush=True)
    lr_models, tab_models, _ = train_binary_selectors(meta)
    print("Step 4/4: freezing validation/test choices and evaluating...", flush=True)
    prepared = freeze_heldout_decisions(lr_models, tab_models)
    evaluate_and_report(prepared, diag)
    print("Correctness-based experiment completed.", flush=True)


if __name__ == "__main__":
    main()
