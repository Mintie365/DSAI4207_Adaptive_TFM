# Banking77 实验运行说明

本版本在保留原 HWU64 路径、配置和缓存的基础上，增加独立的 Banking77 实验入口。

## 已固定的实验设置

- 数据集：Banking77，训练集 10,003 条，官方测试集 3,080 条，77 类
- Seed：42；训练集按 70% Demonstration Pool / 20% Meta-training / 10% Validation 分层划分
- Embedding：原项目固定的 all-MiniLM-L6-v2 checkpoint
- Retrieval：cosine Top-32，排除规范化后完全相同的文本
- Demonstrations：8-shot；Similar / Diverse (greedy MaxMin) / Balanced (MMR λ=0.5)
- LLM：原项目固定的 Qwen2.5-1.5B-Instruct checkpoint，greedy decoding
- Meta-label：Meta-training gold-label continuation mean token log-likelihood argmax
- Selectors：Logistic Regression + TabPFN-v2

## 数据位置

把已经下载并验证过的两个 CSV 放在原项目目录：

`data/banking77/raw/train.csv`
`data/banking77/raw/test.csv`

CSV 必须包含 `text` 和 `category` 两列。程序会检查行数、缺失值和 77 个类别。

## 运行

在项目目录执行：

```bash
PYTHON="$HOME/Downloads/HWU64_8shot_OfficialMethod/.venv312/bin/python" bash scripts/run_banking77.sh prepare-data
```

确认显示 `Banking77 loaded: train=10003, test=3080, classes=77` 且四个 split 都包含 77 类后，再运行：

```bash
PYTHON="$HOME/Downloads/HWU64_8shot_OfficialMethod/.venv312/bin/python" HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 TRANSFORMERS_OFFLINE=1 bash scripts/run_banking77.sh all
```

如果你希望分阶段执行，也可以把 `all` 换成 `embed`、`prepare-queries`、`predict`、`score-meta`、`evaluate` 或 `report`。

## Banking77 输出位置

所有 Banking77 的 split、embedding cache、prediction cache、模型、结果和报告都写入：

`experiments/banking77/`

原 HWU64 的 `data/splits`、`cache/`、`models/`、`results/` 和 `report/` 不会被 Banking77 覆盖。

## 重要

本版本没有更换实验方法或模型参数。HWU64 的 prompt-version 标识也保持原值，以免误使原 HWU64 prediction cache 失效。Banking77 使用独立 prompt-version 和独立实验目录。
