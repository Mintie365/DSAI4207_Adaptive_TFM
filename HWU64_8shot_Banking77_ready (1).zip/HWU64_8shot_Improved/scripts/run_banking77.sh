#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_DIR"

if [[ -n "${PYTHON:-}" ]]; then
  PYTHON_BIN="$PYTHON"
elif [[ -x "$PROJECT_DIR/.venv312/bin/python" ]]; then
  PYTHON_BIN="$PROJECT_DIR/.venv312/bin/python"
elif [[ -x "$PROJECT_DIR/.venv/bin/python" ]]; then
  PYTHON_BIN="$PROJECT_DIR/.venv/bin/python"
else
  PYTHON_BIN="$(command -v python3 || true)"
fi
if [[ -z "$PYTHON_BIN" || ! -x "$PYTHON_BIN" ]]; then
  echo "ERROR: Python not found." >&2
  exit 1
fi
export PYTHONPATH="$PROJECT_DIR${PYTHONPATH:+:$PYTHONPATH}"
export EXPERIMENT_CONFIG="$PROJECT_DIR/configs/banking77.yaml"
export HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 TRANSFORMERS_OFFLINE=1
STAGE="${1:-all}"
echo "Dataset: Banking77"
echo "Config: $EXPERIMENT_CONFIG"
echo "Python: $PYTHON_BIN"
echo "Stage: $STAGE"
exec "$PYTHON_BIN" "$PROJECT_DIR/run.py" "$STAGE"
