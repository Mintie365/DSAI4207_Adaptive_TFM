import importlib.metadata
import platform

print("Python:", platform.python_version())
for package in ("torch", "transformers", "datasets", "sentence-transformers", "tabpfn", "scikit-learn"):
    try:
        print(f"{package}: {importlib.metadata.version(package)}")
    except importlib.metadata.PackageNotFoundError:
        print(f"{package}: NOT INSTALLED")
try:
    import torch
    print("CUDA available:", torch.cuda.is_available())
    print("MPS available:", torch.backends.mps.is_available())
except Exception as exc:
    print("Torch check failed:", repr(exc))
