# HWU64 8-shot Query-Adaptive Demonstration Selection

这是基于你上传的 Banking77 项目流程，重新整理的 **HWU64 独立实验版本**。代码不会修改你原来的 Banking77 ZIP。

本项目目标：冻结 Qwen2.5-1.5B-Instruct，在 HWU64 的 64 个 intent 上比较三种 8-shot demonstration selection 策略，并训练 Logistic Regression 与 TabPFN-v2 作为 query-level meta-selector。完成运行后，会自动生成与 Banking77 报告结构相近的 Markdown 和 6 页 PDF 报告。

## 1. 本版本和原 Banking77 报告的关系

| 项目 | Banking77 原报告 | 本 HWU64 版本 |
|---|---|---|
| 数据集 | Banking77，77 类 | HWU64，64 类 |
| 官方数据 | 10,003 train / 3,080 test | 8,954 train / 1,076 test |
| Training split | 7,000 Demo / 2,000 Meta / 1,003 Val | 按 70/20/10 分成 6,268 Demo / 1,791 Meta / 895 Val |
| Retrieval | MiniLM、Cosine Top-32 | 相同方法 |
| Demonstrations | Similar / Diverse / Balanced，8-shot | 相同方法 |
| LLM | Frozen Qwen2.5-1.5B-Instruct | 相同模型名称，运行时记录实际设备和版本 |
| Selector | Logistic Regression / TabPFN-v2 | 相同类型 |
| Meta-label | Gold-label token log-likelihood 最大策略 | **三种策略在 Meta-training 上的真实分类正确性** |
| Report | Accuracy、Macro-F1、Invalid、Oracle、配对统计 | 相同核心分析，并额外记录实际策略切换 |

**为什么改变 Meta-label？** 原报告使用 Qwen 对 gold label 的 token log-likelihood 最大值作为目标，但它与最终 greedy prediction 的 0/1 正确性并不完全等价。本版本对每条 Meta-training query 运行三个策略，直接观察哪种策略分类正确，再用该信息训练 selector。只有 Meta-training 的 gold label 用于构造训练目标；Validation 和 Test 的 gold label 不用于 selector 训练。若多个策略都正确，或三个策略都错误，则按 `Similar > Balanced > Diverse` 的固定顺序打破平局。报告会明确说明这一变化，因此不要把 HWU64 和 Banking77 的数字当成完全相同训练目标下的直接对照。

## 2. 从零开始运行（Mac）

### 第一步：解压并打开项目目录

解压 `HWU64_8shot_Code.zip`。在 Terminal 中进入解压后的 `HWU64_8shot_Code` 文件夹。例如：

```bash
cd ~/Downloads/HWU64_8shot_Code
```

### 第二步：创建独立 Python 环境

建议 Python 3.12。先检查：

```bash
python3.12 --version
```

如果显示 Python 3.12.x，继续：

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
```

如果 Mac 没有 `python3.12`，先安装 Python 3.12，再执行上面命令。不要在系统 Python 环境里直接装项目依赖。

### 第三步：安装依赖

```bash
python -m pip install -r requirements.txt
python scripts/check_environment.py
```

首次安装可能需要一些时间。若 `tabpfn` 或 `torch` 安装失败，先不要删除项目文件，把 Terminal 的完整报错发给我。

### 第四步：运行完整实验

```bash
python run.py all
```

这条命令会自动完成数据下载、数据划分、Embedding、Top-32 检索、三种 demonstration 选择、Qwen 推理、Meta-selector 训练、Validation/Test 评估、统计检验和报告生成。

第一次运行需要联网下载 HWU64、Sentence-BERT、Qwen 和 TabPFN 对应模型资源。Qwen 约 1.5B 参数，模型文件和运行内存需求不小；建议预留至少 10 GB 磁盘空间，并尽量使用有足够内存的 Mac / CUDA GPU 电脑。代码会自动选择可用的 MPS、CUDA 或 CPU；CPU 可以运行，但 Qwen 全量推理会非常慢。实际耗时取决于你的硬件和模型下载速度。

## 3. 分阶段运行（适合检查每一步）

如不想直接执行完整流程，可以按以下顺序运行：

```bash
# 1. 下载 HWU64，并生成 Demo / Meta / Validation / Test 四个划分
python run.py prepare-data

# 2. 计算 Sentence-BERT embeddings
python run.py embed

# 3. 为每条 query 建立 Top-32 候选、三套 8-shot examples 和四维 meta-features
python run.py prepare-queries

# 4. 使用冻结 Qwen 分别运行 Similar / Diverse / Balanced
python run.py predict

# 5. 根据 Meta-training 的真实正确性训练 LR / TabPFN，并完成评估和报告
python run.py evaluate
```

每一阶段完成后，程序会在 `data/`、`cache/`、`results/` 或 `models/` 保存中间结果。Qwen 输出按 query 和 strategy 缓存；中断后再次执行 `python run.py predict` 会跳过已经完成的项目，不需要从头生成所有答案。

如果 `results/evaluation.json` 已经存在，单独重新生成报告：

```bash
python run.py report
```

## 4. 生成的报告和重要文件在哪里？

完整运行结束后，打开：

```text
report/HWU64_实验报告.pdf
```

同一份报告的 Markdown 版本：

```text
report/summary.md
```

主要实验产物：

| 路径 | 内容 |
|---|---|
| `data/splits/` | 数据划分、label mapping、dataset revision 和统计信息 |
| `cache/embeddings/` | 四个 partition 的 Sentence-BERT 向量 |
| `cache/queries/` | 每条 query 的 Top-32、四维特征和三策略 demonstrations |
| `cache/predictions/` | Qwen 对每条 query、每种策略的原始输出和解析标签 |
| `results/meta_training_dataset.csv` | Meta-training features、三个策略正确性和 selector target |
| `results/evaluation.json` | Accuracy、Macro-F1、配对统计和切换分析 |
| `results/*_predictions_and_choices.csv` | Validation / Test 各 query 预测及 selector 决策 |
| `models/` | LR 模型、TabPFN fit context 和模型信息（TabPFN checkpoint revision / SHA-256 固定在 `configs/tabpfn_checkpoint.json`） |
| `report/` | PDF、Markdown 和图表 |

## 5. 报告中的指标怎么理解？

- **Similar / Diverse / Balanced**：三个固定策略，作为主要 baseline。
- **Logistic Regression / TabPFN-v2**：根据 query 的四个检索统计特征选择一种策略，再采用该策略已经生成的 Qwen 答案。
- **Oracle**：事后查看 gold label 后，从三种策略中挑选正确答案；它只表示理论上界，不能当成可部署模型结果。
- **Accuracy**：预测正确的比例。
- **Macro-F1**：先对 64 个 intent 分别计算 F1，再平均，避免只看样本多的类别。
- **Invalid**：Qwen 输出无法严格解析为 64 个官方标签的次数，这些输出按错误计入 Accuracy。
- **Beneficial / Harmful switch**：selector 相对固定 Similar 的有益切换次数 / 有害切换次数。
- **McNemar + Bootstrap + Holm**：在相同 query 上配对比较准确率差异，并做多重比较校正。

## 6. 研究过程中的注意事项

1. 先检查 `results/meta_label_diagnostics.json`。若 meta-label 几乎全部是 Similar，selector 很难学会切换；这本身是值得报告的发现，不要人为平衡 Test 结果。
2. Oracle 必须标记为 retrospective upper bound，不可以说模型达到了 Oracle。
3. 不能用 Test gold label 训练 selector，也不能用 Test 反复调参。
4. 该流程需要对 Meta-training、Validation 和 Test 的每条 query 分别生成 3 个 Qwen 输出。全量约为 **11,286 次生成**（1,791 + 895 + 1,076 条 query，再乘 3 种策略），通常是整个实验最耗时的部分。
5. 第一次正式跑请保留 `data/splits/manifest.json`、`results/evaluation.json` 和完整报告；不要只截图准确率。
6. 上传给老师或组员前，先确认报告中的硬件、模型 revision、数据 revision 和实际结果都来自本次运行，不要沿用 Banking77 报告中的任何数字。

## 7. 数据来源

- Hugging Face dataset: https://huggingface.co/datasets/DeepPavlov/hwu64
- Dataset source repository cited by the dataset card: https://github.com/jianguoz/Few-Shot-Intent-Detection

脚本会在开始时解析并记录当时的数据集 revision。报告只会根据代码实际跑出的文件生成结果，不会预填任何准确率。
